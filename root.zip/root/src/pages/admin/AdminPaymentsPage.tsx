import React, { useState, useEffect } from 'react';
import { CreditCard, ShieldCheck, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';
import { api } from '../../services/api';
import { Order } from '../../types';
import { useSettings } from '../../context/SettingsContext';

export const AdminPaymentsPage: React.FC = () => {
  const { settings, formatPrice } = useSettings();
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    api.getAdminOrders().then(res => {
      setOrders(res.orders || []);
      setIsLoading(false);
    });
  }, []);

  const totalPaid = orders
    .filter(o => o.paymentStatus === 'Paid')
    .reduce((sum, o) => sum + o.total, 0);

  const bkashTotal = orders
    .filter(o => o.paymentMethod === 'bkash' && o.paymentStatus === 'Paid')
    .reduce((sum, o) => sum + o.total, 0);

  const nagadTotal = orders
    .filter(o => o.paymentMethod === 'nagad' && o.paymentStatus === 'Paid')
    .reduce((sum, o) => sum + o.total, 0);

  const codTotal = orders
    .filter(o => o.paymentMethod === 'cod')
    .reduce((sum, o) => sum + o.total, 0);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-extrabold text-neutral-900 tracking-tight">
          Payment Gateways & Ledger
        </h1>
        <p className="text-xs text-neutral-500 mt-0.5">
          Bangladesh official payment gateways: bKash, Nagad, Cards & Cash on Delivery
        </p>
      </div>

      {/* Gateway Status Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* bKash */}
        <div className="bg-white p-5 rounded-3xl border border-neutral-200/80 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="px-2.5 py-1 rounded-lg bg-[#E2136E] text-white font-black text-xs">
              bKash
            </span>
            <span className="text-[10px] font-extrabold uppercase text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
              Connected
            </span>
          </div>
          <div>
            <p className="text-xs text-neutral-500 font-semibold">Total Verified Volume</p>
            <p className="text-xl font-black text-neutral-900 mt-0.5">{formatPrice(bkashTotal)}</p>
          </div>
          <p className="text-[10px] text-neutral-400 font-mono">Sandbox / Tokenized API v1.2</p>
        </div>

        {/* Nagad */}
        <div className="bg-white p-5 rounded-3xl border border-neutral-200/80 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="px-2.5 py-1 rounded-lg bg-[#F26522] text-white font-black text-xs">
              Nagad
            </span>
            <span className="text-[10px] font-extrabold uppercase text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
              Connected
            </span>
          </div>
          <div>
            <p className="text-xs text-neutral-500 font-semibold">Total Verified Volume</p>
            <p className="text-xl font-black text-neutral-900 mt-0.5">{formatPrice(nagadTotal)}</p>
          </div>
          <p className="text-[10px] text-neutral-400 font-mono">DFS Merchant API Gateway</p>
        </div>

        {/* Cash on Delivery */}
        <div className="bg-white p-5 rounded-3xl border border-neutral-200/80 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="px-2.5 py-1 rounded-lg bg-emerald-950 text-emerald-300 font-bold text-xs">
              Cash on Delivery
            </span>
            <span className="text-[10px] font-extrabold uppercase text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
              Active
            </span>
          </div>
          <div>
            <p className="text-xs text-neutral-500 font-semibold">Doorstep COD Volume</p>
            <p className="text-xl font-black text-neutral-900 mt-0.5">{formatPrice(codTotal)}</p>
          </div>
          <p className="text-[10px] text-neutral-400 font-mono">Collected by courier rider</p>
        </div>

        {/* Total Ledger */}
        <div className="bg-neutral-900 text-white p-5 rounded-3xl shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-amber-400 font-extrabold text-xs uppercase tracking-wider">
              Total Processed
            </span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <p className="text-xs text-neutral-400 font-semibold">Total Settlement Value</p>
            <p className="text-2xl font-black text-white mt-0.5">{formatPrice(totalPaid)}</p>
          </div>
          <p className="text-[10px] text-neutral-400 font-mono">All transactions logged</p>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-white rounded-3xl border border-neutral-200/80 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-neutral-100 flex justify-between items-center">
          <h3 className="font-extrabold text-neutral-900 text-sm">Payment Transaction History</h3>
          <span className="text-xs text-neutral-400">{orders.length} Records</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-900 text-white uppercase text-[10px] tracking-wider font-extrabold">
              <tr>
                <th className="py-3 px-4">Order #</th>
                <th className="py-3 px-3">Gateway</th>
                <th className="py-3 px-3">Transaction ID</th>
                <th className="py-3 px-3">Customer</th>
                <th className="py-3 px-3 text-right">Amount</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-4 text-right">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 font-medium">
              {orders.map(order => (
                <tr key={order.id} className="hover:bg-neutral-50/70 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-amber-700">{order.orderNumber}</td>

                  <td className="py-3 px-3">
                    <span className="font-bold uppercase text-neutral-800">{order.paymentMethod}</span>
                  </td>

                  <td className="py-3 px-3 font-mono text-neutral-500">
                    {order.transactionId || '—'}
                  </td>

                  <td className="py-3 px-3 text-neutral-800 font-semibold">{order.customerName}</td>

                  <td className="py-3 px-3 text-right font-black text-neutral-900">
                    {formatPrice(order.total)}
                  </td>

                  <td className="py-3 px-3 text-center">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                        order.paymentStatus === 'Paid'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {order.paymentStatus}
                    </span>
                  </td>

                  <td className="py-3 px-4 text-right text-neutral-400">
                    {new Date(order.createdAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
