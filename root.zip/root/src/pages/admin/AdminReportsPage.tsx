import React, { useState, useEffect } from 'react';
import { Download, BarChart3, TrendingUp, Calendar, FileText, CheckCircle2 } from 'lucide-react';
import { api } from '../../services/api';
import { useSettings } from '../../context/SettingsContext';
import { useToast } from '../../context/ToastContext';

export const AdminReportsPage: React.FC = () => {
  const { formatPrice } = useSettings();
  const { showToast } = useToast();

  const [summary, setSummary] = useState<any>(null);
  const [orders, setOrders] = useState<any[]>([]);
  const [isExporting, setIsExporting] = useState(false);

  useEffect(() => {
    Promise.all([api.getAdminReportsSummary(), api.getAdminOrders()]).then(([repRes, ordRes]) => {
      setSummary(repRes.summary);
      setOrders(ordRes.orders || []);
    });
  }, []);

  const handleExportCSV = async () => {
    setIsExporting(true);
    try {
      const token = localStorage.getItem('stepora_admin_token') || '';
      const response = await fetch('/api/admin/reports?format=csv', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `STEPORA_Sales_Report_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      showToast('Sales report CSV generated and downloaded.', 'success');
    } catch (err: any) {
      showToast('Failed to export CSV.', 'error');
    } finally {
      setIsExporting(false);
    }
  };

  const totalSales = orders.filter(o => o.paymentStatus === 'Paid').reduce((sum, o) => sum + o.total, 0);

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-neutral-900 tracking-tight">Analytics & Reports</h1>
          <p className="text-xs text-neutral-500 mt-0.5">
            Export comprehensive sales, order volume, and customer fulfillment logs
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          disabled={isExporting}
          className="flex items-center gap-2 px-5 py-2.5 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wider shadow-md transition-colors cursor-pointer disabled:opacity-50 w-fit"
        >
          <Download className="w-4 h-4 text-amber-400" />
          <span>{isExporting ? 'Generating CSV...' : 'Export Sales to CSV'}</span>
        </button>
      </div>

      {/* Summary Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-neutral-200/80 shadow-xs space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">
            Total Confirmed Revenue
          </span>
          <h3 className="text-3xl font-black text-neutral-900">{formatPrice(totalSales)}</h3>
          <p className="text-[11px] text-emerald-600 font-bold">From all verified Bangladesh gateways & COD</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-neutral-200/80 shadow-xs space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">
            Total Completed Orders
          </span>
          <h3 className="text-3xl font-black text-neutral-900">{orders.length}</h3>
          <p className="text-[11px] text-neutral-500">Nationwide doorstep fulfillment</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-neutral-200/80 shadow-xs space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">
            Average Order Value (AOV)
          </span>
          <h3 className="text-3xl font-black text-neutral-900">
            {orders.length ? formatPrice(totalSales / orders.length) : formatPrice(0)}
          </h3>
          <p className="text-[11px] text-neutral-500">Average shoe pair price per basket</p>
        </div>
      </div>

      {/* Report description box */}
      <div className="bg-white p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-4">
        <h3 className="font-extrabold text-neutral-900 text-base">Standard Export Fields</h3>
        <p className="text-xs text-neutral-600 leading-relaxed max-w-2xl">
          The generated CSV export includes raw transaction columns: Order Number, Customer Name, Mobile Phone, Division/District, SKU Breakdown, Payment Method, Verification Status, and Subtotal. Compatible with Microsoft Excel, Google Sheets, and accounting packages.
        </p>

        <div className="pt-2 flex items-center gap-2 text-xs font-bold text-emerald-700">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Compliant with standard Bangladeshi accounting audit practices.</span>
        </div>
      </div>
    </div>
  );
};
