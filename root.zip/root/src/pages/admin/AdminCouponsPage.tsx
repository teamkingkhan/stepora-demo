import React, { useState, useEffect } from 'react';
import { PlusCircle, Edit2, Trash2, X, Ticket, CheckCircle2, Clock } from 'lucide-react';
import { Coupon } from '../../types';
import { api } from '../../services/api';
import { useSettings } from '../../context/SettingsContext';
import { useToast } from '../../context/ToastContext';

export const AdminCouponsPage: React.FC = () => {
  const { formatPrice } = useSettings();
  const { showToast } = useToast();

  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null);

  const [code, setCode] = useState('');
  const [discountType, setDiscountType] = useState<'percentage' | 'fixed'>('percentage');
  const [discountValue, setDiscountValue] = useState('15');
  const [minOrderAmount, setMinOrderAmount] = useState('2000');
  const [maxDiscountAmount, setMaxDiscountAmount] = useState('600');
  const [expiryDate, setExpiryDate] = useState('2026-12-31');
  const [usageLimit, setUsageLimit] = useState('500');

  const fetchCoupons = async () => {
    setIsLoading(true);
    try {
      const res = await api.getAdminCoupons();
      setCoupons(res.coupons || []);
    } catch (err: any) {
      showToast(err.message || 'Failed to fetch coupons.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCoupons();
  }, []);

  const openCreateModal = () => {
    setEditingCoupon(null);
    setCode('');
    setDiscountType('percentage');
    setDiscountValue('15');
    setMinOrderAmount('2000');
    setMaxDiscountAmount('600');
    setExpiryDate('2026-12-31');
    setUsageLimit('500');
    setIsModalOpen(true);
  };

  const openEditModal = (c: Coupon) => {
    setEditingCoupon(c);
    setCode(c.code);
    setDiscountType(c.discountType);
    setDiscountValue(c.discountValue.toString());
    setMinOrderAmount(c.minOrderAmount?.toString() || '0');
    setMaxDiscountAmount(c.maxDiscountAmount?.toString() || '1000');
    setExpiryDate(c.expiryDate);
    setUsageLimit(c.usageLimit?.toString() || '100');
    setIsModalOpen(true);
  };

  const handleSaveCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingCoupon) {
        const res = await api.updateAdminCoupon(editingCoupon.id, {
          code,
          discountType,
          discountValue: parseFloat(discountValue),
          minOrderAmount: parseFloat(minOrderAmount),
          maxDiscountAmount: parseFloat(maxDiscountAmount),
          expiryDate,
          usageLimit: parseInt(usageLimit),
        });
        showToast('Coupon updated!', 'success');
        setCoupons(prev => prev.map(c => (c.id === editingCoupon.id ? res.coupon : c)));
      } else {
        const res = await api.createAdminCoupon({
          code,
          discountType,
          discountValue: parseFloat(discountValue),
          minOrderAmount: parseFloat(minOrderAmount),
          maxDiscountAmount: parseFloat(maxDiscountAmount),
          expiryDate,
          usageLimit: parseInt(usageLimit),
        });
        showToast('Coupon created!', 'success');
        setCoupons(prev => [res.coupon, ...prev]);
      }
      setIsModalOpen(false);
    } catch (err: any) {
      showToast(err.message || 'Failed to save coupon.', 'error');
    }
  };

  const handleDelete = async (id: string, codeName: string) => {
    if (!window.confirm(`Delete coupon "${codeName}"?`)) return;
    try {
      await api.deleteAdminCoupon(id);
      showToast('Coupon deleted.', 'info');
      setCoupons(prev => prev.filter(c => c.id !== id));
    } catch (err: any) {
      showToast(err.message || 'Failed to delete coupon.', 'error');
    }
  };

  const handleToggleActive = async (c: Coupon) => {
    try {
      const res = await api.updateAdminCoupon(c.id, { isActive: !c.isActive });
      setCoupons(prev => prev.map(item => (item.id === c.id ? res.coupon : item)));
    } catch (err: any) {
      showToast(err.message || 'Failed to toggle status.', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-extrabold text-neutral-900 tracking-tight">Coupons & Discounts</h1>
          <p className="text-xs text-neutral-500 mt-0.5">Manage promo campaigns, percentages, and minimum thresholds</p>
        </div>
        <button
          onClick={openCreateModal}
          className="flex items-center gap-2 px-5 py-2.5 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wider shadow-md cursor-pointer"
        >
          <PlusCircle className="w-4 h-4 text-amber-400" />
          <span>New Coupon</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {coupons.map(c => (
          <div
            key={c.id}
            className="bg-white p-6 rounded-3xl border border-neutral-200/80 shadow-xs flex flex-col justify-between space-y-4"
          >
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-2">
                <div className="p-2.5 rounded-xl bg-amber-50 text-amber-600">
                  <Ticket className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-mono font-black text-lg text-neutral-900 tracking-wider">
                    {c.code}
                  </h3>
                  <span className="text-[11px] font-bold text-emerald-600">
                    {c.discountType === 'percentage' ? `${c.discountValue}% OFF` : `৳ ${c.discountValue} OFF`}
                  </span>
                </div>
              </div>
              <button
                onClick={() => handleToggleActive(c)}
                className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase cursor-pointer ${
                  c.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-neutral-100 text-neutral-500'
                }`}
              >
                {c.isActive ? 'Active' : 'Disabled'}
              </button>
            </div>

            <div className="space-y-1.5 text-xs text-neutral-600">
              <div className="flex justify-between">
                <span>Min Order Spend:</span>
                <span className="font-bold text-neutral-900">{formatPrice(c.minOrderAmount)}</span>
              </div>
              <div className="flex justify-between">
                <span>Max Discount:</span>
                <span className="font-bold text-neutral-900">{formatPrice(c.maxDiscountAmount)}</span>
              </div>
              <div className="flex justify-between">
                <span>Redemptions:</span>
                <span className="font-bold text-neutral-900">
                  {c.usageCount} / {c.usageLimit}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Valid Until:</span>
                <span className="font-bold text-neutral-900">{c.expiryDate}</span>
              </div>
            </div>

            <div className="pt-3 border-t border-neutral-100 flex justify-end gap-2">
              <button
                onClick={() => openEditModal(c)}
                className="p-1.5 text-neutral-600 hover:text-black rounded-lg hover:bg-neutral-100 cursor-pointer"
              >
                <Edit2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => handleDelete(c.id, c.code)}
                className="p-1.5 text-neutral-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-neutral-100 pb-3">
              <h3 className="font-extrabold text-base text-neutral-900">
                {editingCoupon ? 'Edit Coupon' : 'Create New Coupon'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-neutral-400 hover:text-black">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCoupon} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-neutral-600 uppercase mb-1">Coupon Code *</label>
                <input
                  type="text"
                  value={code}
                  onChange={e => setCode(e.target.value.toUpperCase())}
                  placeholder="e.g. SUMMER25"
                  className="w-full px-3.5 py-2 font-mono font-black text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-neutral-600 uppercase mb-1">Type</label>
                  <select
                    value={discountType}
                    onChange={e => setDiscountType(e.target.value as any)}
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-xl font-bold cursor-pointer"
                  >
                    <option value="percentage">Percentage (%)</option>
                    <option value="fixed">Fixed Taka (৳)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-neutral-600 uppercase mb-1">Value</label>
                  <input
                    type="number"
                    value={discountValue}
                    onChange={e => setDiscountValue(e.target.value)}
                    className="w-full px-3.5 py-2 font-bold bg-neutral-50 border border-neutral-300 rounded-xl"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-neutral-600 uppercase mb-1">Min Order (৳)</label>
                  <input
                    type="number"
                    value={minOrderAmount}
                    onChange={e => setMinOrderAmount(e.target.value)}
                    className="w-full px-3.5 py-2 font-bold bg-neutral-50 border border-neutral-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-neutral-600 uppercase mb-1">Max Cap (৳)</label>
                  <input
                    type="number"
                    value={maxDiscountAmount}
                    onChange={e => setMaxDiscountAmount(e.target.value)}
                    className="w-full px-3.5 py-2 font-bold bg-neutral-50 border border-neutral-300 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-neutral-600 uppercase mb-1">Expiry Date</label>
                  <input
                    type="date"
                    value={expiryDate}
                    onChange={e => setExpiryDate(e.target.value)}
                    className="w-full px-3.5 py-2 font-medium bg-neutral-50 border border-neutral-300 rounded-xl"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-neutral-600 uppercase mb-1">Usage Limit</label>
                  <input
                    type="number"
                    value={usageLimit}
                    onChange={e => setUsageLimit(e.target.value)}
                    className="w-full px-3.5 py-2 font-bold bg-neutral-50 border border-neutral-300 rounded-xl"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-neutral-300 rounded-xl font-bold uppercase text-neutral-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-neutral-900 text-white rounded-xl font-bold uppercase tracking-wider shadow-md"
                >
                  Save Coupon
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
