import React, { useState, useEffect } from 'react';
import { Star, CheckCircle2, EyeOff, Trash2, MessageSquare } from 'lucide-react';
import { Review } from '../../types';
import { api } from '../../services/api';
import { useToast } from '../../context/ToastContext';

export const AdminReviewsPage: React.FC = () => {
  const { showToast } = useToast();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchReviews = async () => {
    setIsLoading(true);
    try {
      const res = await api.getAdminReviews();
      setReviews(res.reviews || []);
    } catch (err: any) {
      showToast(err.message || 'Failed to load reviews.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchReviews();
  }, []);

  const handleUpdateStatus = async (id: string, status: string) => {
    try {
      await api.updateAdminReviewStatus(id, status);
      showToast(`Review status updated to ${status}.`, 'success');
      setReviews(prev => prev.map(r => (r.id === id ? { ...r, status: status as any } : r)));
    } catch (err: any) {
      showToast(err.message || 'Failed to update review status.', 'error');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Delete this review permanently?')) return;
    try {
      await api.deleteAdminReview(id);
      showToast('Review removed.', 'info');
      setReviews(prev => prev.filter(r => r.id !== id));
    } catch (err: any) {
      showToast(err.message || 'Failed to delete review.', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-neutral-900 tracking-tight">Customer Reviews</h1>
        <p className="text-xs text-neutral-500 mt-0.5">Moderate customer feedback, ratings, and verified purchases</p>
      </div>

      <div className="space-y-4">
        {reviews.map(rev => (
          <div
            key={rev.id}
            className="bg-white p-6 rounded-3xl border border-neutral-200/80 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
          >
            <div className="space-y-2 max-w-2xl">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-0.5 text-amber-400">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < rev.rating ? 'fill-amber-400 text-amber-400' : 'fill-neutral-200 text-neutral-200'
                      }`}
                    />
                  ))}
                </div>
                <h4 className="font-extrabold text-neutral-900 text-sm">{rev.title}</h4>
                {rev.isVerifiedPurchase && (
                  <span className="text-[10px] font-extrabold uppercase text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                    Verified Buyer
                  </span>
                )}
              </div>

              <p className="text-xs text-neutral-600 leading-relaxed font-medium">"{rev.comment}"</p>

              <div className="flex items-center gap-3 text-[11px] text-neutral-400">
                <span>By: <strong className="text-neutral-700">{rev.userName}</strong> ({rev.userEmail || 'N/A'})</span>
                <span>•</span>
                <span>{new Date(rev.createdAt).toLocaleDateString()}</span>
                <span>•</span>
                <span className={`font-bold uppercase ${rev.status === 'approved' ? 'text-emerald-600' : 'text-amber-600'}`}>
                  {rev.status}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {rev.status !== 'approved' && (
                <button
                  onClick={() => handleUpdateStatus(rev.id, 'approved')}
                  className="px-3 py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  Approve
                </button>
              )}
              {rev.status !== 'hidden' && (
                <button
                  onClick={() => handleUpdateStatus(rev.id, 'hidden')}
                  className="px-3 py-1.5 bg-neutral-100 text-neutral-700 hover:bg-neutral-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  Hide
                </button>
              )}
              <button
                onClick={() => handleDelete(rev.id)}
                className="p-2 text-neutral-400 hover:text-rose-600 rounded-xl hover:bg-rose-50 transition-colors cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
