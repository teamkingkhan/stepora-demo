import React, { useState } from 'react';
import {
  LayoutDashboard,
  Package,
  Layers,
  ShoppingBag,
  Users,
  Boxes,
  Ticket,
  MessageSquare,
  CreditCard,
  BarChart3,
  Settings,
  UserCheck,
  LogOut,
  ExternalLink,
  Menu,
  X,
  PlusCircle,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useSettings } from '../../context/SettingsContext';

export type AdminTab =
  | 'dashboard'
  | 'products'
  | 'add-product'
  | 'categories'
  | 'orders'
  | 'customers'
  | 'inventory'
  | 'coupons'
  | 'reviews'
  | 'payments'
  | 'reports'
  | 'settings'
  | 'profile';

interface AdminLayoutProps {
  currentTab: AdminTab;
  onSelectTab: (tab: AdminTab) => void;
  onNavigateToStore: () => void;
  children: React.ReactNode;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  currentTab,
  onSelectTab,
  onNavigateToStore,
  children,
}) => {
  const { admin, adminLogout } = useAuth();
  const { settings } = useSettings();
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  const navItems: { tab: AdminTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    { tab: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { tab: 'products', label: 'Products', icon: <Package className="w-4 h-4" /> },
    { tab: 'add-product', label: 'Add New Product', icon: <PlusCircle className="w-4 h-4 text-amber-500" /> },
    { tab: 'categories', label: 'Categories', icon: <Layers className="w-4 h-4" /> },
    { tab: 'orders', label: 'Orders Management', icon: <ShoppingBag className="w-4 h-4" /> },
    { tab: 'customers', label: 'Customers', icon: <Users className="w-4 h-4" /> },
    { tab: 'inventory', label: 'Inventory Stock', icon: <Boxes className="w-4 h-4" /> },
    { tab: 'coupons', label: 'Coupons & Promo', icon: <Ticket className="w-4 h-4" /> },
    { tab: 'reviews', label: 'Customer Reviews', icon: <MessageSquare className="w-4 h-4" /> },
    { tab: 'payments', label: 'Payment Gateways', icon: <CreditCard className="w-4 h-4" /> },
    { tab: 'reports', label: 'Analytics Reports', icon: <BarChart3 className="w-4 h-4" /> },
    { tab: 'settings', label: 'Store Settings', icon: <Settings className="w-4 h-4" /> },
    { tab: 'profile', label: 'Admin Security', icon: <UserCheck className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen bg-neutral-100 flex flex-col">
      {/* Top Navbar */}
      <header className="bg-neutral-900 text-white border-b border-neutral-800 sticky top-0 z-30">
        <div className="px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
              className="lg:hidden p-2 text-neutral-400 hover:text-white cursor-pointer"
            >
              {isMobileSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => onSelectTab('dashboard')}>
              <div className="w-8 h-8 rounded-lg bg-amber-500 text-neutral-950 font-black flex items-center justify-center text-base">
                S
              </div>
              <div className="flex flex-col">
                <span className="font-extrabold text-sm tracking-tight text-white uppercase">
                  {settings.storeName.split(' ')[0] || 'STEPORA'} ADMIN
                </span>
                <span className="text-[10px] text-amber-400 font-bold uppercase tracking-widest -mt-1">
                  Management Console
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onNavigateToStore}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Live Storefront</span>
            </button>

            <div className="hidden sm:flex items-center gap-2 pl-3 border-l border-neutral-800 text-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-bold text-neutral-300">{admin?.fullName || 'RAHULADMIN'}</span>
            </div>

            <button
              onClick={adminLogout}
              className="p-1.5 text-neutral-400 hover:text-rose-400 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:flex flex-col w-64 bg-white border-r border-neutral-200/80 shrink-0 p-4 space-y-1">
          <div className="text-[10px] font-extrabold uppercase tracking-widest text-neutral-400 px-3 py-2">
            Navigation Menu
          </div>
          {navItems.map(item => (
            <button
              key={item.tab}
              onClick={() => onSelectTab(item.tab)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                currentTab === item.tab
                  ? 'bg-neutral-900 text-white shadow-sm'
                  : 'text-neutral-600 hover:bg-neutral-100 hover:text-black'
              }`}
            >
              <div className="flex items-center gap-2.5">
                {item.icon}
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-900">
                  {item.badge}
                </span>
              )}
            </button>
          ))}

          <div className="mt-auto pt-4 border-t border-neutral-100">
            <button
              onClick={adminLogout}
              className="w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-bold text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out Admin</span>
            </button>
          </div>
        </aside>

        {/* Mobile Sidebar Drawer */}
        {isMobileSidebarOpen && (
          <div className="lg:hidden fixed inset-0 z-40 bg-black/60 backdrop-blur-xs flex">
            <div className="w-64 bg-white h-full shadow-2xl flex flex-col p-4 overflow-y-auto animate-in slide-in-from-left">
              <div className="flex items-center justify-between pb-4 border-b border-neutral-200">
                <span className="font-extrabold text-sm uppercase text-neutral-900">Admin Menu</span>
                <button onClick={() => setIsMobileSidebarOpen(false)} className="p-1 text-neutral-500">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="py-2 space-y-1">
                {navItems.map(item => (
                  <button
                    key={item.tab}
                    onClick={() => {
                      onSelectTab(item.tab);
                      setIsMobileSidebarOpen(false);
                    }}
                    className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-bold ${
                      currentTab === item.tab
                        ? 'bg-neutral-900 text-white'
                        : 'text-neutral-700 hover:bg-neutral-100'
                    }`}
                  >
                    {item.icon}
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="flex-1" onClick={() => setIsMobileSidebarOpen(false)} />
          </div>
        )}

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">{children}</div>
        </main>
      </div>
    </div>
  );
};
