import React, { useState } from 'react';
import { Settings, Save, ShieldCheck, Truck, DollarSign, Globe, CheckCircle2 } from 'lucide-react';
import { useSettings } from '../../context/SettingsContext';
import { useToast } from '../../context/ToastContext';
import { api } from '../../services/api';

export const AdminSettingsPage: React.FC = () => {
  const { settings, refreshSettings } = useSettings();
  const { showToast } = useToast();

  const [formData, setFormData] = useState({
    storeName: settings.storeName,
    storeEmail: settings.storeEmail,
    storePhone: settings.storePhone,
    storeAddress: settings.storeAddress,
    currency: settings.currency,
    currencyCode: settings.currencyCode,
    insideDhakaShippingFee: settings.insideDhakaShippingFee,
    outsideDhakaShippingFee: settings.outsideDhakaShippingFee,
    freeShippingThreshold: settings.freeShippingThreshold,
    enableBkash: settings.enableBkash,
    enableNagad: settings.enableNagad,
    enableCard: settings.enableCard,
    enableCod: settings.enableCod,
    paymentTestMode: settings.paymentTestMode,
  });

  const [isSaving, setIsSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await api.updateAdminSettings(formData);
      await refreshSettings();
      showToast('Store settings updated successfully!', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to update settings.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-extrabold text-neutral-900 tracking-tight">Website & Store Settings</h1>
        <p className="text-xs text-neutral-500 mt-0.5">
          Configure branding, currency, shipping tariffs, and payment gateways
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Branding & Contact Info */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-neutral-100 pb-3">
            <Globe className="w-4 h-4 text-amber-600" />
            <h3 className="font-extrabold text-neutral-900 text-sm uppercase tracking-wider">
              Branding & Contact Info
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-bold text-neutral-600 uppercase mb-1">Store Brand Name</label>
              <input
                type="text"
                value={formData.storeName}
                onChange={e => setFormData({ ...formData, storeName: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl font-bold"
                required
              />
            </div>

            <div>
              <label className="block font-bold text-neutral-600 uppercase mb-1">Customer Support Email</label>
              <input
                type="email"
                value={formData.storeEmail}
                onChange={e => setFormData({ ...formData, storeEmail: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl font-medium"
                required
              />
            </div>

            <div>
              <label className="block font-bold text-neutral-600 uppercase mb-1">Store Hotline Phone</label>
              <input
                type="text"
                value={formData.storePhone}
                onChange={e => setFormData({ ...formData, storePhone: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl font-medium"
                required
              />
            </div>

            <div>
              <label className="block font-bold text-neutral-600 uppercase mb-1">Currency Symbol & Code</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={formData.currency}
                  onChange={e => setFormData({ ...formData, currency: e.target.value })}
                  className="w-1/3 px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl font-bold text-center"
                />
                <input
                  type="text"
                  value={formData.currencyCode}
                  onChange={e => setFormData({ ...formData, currencyCode: e.target.value })}
                  className="w-2/3 px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl font-bold"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-neutral-600 uppercase mb-1">
              Flagship Showroom / Workshop Address
            </label>
            <input
              type="text"
              value={formData.storeAddress}
              onChange={e => setFormData({ ...formData, storeAddress: e.target.value })}
              className="w-full px-3.5 py-2.5 text-xs bg-neutral-50 border border-neutral-300 rounded-xl font-medium"
              required
            />
          </div>
        </div>

        {/* Shipping Tariff Settings */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-neutral-100 pb-3">
            <Truck className="w-4 h-4 text-amber-600" />
            <h3 className="font-extrabold text-neutral-900 text-sm uppercase tracking-wider">
              Nationwide Shipping Fees (Bangladesh)
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block font-bold text-neutral-600 uppercase mb-1">
                Inside Dhaka Fee (৳)
              </label>
              <input
                type="number"
                value={formData.insideDhakaShippingFee}
                onChange={e =>
                  setFormData({ ...formData, insideDhakaShippingFee: parseInt(e.target.value) || 0 })
                }
                className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl font-bold"
                required
              />
            </div>

            <div>
              <label className="block font-bold text-neutral-600 uppercase mb-1">
                Outside Dhaka Fee (৳)
              </label>
              <input
                type="number"
                value={formData.outsideDhakaShippingFee}
                onChange={e =>
                  setFormData({ ...formData, outsideDhakaShippingFee: parseInt(e.target.value) || 0 })
                }
                className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl font-bold"
                required
              />
            </div>

            <div>
              <label className="block font-bold text-neutral-600 uppercase mb-1">
                Free Shipping Threshold (৳)
              </label>
              <input
                type="number"
                value={formData.freeShippingThreshold}
                onChange={e =>
                  setFormData({ ...formData, freeShippingThreshold: parseInt(e.target.value) || 0 })
                }
                className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl font-bold text-emerald-700"
                required
              />
            </div>
          </div>
        </div>

        {/* Payment Gateways Config */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-neutral-100 pb-3">
            <ShieldCheck className="w-4 h-4 text-amber-600" />
            <h3 className="font-extrabold text-neutral-900 text-sm uppercase tracking-wider">
              Payment Gateway Methods
            </h3>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-bold">
            <label className="flex items-center gap-2.5 p-3 rounded-xl border border-neutral-200 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.enableBkash}
                onChange={e => setFormData({ ...formData, enableBkash: e.target.checked })}
                className="w-4 h-4 text-[#E2136E] rounded"
              />
              <span>bKash Wallet</span>
            </label>

            <label className="flex items-center gap-2.5 p-3 rounded-xl border border-neutral-200 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.enableNagad}
                onChange={e => setFormData({ ...formData, enableNagad: e.target.checked })}
                className="w-4 h-4 text-[#F26522] rounded"
              />
              <span>Nagad Wallet</span>
            </label>

            <label className="flex items-center gap-2.5 p-3 rounded-xl border border-neutral-200 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.enableCard}
                onChange={e => setFormData({ ...formData, enableCard: e.target.checked })}
                className="w-4 h-4 text-neutral-900 rounded"
              />
              <span>Credit / Debit Card</span>
            </label>

            <label className="flex items-center gap-2.5 p-3 rounded-xl border border-neutral-200 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.enableCod}
                onChange={e => setFormData({ ...formData, enableCod: e.target.checked })}
                className="w-4 h-4 text-emerald-600 rounded"
              />
              <span>Cash on Delivery</span>
            </label>
          </div>

          <div className="pt-2">
            <label className="flex items-center gap-2.5 p-3 bg-amber-50 rounded-xl border border-amber-200 cursor-pointer text-xs font-bold text-amber-950">
              <input
                type="checkbox"
                checked={formData.paymentTestMode}
                onChange={e => setFormData({ ...formData, paymentTestMode: e.target.checked })}
                className="w-4 h-4 text-amber-600 rounded"
              />
              <span>Enable Sandbox / Test Simulation Gateway Mode</span>
            </label>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="flex items-center gap-2 px-8 py-3.5 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wider shadow-lg transition-colors cursor-pointer disabled:opacity-50"
          >
            <Save className="w-4 h-4 text-amber-400" />
            <span>{isSaving ? 'Saving Changes...' : 'Save All Settings'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
