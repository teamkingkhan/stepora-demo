import React, { useState } from 'react';
import { X, Plus, Trash2, Image, Check, Sparkles } from 'lucide-react';
import { Product, ShoeSize, ProductColor } from '../../types';

interface AdminProductFormModalProps {
  product?: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (productData: any) => Promise<void>;
}

const ALL_SIZES: ShoeSize[] = ['36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46'];

export const AdminProductFormModal: React.FC<AdminProductFormModalProps> = ({
  product,
  isOpen,
  onClose,
  onSave,
}) => {
  const isEditing = Boolean(product);

  const [name, setName] = useState(product?.name || '');
  const [sku, setSku] = useState(product?.sku || `STP-${Date.now().toString().slice(-4)}`);
  const [category, setCategory] = useState(product?.category || 'sneakers');
  const [subcategory, setSubcategory] = useState(product?.subcategory || '');
  const [brand, setBrand] = useState(product?.brand || 'STEPORA ORIGINALS');
  const [gender, setGender] = useState<'men' | 'women' | 'kids' | 'unisex'>(product?.gender || 'unisex');
  const [price, setPrice] = useState(product?.price?.toString() || '3500');
  const [salePrice, setSalePrice] = useState(product?.salePrice?.toString() || '2990');
  const [description, setDescription] = useState(product?.description || '');
  const [shortDescription, setShortDescription] = useState(product?.shortDescription || '');

  // Sizes & Stock
  const [selectedSizes, setSelectedSizes] = useState<ShoeSize[]>(
    product?.availableSizes || ['39', '40', '41', '42', '43']
  );
  const [stockQuantity, setStockQuantity] = useState(product?.stockQuantity?.toString() || '20');

  // Images Area
  const [images, setImages] = useState<string[]>(
    product?.images && product.images.length
      ? product.images
      : ['https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=800&q=80']
  );
  const [newImageUrl, setNewImageUrl] = useState('');

  // Colors
  const [colors, setColors] = useState<ProductColor[]>(
    product?.availableColors || [
      { name: 'Onyx Black', hex: '#111111' },
      { name: 'Pure White', hex: '#FFFFFF' },
    ]
  );
  const [colorName, setColorName] = useState('');
  const [colorHex, setColorHex] = useState('#000000');

  // Badges & Status
  const [featured, setFeatured] = useState(Boolean(product?.featured));
  const [bestSeller, setBestSeller] = useState(Boolean(product?.bestSeller));
  const [newArrival, setNewArrival] = useState(Boolean(product?.newArrival ?? true));
  const [isActive, setIsActive] = useState(Boolean(product?.isActive ?? true));

  const [isSaving, setIsSaving] = useState(false);

  if (!isOpen) return null;

  const handleAddImage = () => {
    if (newImageUrl.trim()) {
      setImages(prev => [...prev, newImageUrl.trim()]);
      setNewImageUrl('');
    }
  };

  const handleRemoveImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSetMainImage = (index: number) => {
    const selected = images[index];
    const rest = images.filter((_, i) => i !== index);
    setImages([selected, ...rest]);
  };

  const handleAddColor = () => {
    if (colorName.trim()) {
      setColors(prev => [...prev, { name: colorName.trim(), hex: colorHex }]);
      setColorName('');
    }
  };

  const handleRemoveColor = (index: number) => {
    setColors(prev => prev.filter((_, i) => i !== index));
  };

  const toggleSize = (size: ShoeSize) => {
    setSelectedSizes(prev =>
      prev.includes(size) ? prev.filter(s => s !== size) : [...prev, size].sort()
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);

    const sizeStock = selectedSizes.map(size => {
      const existing = product?.sizeStock?.find(s => s.size === size);
      return {
        size,
        stock: existing ? existing.stock : Math.round(parseInt(stockQuantity) / selectedSizes.length) || 4,
      };
    });

    const payload = {
      name,
      sku,
      category,
      subcategory,
      brand,
      gender,
      price: parseFloat(price) || 0,
      salePrice: parseFloat(salePrice) || parseFloat(price) || 0,
      description,
      shortDescription,
      availableSizes: selectedSizes,
      sizeStock,
      stockQuantity: parseInt(stockQuantity) || 0,
      images,
      mainImage: images[0] || 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=800&q=80',
      availableColors: colors,
      featured,
      bestSeller,
      newArrival,
      isActive,
    };

    try {
      await onSave(payload);
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 bg-neutral-900 text-white">
          <div>
            <h3 className="font-extrabold text-base">
              {isEditing ? `Edit Product: ${product?.name}` : 'Add New Footwear Model'}
            </h3>
            <p className="text-xs text-neutral-400">Configure shoe images, sizes, colors, and pricing</p>
          </div>
          <button onClick={onClose} className="p-1.5 text-neutral-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6">
          {/* Basic Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">
                Shoe Name *
              </label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Apex Glide Nitro Runner"
                className="w-full px-3.5 py-2.5 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900 font-semibold"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">
                SKU Code *
              </label>
              <input
                type="text"
                value={sku}
                onChange={e => setSku(e.target.value)}
                placeholder="STP-RUN-001"
                className="w-full px-3.5 py-2.5 text-sm bg-neutral-50 border border-neutral-300 rounded-xl font-mono focus:bg-white focus:outline-none focus:border-neutral-900 font-bold"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">Category *</label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-neutral-50 border border-neutral-300 rounded-xl font-bold cursor-pointer"
              >
                <option value="sneakers">Sneakers</option>
                <option value="men">Men's Shoes</option>
                <option value="women">Women's Shoes</option>
                <option value="sports">Sports & Running</option>
                <option value="formal">Formal Leather</option>
                <option value="casual">Casual & Loafers</option>
                <option value="boots">Boots</option>
                <option value="sandals">Sandals & Slippers</option>
                <option value="kids">Kids' Shoes</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">Brand</label>
              <input
                type="text"
                value={brand}
                onChange={e => setBrand(e.target.value)}
                placeholder="STEPORA PRO"
                className="w-full px-3.5 py-2.5 text-xs bg-neutral-50 border border-neutral-300 rounded-xl font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">Gender</label>
              <select
                value={gender}
                onChange={e => setGender(e.target.value as any)}
                className="w-full px-3.5 py-2.5 text-xs bg-neutral-50 border border-neutral-300 rounded-xl font-bold cursor-pointer"
              >
                <option value="men">Men</option>
                <option value="women">Women</option>
                <option value="kids">Kids</option>
                <option value="unisex">Unisex</option>
              </select>
            </div>
          </div>

          {/* Pricing & Stock */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">
                Regular Price (৳) *
              </label>
              <input
                type="number"
                value={price}
                onChange={e => setPrice(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm bg-neutral-50 border border-neutral-300 rounded-xl font-bold"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">
                Sale Price (৳)
              </label>
              <input
                type="number"
                value={salePrice}
                onChange={e => setSalePrice(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm bg-neutral-50 border border-neutral-300 rounded-xl font-bold text-rose-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">
                Total Stock Quantity *
              </label>
              <input
                type="number"
                value={stockQuantity}
                onChange={e => setStockQuantity(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm bg-neutral-50 border border-neutral-300 rounded-xl font-bold"
                required
              />
            </div>
          </div>

          {/* Available Shoe Sizes */}
          <div>
            <label className="block text-xs font-bold uppercase text-neutral-600 mb-2">
              Available Shoe Sizes (EU / Bangladesh)
            </label>
            <div className="flex flex-wrap gap-2">
              {ALL_SIZES.map(sz => (
                <button
                  type="button"
                  key={sz}
                  onClick={() => toggleSize(sz)}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                    selectedSizes.includes(sz)
                      ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
                      : 'bg-white text-neutral-500 border-neutral-300'
                  }`}
                >
                  EU {sz}
                </button>
              ))}
            </div>
          </div>

          {/* Product Images Area (Section 49) */}
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold uppercase text-neutral-600">
                Product Photography Gallery (Direct Free-Stock / Unsplash URLs)
              </label>
              <span className="text-[11px] text-neutral-400">First image is Main Cover</span>
            </div>

            <div className="flex gap-2">
              <input
                type="url"
                value={newImageUrl}
                onChange={e => setNewImageUrl(e.target.value)}
                placeholder="Paste remote image URL (e.g. https://images.unsplash.com/...)"
                className="flex-1 px-3.5 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900"
              />
              <button
                type="button"
                onClick={handleAddImage}
                className="px-4 py-2 bg-neutral-900 text-white text-xs font-bold rounded-xl cursor-pointer hover:bg-black"
              >
                Add Image
              </button>
            </div>

            {/* Images preview strip */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {images.map((img, idx) => (
                <div key={idx} className="relative aspect-square rounded-2xl overflow-hidden border group bg-neutral-100">
                  <img src={img} alt="Product preview" className="w-full h-full object-cover" />
                  {idx === 0 ? (
                    <span className="absolute top-2 left-2 px-2 py-0.5 bg-neutral-900 text-white text-[10px] font-bold rounded-md">
                      Cover
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleSetMainImage(idx)}
                      className="absolute top-2 left-2 px-2 py-0.5 bg-white/90 text-neutral-900 text-[10px] font-bold rounded-md opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer shadow-xs"
                    >
                      Make Cover
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => handleRemoveImage(idx)}
                    className="absolute top-2 right-2 p-1.5 bg-rose-600 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">
              Product Description
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Describe materials, leather tanning, cushioning and performance..."
              className="w-full px-3.5 py-2.5 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900"
            />
          </div>

          {/* Badges / Visibility Toggles */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-neutral-50 rounded-2xl border border-neutral-200">
            <label className="flex items-center gap-2 text-xs font-bold text-neutral-800 cursor-pointer">
              <input
                type="checkbox"
                checked={isActive}
                onChange={e => setIsActive(e.target.checked)}
                className="w-4 h-4 text-neutral-900 rounded"
              />
              <span>Active on Store</span>
            </label>

            <label className="flex items-center gap-2 text-xs font-bold text-neutral-800 cursor-pointer">
              <input
                type="checkbox"
                checked={featured}
                onChange={e => setFeatured(e.target.checked)}
                className="w-4 h-4 text-neutral-900 rounded"
              />
              <span>Featured</span>
            </label>

            <label className="flex items-center gap-2 text-xs font-bold text-neutral-800 cursor-pointer">
              <input
                type="checkbox"
                checked={bestSeller}
                onChange={e => setBestSeller(e.target.checked)}
                className="w-4 h-4 text-neutral-900 rounded"
              />
              <span>Best Seller</span>
            </label>

            <label className="flex items-center gap-2 text-xs font-bold text-neutral-800 cursor-pointer">
              <input
                type="checkbox"
                checked={newArrival}
                onChange={e => setNewArrival(e.target.checked)}
                className="w-4 h-4 text-neutral-900 rounded"
              />
              <span>New Arrival</span>
            </label>
          </div>

          {/* Modal Footer */}
          <div className="pt-4 border-t border-neutral-200 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2.5 border border-neutral-300 rounded-xl text-xs font-bold uppercase text-neutral-700 hover:bg-neutral-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2.5 bg-neutral-900 hover:bg-black text-white text-xs font-bold uppercase tracking-wider rounded-xl shadow-md cursor-pointer disabled:opacity-50"
            >
              {isSaving ? 'Saving Product...' : isEditing ? 'Update Footwear' : 'Create Product'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
