import React, { useState } from 'react';
import { ShieldCheck, Lock, User, Key, CheckCircle2, AlertCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { api } from '../../services/api';

export const AdminProfilePage: React.FC = () => {
  const { admin } = useAuth();
  const { showToast } = useToast();

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setErrorMessage('New passwords do not match.');
      return;
    }
    if (newPassword.length < 6) {
      setErrorMessage('Password must be at least 6 characters.');
      return;
    }

    setIsUpdating(true);
    setErrorMessage(null);

    try {
      await api.changeAdminPassword({ currentPassword, newPassword });
      showToast('Admin password updated securely!', 'success');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to update admin password.');
      showToast(err.message || 'Password update failed.', 'error');
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="space-y-6 max-w-xl">
      <div>
        <h1 className="text-2xl font-extrabold text-neutral-900 tracking-tight">Admin Security & Profile</h1>
        <p className="text-xs text-neutral-500 mt-0.5">
          Manage root administrative credentials and backend access security
        </p>
      </div>

      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-6">
        <div className="flex items-center gap-4 border-b border-neutral-100 pb-5">
          <div className="w-12 h-12 rounded-2xl bg-neutral-900 text-amber-400 font-extrabold text-lg flex items-center justify-center">
            {admin?.fullName.charAt(0) || 'A'}
          </div>
          <div>
            <h3 className="font-extrabold text-base text-neutral-900">{admin?.fullName}</h3>
            <p className="text-xs text-neutral-500">{admin?.email}</p>
          </div>
        </div>

        {errorMessage && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleChangePassword} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-neutral-600 uppercase mb-1">
              Current Admin Password (Default: 123456) *
            </label>
            <input
              type="password"
              value={currentPassword}
              onChange={e => setCurrentPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl font-medium focus:bg-white focus:outline-none focus:border-neutral-900"
              required
            />
          </div>

          <div>
            <label className="block font-bold text-neutral-600 uppercase mb-1">
              New Secure Password *
            </label>
            <input
              type="password"
              value={newPassword}
              onChange={e => setNewPassword(e.target.value)}
              placeholder="At least 6 characters"
              className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl font-medium focus:bg-white focus:outline-none focus:border-neutral-900"
              required
            />
          </div>

          <div>
            <label className="block font-bold text-neutral-600 uppercase mb-1">
              Confirm New Password *
            </label>
            <input
              type="password"
              value={confirmPassword}
              onChange={e => setConfirmPassword(e.target.value)}
              placeholder="Re-enter new password"
              className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl font-medium focus:bg-white focus:outline-none focus:border-neutral-900"
              required
            />
          </div>

          <button
            type="submit"
            disabled={isUpdating}
            className="w-full py-3 bg-neutral-900 hover:bg-black text-white rounded-xl font-bold uppercase tracking-wider shadow-md transition-colors cursor-pointer disabled:opacity-50"
          >
            {isUpdating ? 'Updating Credentials...' : 'Save New Admin Password'}
          </button>
        </form>
      </div>
    </div>
  );
};
