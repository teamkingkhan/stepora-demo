import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  DollarSign,
  ShoppingBag,
  Package,
  Users,
  AlertTriangle,
  ArrowUpRight,
  PlusCircle,
  Clock,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { DashboardStats } from '../../types';
import { api } from '../../services/api';
import { useSettings } from '../../context/SettingsContext';

interface AdminDashboardPageProps {
  onSelectTab: (tab: any) => void;
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ onSelectTab }) => {
  const { formatPrice } = useSettings();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    api
      .getAdminDashboard()
      .then(res => setStats(res.stats))
      .catch(err => console.error('Dashboard load error:', err))
      .finally(() => setIsLoading(false));
  }, []);

  if (isLoading || !stats) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 animate-pulse">
        {[...Array(8)].map((_, i) => (
          <div key={i} className="h-32 bg-white rounded-3xl border border-neutral-200" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-widest text-amber-600">Executive Overview</span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight mt-0.5">
            Store Performance Dashboard
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onSelectTab('add-product')}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wider shadow-md transition-colors cursor-pointer"
          >
            <PlusCircle className="w-4 h-4 text-amber-400" />
            <span>Add Footwear</span>
          </button>
          <button
            onClick={() => onSelectTab('orders')}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-white border border-neutral-300 hover:bg-neutral-50 text-neutral-800 rounded-xl text-xs font-bold uppercase tracking-wider shadow-xs transition-colors cursor-pointer"
          >
            <span>View Orders</span>
          </button>
        </div>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Total Sales */}
        <div className="bg-white p-6 rounded-3xl border border-neutral-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-neutral-500 font-bold uppercase tracking-wider">
            <span>Total Sales Revenue</span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <h3 className="text-2xl sm:text-3xl font-black text-neutral-900">
              {formatPrice(stats.totalSales)}
            </h3>
            <p className="text-xs text-neutral-500 mt-1">
              Monthly estimate: <strong>{formatPrice(stats.monthlySales)}</strong>
            </p>
          </div>
        </div>

        {/* Total Orders */}
        <div className="bg-white p-6 rounded-3xl border border-neutral-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-neutral-500 font-bold uppercase tracking-wider">
            <span>Total Footwear Orders</span>
            <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <h3 className="text-2xl sm:text-3xl font-black text-neutral-900">
              {stats.totalOrders}
            </h3>
            <div className="flex items-center gap-2 mt-1 text-xs text-neutral-500">
              <span className="text-emerald-600 font-bold">{stats.completedOrders} Delivered</span>
              <span>•</span>
              <span className="text-amber-600 font-bold">{stats.pendingOrders} Pending</span>
            </div>
          </div>
        </div>

        {/* Total Footwear Products */}
        <div className="bg-white p-6 rounded-3xl border border-neutral-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-neutral-500 font-bold uppercase tracking-wider">
            <span>Product Catalog</span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <h3 className="text-2xl sm:text-3xl font-black text-neutral-900">
              {stats.totalProducts} Designs
            </h3>
            <p className="text-xs text-neutral-500 mt-1">
              Active stock across all sizes 36–46
            </p>
          </div>
        </div>

        {/* Stock Alerts */}
        <div className="bg-white p-6 rounded-3xl border border-neutral-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-neutral-500 font-bold uppercase tracking-wider">
            <span>Inventory Alerts</span>
            <div className="p-2 rounded-xl bg-rose-50 text-rose-600">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-amber-600">{stats.lowStockCount} Low</span>
              <span className="text-neutral-400">/</span>
              <span className="text-2xl font-black text-rose-600">{stats.outOfStockCount} Out</span>
            </div>
            <button
              onClick={() => onSelectTab('inventory')}
              className="text-xs text-amber-700 font-bold hover:underline mt-1 block"
            >
              Manage Inventory Stock →
            </button>
          </div>
        </div>
      </div>

      {/* Charts & Analytical Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sales Overview Area SVG Visualizer */}
        <div className="lg:col-span-2 bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-neutral-100 pb-4">
            <div>
              <h3 className="font-extrabold text-neutral-900 text-base">Sales Revenue Trend</h3>
              <p className="text-xs text-neutral-500">Order transaction trajectory (BDT)</p>
            </div>
            <span className="px-3 py-1 bg-amber-50 text-amber-800 text-xs font-bold rounded-lg">
              Last 7 Timeframes
            </span>
          </div>

          {/* Simple Clean Responsive SVG Bar Graph */}
          <div className="h-64 flex items-end justify-between gap-3 pt-6 px-2">
            {stats.salesOverview.map((item, idx) => {
              const maxVal = Math.max(...stats.salesOverview.map(s => s.amount), 5000);
              const barHeightPct = Math.max(15, Math.round((item.amount / maxVal) * 85));

              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                  <span className="text-[10px] font-bold text-neutral-500 opacity-0 group-hover:opacity-100 transition-opacity">
                    {formatPrice(item.amount)}
                  </span>
                  <div
                    className="w-full max-w-[48px] bg-neutral-900 group-hover:bg-amber-500 rounded-t-xl transition-all duration-300 shadow-xs"
                    style={{ height: `${barHeightPct}%` }}
                  />
                  <span className="text-[11px] font-mono text-neutral-500 truncate w-full text-center">
                    {item.date.slice(5)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Category Breakdown */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-6">
          <div className="border-b border-neutral-100 pb-4">
            <h3 className="font-extrabold text-neutral-900 text-base">Category Performance</h3>
            <p className="text-xs text-neutral-500">Revenue contribution per footwear line</p>
          </div>

          <div className="space-y-4">
            {stats.categoryPerformance.map((cat, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-neutral-800 capitalize">{cat.category}</span>
                  <span className="text-neutral-900">{formatPrice(cat.sales)}</span>
                </div>
                <div className="w-full h-2 rounded-full bg-neutral-100 overflow-hidden">
                  <div
                    className="h-full bg-amber-500 rounded-full"
                    style={{
                      width: `${Math.min(100, Math.round((cat.sales / (stats.totalSales || 1)) * 100))}%`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top Selling Products List */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-6">
        <div className="flex justify-between items-center border-b border-neutral-100 pb-4">
          <div>
            <h3 className="font-extrabold text-neutral-900 text-base">Top Performing Footwear</h3>
            <p className="text-xs text-neutral-500">Highest volume shoe models</p>
          </div>
          <button
            onClick={() => onSelectTab('products')}
            className="text-xs font-bold text-amber-700 hover:underline"
          >
            Manage All Products →
          </button>
        </div>

        <div className="divide-y divide-neutral-100">
          {stats.topSellingProducts.map(prod => (
            <div key={prod.id} className="py-3.5 first:pt-0 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <img src={prod.image} alt={prod.name} className="w-12 h-12 rounded-xl object-cover" />
                <div>
                  <h4 className="font-bold text-neutral-900 text-sm">{prod.name}</h4>
                  <p className="text-xs text-neutral-500">{prod.sales} pairs sold</p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-sm font-extrabold text-neutral-900">{formatPrice(prod.revenue)}</span>
                <p className="text-[10px] text-emerald-600 font-bold uppercase">Active Sales</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
