import React, { useState, useEffect } from 'react';
import {
  Search,
  Filter,
  Eye,
  Printer,
  Package,
  Calendar,
  Truck,
  CheckCircle2,
  Clock,
  AlertCircle,
  X,
} from 'lucide-react';
import { Order, OrderStatus, PaymentStatus } from '../../types';
import { api } from '../../services/api';
import { useSettings } from '../../context/SettingsContext';
import { useToast } from '../../context/ToastContext';
import { InvoiceModal } from '../../components/common/InvoiceModal';

export const AdminOrdersPage: React.FC = () => {
  const { formatPrice } = useSettings();
  const { showToast } = useToast();

  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [paymentFilter, setPaymentFilter] = useState('all');

  // Selected Order for detail & invoice
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false);

  // Status updating state
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);

  const fetchOrders = async () => {
    setIsLoading(true);
    try {
      const res = await api.getAdminOrders();
      setOrders(res.orders || []);
    } catch (err: any) {
      showToast(err.message || 'Failed to load orders.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleUpdateStatus = async (orderId: string, orderStatus: OrderStatus, paymentStatus: PaymentStatus) => {
    setIsUpdatingStatus(true);
    try {
      const res = await api.updateAdminOrderStatus(orderId, { orderStatus, paymentStatus });
      showToast(`Order status updated to ${orderStatus}.`, 'success');
      setOrders(prev => prev.map(o => (o.id === orderId ? res.order : o)));
      if (selectedOrder && selectedOrder.id === orderId) {
        setSelectedOrder(res.order);
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to update order status.', 'error');
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const filteredOrders = orders.filter(o => {
    const s = searchQuery.toLowerCase();
    const matchesSearch =
      !searchQuery ||
      o.orderNumber.toLowerCase().includes(s) ||
      o.customerName.toLowerCase().includes(s) ||
      o.customerPhone.includes(s);

    const matchesStatus = statusFilter === 'all' || o.orderStatus === statusFilter;
    const matchesPayment = paymentFilter === 'all' || o.paymentStatus === paymentFilter;

    return matchesSearch && matchesStatus && matchesPayment;
  });

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-2xl font-extrabold text-neutral-900 tracking-tight">Orders Management</h1>
        <p className="text-xs text-neutral-500 mt-0.5">
          Process shipments, verify digital payments, and download customer tax invoices
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3 bg-white p-4 rounded-2xl border border-neutral-200/80 shadow-xs">
        <div className="relative flex-1 w-full">
          <input
            type="text"
            placeholder="Search by Order #, Customer Name, Mobile..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900 font-medium"
          />
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        <select
          value={statusFilter}
          onChange={e => setStatusFilter(e.target.value)}
          className="w-full sm:w-44 px-3 py-2 text-xs font-bold bg-neutral-50 border border-neutral-200 rounded-xl focus:outline-none cursor-pointer"
        >
          <option value="all">All Order Statuses</option>
          <option value="Pending">Pending</option>
          <option value="Confirmed">Confirmed</option>
          <option value="Processing">Processing</option>
          <option value="Packed">Packed</option>
          <option value="Shipped">Shipped</option>
          <option value="Out for Delivery">Out for Delivery</option>
          <option value="Delivered">Delivered</option>
          <option value="Cancelled">Cancelled</option>
        </select>

        <select
          value={paymentFilter}
          onChange={e => setPaymentFilter(e.target.value)}
          className="w-full sm:w-44 px-3 py-2 text-xs font-bold bg-neutral-50 border border-neutral-200 rounded-xl focus:outline-none cursor-pointer"
        >
          <option value="all">All Payment Statuses</option>
          <option value="Paid">Paid</option>
          <option value="Pending">Pending</option>
          <option value="Processing">Processing</option>
          <option value="Failed">Failed</option>
        </select>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-3xl border border-neutral-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-900 text-white uppercase text-[10px] tracking-wider font-extrabold">
              <tr>
                <th className="py-3 px-4">Order #</th>
                <th className="py-3 px-3">Date</th>
                <th className="py-3 px-3">Customer</th>
                <th className="py-3 px-3">Items</th>
                <th className="py-3 px-3 text-right">Total</th>
                <th className="py-3 px-3 text-center">Payment</th>
                <th className="py-3 px-3 text-center">Order Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 font-medium">
              {filteredOrders.map(order => (
                <tr key={order.id} className="hover:bg-neutral-50/70 transition-colors">
                  <td className="py-3 px-4">
                    <span className="font-mono font-bold text-amber-700">{order.orderNumber}</span>
                  </td>

                  <td className="py-3 px-3 text-neutral-500 whitespace-nowrap">
                    {new Date(order.createdAt).toLocaleDateString()}
                  </td>

                  <td className="py-3 px-3">
                    <p className="font-bold text-neutral-900 line-clamp-1">{order.customerName}</p>
                    <p className="text-[11px] text-neutral-500 font-mono">{order.customerPhone}</p>
                  </td>

                  <td className="py-3 px-3 text-neutral-700">
                    <span className="font-bold">{order.items.length}</span> pairs
                  </td>

                  <td className="py-3 px-3 text-right font-extrabold text-neutral-950 whitespace-nowrap">
                    {formatPrice(order.total)}
                  </td>

                  <td className="py-3 px-3 text-center">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                        order.paymentStatus === 'Paid'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {order.paymentMethod} • {order.paymentStatus}
                    </span>
                  </td>

                  <td className="py-3 px-3 text-center">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                        order.orderStatus === 'Delivered'
                          ? 'bg-emerald-100 text-emerald-800'
                          : order.orderStatus === 'Cancelled'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-indigo-100 text-indigo-800'
                      }`}
                    >
                      {order.orderStatus}
                    </span>
                  </td>

                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => setSelectedOrder(order)}
                        className="p-1.5 text-neutral-600 hover:text-black rounded-lg hover:bg-neutral-100 cursor-pointer"
                        title="View Details"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          setSelectedOrder(order);
                          setIsInvoiceOpen(true);
                        }}
                        className="p-1.5 text-neutral-600 hover:text-amber-600 rounded-lg hover:bg-neutral-100 cursor-pointer"
                        title="Print Invoice"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Complete Order Details Modal */}
      {selectedOrder && !isInvoiceOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 bg-neutral-900 text-white">
              <div>
                <h3 className="font-extrabold text-base">Order #{selectedOrder.orderNumber}</h3>
                <p className="text-xs text-neutral-400">Customer purchase and dispatch tracking</p>
              </div>
              <button onClick={() => setSelectedOrder(null)} className="p-1.5 text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-6">
              {/* Status Update Quick Bar */}
              <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-900 block">
                  Update Order & Payment Status
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-neutral-600 mb-1">
                      Order Fulfillment Status
                    </label>
                    <select
                      value={selectedOrder.orderStatus}
                      onChange={e =>
                        handleUpdateStatus(selectedOrder.id, e.target.value as OrderStatus, selectedOrder.paymentStatus)
                      }
                      disabled={isUpdatingStatus}
                      className="w-full p-2 bg-white rounded-xl border border-neutral-300 text-xs font-bold cursor-pointer"
                    >
                      <option value="Pending">Pending</option>
                      <option value="Confirmed">Confirmed</option>
                      <option value="Processing">Processing</option>
                      <option value="Packed">Packed</option>
                      <option value="Shipped">Shipped</option>
                      <option value="Out for Delivery">Out for Delivery</option>
                      <option value="Delivered">Delivered</option>
                      <option value="Cancelled">Cancelled</option>
                      <option value="Returned">Returned</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-neutral-600 mb-1">
                      Payment Verification Status
                    </label>
                    <select
                      value={selectedOrder.paymentStatus}
                      onChange={e =>
                        handleUpdateStatus(selectedOrder.id, selectedOrder.orderStatus, e.target.value as PaymentStatus)
                      }
                      disabled={isUpdatingStatus}
                      className="w-full p-2 bg-white rounded-xl border border-neutral-300 text-xs font-bold cursor-pointer"
                    >
                      <option value="Pending">Pending</option>
                      <option value="Paid">Paid</option>
                      <option value="Processing">Processing</option>
                      <option value="Failed">Failed</option>
                      <option value="Refunded">Refunded</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Items List */}
              <div className="space-y-2">
                <h4 className="font-extrabold text-neutral-900 text-xs uppercase tracking-wider">
                  Purchased Items ({selectedOrder.items.length})
                </h4>
                <div className="divide-y divide-neutral-100 border border-neutral-200 rounded-2xl p-2 bg-neutral-50/50">
                  {selectedOrder.items.map((it, idx) => (
                    <div key={idx} className="p-2 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-3">
                        <img src={it.image} alt={it.productName} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                        <div>
                          <p className="font-bold text-neutral-900">{it.productName}</p>
                          <p className="text-[11px] text-neutral-500">
                            Size: <strong>EU {it.selectedSize}</strong> • Color:{' '}
                            <strong>{it.selectedColor?.name || 'Standard'}</strong> • Qty: {it.quantity}
                          </p>
                        </div>
                      </div>
                      <span className="font-extrabold text-neutral-900">{formatPrice(it.itemTotal)}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Shipping Details */}
              <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-200 text-xs space-y-1">
                <h4 className="font-extrabold text-neutral-900 uppercase tracking-wider text-[11px] mb-1">
                  Customer Shipping Address
                </h4>
                <p className="font-bold text-neutral-900">{selectedOrder.shippingAddress.fullName}</p>
                <p className="text-neutral-600">{selectedOrder.shippingAddress.phoneNumber}</p>
                <p className="text-neutral-600">
                  {selectedOrder.shippingAddress.fullAddress}, {selectedOrder.shippingAddress.area},{' '}
                  {selectedOrder.shippingAddress.district}, {selectedOrder.shippingAddress.division}
                </p>
              </div>

              {/* Price summary */}
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-neutral-600">
                  <span>Subtotal:</span>
                  <span className="font-bold text-neutral-900">{formatPrice(selectedOrder.subtotal)}</span>
                </div>
                {selectedOrder.discount > 0 && (
                  <div className="flex justify-between text-rose-600">
                    <span>Discount:</span>
                    <span className="font-bold">-{formatPrice(selectedOrder.discount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-neutral-600">
                  <span>Shipping:</span>
                  <span className="font-bold text-neutral-900">
                    {selectedOrder.shippingFee === 0 ? 'FREE' : formatPrice(selectedOrder.shippingFee)}
                  </span>
                </div>
                <div className="pt-2 border-t-2 border-neutral-900 flex justify-between text-sm font-extrabold text-neutral-950">
                  <span>Grand Total:</span>
                  <span className="text-amber-600">{formatPrice(selectedOrder.total)}</span>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-neutral-200 bg-neutral-50 flex justify-between">
              <button
                type="button"
                onClick={() => setIsInvoiceOpen(true)}
                className="px-4 py-2 bg-white border border-neutral-300 text-neutral-800 rounded-xl text-xs font-bold uppercase flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Printer className="w-3.5 h-3.5 text-amber-600" />
                <span>Print Official Invoice</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedOrder(null)}
                className="px-6 py-2 bg-neutral-900 text-white rounded-xl text-xs font-bold uppercase cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Invoice modal */}
      {selectedOrder && (
        <InvoiceModal
          order={selectedOrder}
          isOpen={isInvoiceOpen}
          onClose={() => setIsInvoiceOpen(false)}
        />
      )}
    </div>
  );
};
