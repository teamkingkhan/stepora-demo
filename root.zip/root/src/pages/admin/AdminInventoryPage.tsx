import React, { useState, useEffect } from 'react';
import { Boxes, AlertTriangle, CheckCircle2, Edit3, X, Save } from 'lucide-react';
import { api } from '../../services/api';
import { useSettings } from '../../context/SettingsContext';
import { useToast } from '../../context/ToastContext';
import { ShoeSize } from '../../types';

export const AdminInventoryPage: React.FC = () => {
  const { formatPrice } = useSettings();
  const { showToast } = useToast();

  const [inventory, setInventory] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filterType, setFilterType] = useState<'all' | 'low' | 'out'>('all');

  // Quick Restock Modal
  const [restockProduct, setRestockProduct] = useState<any | null>(null);
  const [selectedSize, setSelectedSize] = useState<ShoeSize>('42');
  const [newStockVal, setNewStockVal] = useState('15');
  const [isSaving, setIsSaving] = useState(false);

  const fetchInventory = async () => {
    setIsLoading(true);
    try {
      const res = await api.getAdminInventory();
      setInventory(res.inventory || []);
    } catch (err: any) {
      showToast(err.message || 'Failed to load inventory stock.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchInventory();
  }, []);

  const handleSaveStock = async () => {
    if (!restockProduct) return;
    setIsSaving(true);
    try {
      await api.updateAdminInventory(restockProduct.id, selectedSize, parseInt(newStockVal) || 0);
      showToast(`Stock updated for ${restockProduct.name} (EU ${selectedSize})`, 'success');
      setRestockProduct(null);
      fetchInventory();
    } catch (err: any) {
      showToast(err.message || 'Failed to update stock.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const filtered = inventory.filter(item => {
    if (filterType === 'low') return item.isLowStock;
    if (filterType === 'out') return item.isOutOfStock;
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-neutral-900 tracking-tight">
            Inventory & Stock Control
          </h1>
          <p className="text-xs text-neutral-500 mt-0.5">
            Monitor real-time shoe sizes, low stock thresholds, and rapid restock adjustments
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
              filterType === 'all'
                ? 'bg-neutral-900 text-white'
                : 'bg-white border border-neutral-200 text-neutral-700'
            }`}
          >
            All Items ({inventory.length})
          </button>
          <button
            onClick={() => setFilterType('low')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
              filterType === 'low'
                ? 'bg-amber-500 text-black'
                : 'bg-white border border-neutral-200 text-amber-700'
            }`}
          >
            Low Stock ({inventory.filter(i => i.isLowStock).length})
          </button>
          <button
            onClick={() => setFilterType('out')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
              filterType === 'out'
                ? 'bg-rose-600 text-white'
                : 'bg-white border border-neutral-200 text-rose-600'
            }`}
          >
            Out of Stock ({inventory.filter(i => i.isOutOfStock).length})
          </button>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-neutral-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-900 text-white uppercase text-[10px] tracking-wider font-extrabold">
              <tr>
                <th className="py-3 px-4">Product / SKU</th>
                <th className="py-3 px-3">Brand</th>
                <th className="py-3 px-3 text-right">Unit Price</th>
                <th className="py-3 px-3 text-center">Total Stock</th>
                <th className="py-3 px-3">Size Breakdown</th>
                <th className="py-3 px-3 text-center">Alert Status</th>
                <th className="py-3 px-4 text-right">Quick Restock</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 font-medium">
              {filtered.map(item => (
                <tr key={item.id} className="hover:bg-neutral-50/70 transition-colors">
                  <td className="py-3 px-4">
                    <p className="font-bold text-neutral-900 text-sm">{item.name}</p>
                    <p className="text-[11px] font-mono text-neutral-400">SKU: {item.sku}</p>
                  </td>

                  <td className="py-3 px-3 text-neutral-600 font-semibold">{item.brand}</td>

                  <td className="py-3 px-3 text-right font-extrabold text-neutral-900">
                    {formatPrice(item.salePrice || item.price)}
                  </td>

                  <td className="py-3 px-3 text-center font-black text-sm">
                    {item.stockQuantity} pairs
                  </td>

                  <td className="py-3 px-3">
                    <div className="flex flex-wrap gap-1 max-w-xs">
                      {item.sizeStock?.map((s: any) => (
                        <span
                          key={s.size}
                          className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            s.stock === 0
                              ? 'bg-rose-100 text-rose-800'
                              : s.stock <= 3
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-neutral-100 text-neutral-700'
                          }`}
                        >
                          EU {s.size}: {s.stock}
                        </span>
                      ))}
                    </div>
                  </td>

                  <td className="py-3 px-3 text-center">
                    {item.isOutOfStock ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-extrabold uppercase text-rose-600 bg-rose-50 px-2.5 py-0.5 rounded-full">
                        <AlertTriangle className="w-3 h-3" />
                        Out of Stock
                      </span>
                    ) : item.isLowStock ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-extrabold uppercase text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full">
                        <AlertTriangle className="w-3 h-3" />
                        Low Stock
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold uppercase text-emerald-600">
                        Healthy Stock
                      </span>
                    )}
                  </td>

                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => {
                        setRestockProduct(item);
                        setSelectedSize(item.sizeStock?.[0]?.size || '42');
                      }}
                      className="px-3 py-1.5 bg-neutral-900 hover:bg-black text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                    >
                      Restock
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Restock Modal */}
      {restockProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-neutral-100 pb-3">
              <div>
                <h3 className="font-extrabold text-base text-neutral-900">Restock Footwear</h3>
                <p className="text-xs text-neutral-400">{restockProduct.name}</p>
              </div>
              <button onClick={() => setRestockProduct(null)} className="p-1 text-neutral-400 hover:text-black">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-neutral-600 uppercase mb-1">Select Size</label>
                <select
                  value={selectedSize}
                  onChange={e => setSelectedSize(e.target.value as ShoeSize)}
                  className="w-full px-3.5 py-2 text-sm font-bold bg-neutral-50 border border-neutral-300 rounded-xl cursor-pointer"
                >
                  {restockProduct.sizeStock?.map((s: any) => (
                    <option key={s.size} value={s.size}>
                      EU {s.size} (Current: {s.stock} pairs)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-neutral-600 uppercase mb-1">
                  New Stock Count for Size EU {selectedSize}
                </label>
                <input
                  type="number"
                  value={newStockVal}
                  onChange={e => setNewStockVal(e.target.value)}
                  className="w-full px-3.5 py-2 text-base font-bold bg-neutral-50 border border-neutral-300 rounded-xl"
                  required
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setRestockProduct(null)}
                  className="px-4 py-2 border border-neutral-300 rounded-xl font-bold uppercase text-neutral-700"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isSaving}
                  onClick={handleSaveStock}
                  className="px-5 py-2 bg-neutral-900 hover:bg-black text-white rounded-xl font-bold uppercase tracking-wider"
                >
                  {isSaving ? 'Updating...' : 'Save Stock'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
