import React, { useState, useEffect } from 'react';
import {
  PlusCircle,
  Search,
  Edit2,
  Trash2,
  Copy,
  ExternalLink,
  Package,
  CheckCircle2,
  XCircle,
  AlertTriangle,
} from 'lucide-react';
import { Product } from '../../types';
import { api } from '../../services/api';
import { useSettings } from '../../context/SettingsContext';
import { useToast } from '../../context/ToastContext';
import { AdminProductFormModal } from './AdminProductFormModal';

interface AdminProductsPageProps {
  onOpenCreate?: boolean;
}

export const AdminProductsPage: React.FC<AdminProductsPageProps> = ({ onOpenCreate = false }) => {
  const { formatPrice } = useSettings();
  const { showToast } = useToast();

  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(onOpenCreate);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Delete Confirm State
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const fetchProducts = async () => {
    setIsLoading(true);
    try {
      const res = await api.getAdminProducts();
      setProducts(res.products || []);
    } catch (err: any) {
      showToast(err.message || 'Failed to load products.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleCreateOrUpdate = async (productData: any) => {
    if (editingProduct) {
      const res = await api.updateAdminProduct(editingProduct.id, productData);
      showToast('Product updated successfully!', 'success');
      setProducts(prev => prev.map(p => (p.id === editingProduct.id ? res.product : p)));
    } else {
      const res = await api.createAdminProduct(productData);
      showToast('Product created successfully!', 'success');
      setProducts(prev => [res.product, ...prev]);
    }
  };

  const handleDuplicate = async (product: Product) => {
    try {
      const res = await api.duplicateAdminProduct(product.id);
      showToast(`Duplicated ${product.name}!`, 'success');
      setProducts(prev => [res.product, ...prev]);
    } catch (err: any) {
      showToast(err.message || 'Failed to duplicate product.', 'error');
    }
  };

  const confirmDelete = async () => {
    if (!productToDelete) return;
    setIsDeleting(true);
    try {
      await api.deleteAdminProduct(productToDelete.id);
      showToast(`Deleted ${productToDelete.name}.`, 'info');
      setProducts(prev => prev.filter(p => p.id !== productToDelete.id));
      setProductToDelete(null);
    } catch (err: any) {
      showToast(err.message || 'Failed to delete product.', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  const filteredProducts = products.filter(p => {
    const matchesSearch =
      !searchQuery ||
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.brand.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'all' || p.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="space-y-6">
      {/* Page Title & Add Button */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-neutral-900 tracking-tight">Product Catalog</h1>
          <p className="text-xs text-neutral-500 mt-0.5">
            Manage styles, images, multi-size stock, and live store status
          </p>
        </div>
        <button
          onClick={() => {
            setEditingProduct(null);
            setIsModalOpen(true);
          }}
          className="flex items-center gap-2 px-5 py-2.5 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wider shadow-md transition-colors cursor-pointer w-fit"
        >
          <PlusCircle className="w-4 h-4 text-amber-400" />
          <span>Add New Footwear</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3 bg-white p-4 rounded-2xl border border-neutral-200/80 shadow-xs">
        <div className="relative flex-1 w-full">
          <input
            type="text"
            placeholder="Search by name, SKU, brand..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900"
          />
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        <select
          value={selectedCategory}
          onChange={e => setSelectedCategory(e.target.value)}
          className="w-full sm:w-48 px-3 py-2 text-xs font-bold bg-neutral-50 border border-neutral-200 rounded-xl focus:outline-none focus:border-neutral-900 cursor-pointer"
        >
          <option value="all">All Categories</option>
          <option value="sneakers">Sneakers</option>
          <option value="men">Men's Shoes</option>
          <option value="women">Women's Shoes</option>
          <option value="sports">Sports & Running</option>
          <option value="formal">Formal Leather</option>
          <option value="casual">Casual & Loafers</option>
          <option value="boots">Boots</option>
          <option value="sandals">Sandals</option>
          <option value="kids">Kids' Shoes</option>
        </select>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-3xl border border-neutral-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-900 text-white uppercase text-[10px] tracking-wider font-extrabold">
              <tr>
                <th className="py-3 px-4">Footwear</th>
                <th className="py-3 px-3">SKU</th>
                <th className="py-3 px-3">Category</th>
                <th className="py-3 px-3 text-right">Price</th>
                <th className="py-3 px-3 text-center">Stock</th>
                <th className="py-3 px-3">Sizes</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 font-medium">
              {filteredProducts.map(p => {
                const isLow = p.stockQuantity > 0 && p.stockQuantity <= 5;
                const isOut = p.stockQuantity === 0;

                return (
                  <tr key={p.id} className="hover:bg-neutral-50/70 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={p.mainImage}
                          alt={p.name}
                          className="w-12 h-12 rounded-xl object-cover bg-neutral-100 shrink-0"
                        />
                        <div>
                          <p className="font-bold text-neutral-900 text-sm line-clamp-1">{p.name}</p>
                          <p className="text-[11px] text-neutral-500 font-semibold">{p.brand}</p>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-3 font-mono font-bold text-neutral-600">{p.sku}</td>

                    <td className="py-3 px-3 capitalize text-neutral-700 font-semibold">
                      {p.category}
                    </td>

                    <td className="py-3 px-3 text-right">
                      <span className="font-extrabold text-neutral-900">{formatPrice(p.salePrice || p.price)}</span>
                      {p.salePrice < p.price && (
                        <p className="text-[10px] text-neutral-400 line-through">{formatPrice(p.price)}</p>
                      )}
                    </td>

                    <td className="py-3 px-3 text-center">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                          isOut
                            ? 'bg-rose-100 text-rose-800'
                            : isLow
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {p.stockQuantity} pairs
                      </span>
                    </td>

                    <td className="py-3 px-3 text-neutral-600">
                      <div className="flex flex-wrap gap-1 max-w-[150px]">
                        {p.availableSizes.slice(0, 4).map(sz => (
                          <span key={sz} className="px-1.5 py-0.5 bg-neutral-100 rounded text-[10px] font-bold">
                            {sz}
                          </span>
                        ))}
                        {p.availableSizes.length > 4 && (
                          <span className="text-[10px] text-neutral-400 font-bold">
                            +{p.availableSizes.length - 4}
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="py-3 px-3 text-center">
                      {p.isActive ? (
                        <span className="text-emerald-600 font-bold text-[10px] uppercase">Active</span>
                      ) : (
                        <span className="text-neutral-400 font-bold text-[10px] uppercase">Draft</span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setEditingProduct(p);
                            setIsModalOpen(true);
                          }}
                          className="p-1.5 text-neutral-600 hover:text-black rounded-lg hover:bg-neutral-100 cursor-pointer"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDuplicate(p)}
                          className="p-1.5 text-neutral-600 hover:text-amber-600 rounded-lg hover:bg-neutral-100 cursor-pointer"
                          title="Duplicate"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setProductToDelete(p)}
                          className="p-1.5 text-neutral-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 cursor-pointer"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create / Edit Modal */}
      <AdminProductFormModal
        isOpen={isModalOpen}
        product={editingProduct}
        onClose={() => {
          setIsModalOpen(false);
          setEditingProduct(null);
        }}
        onSave={handleCreateOrUpdate}
      />

      {/* Delete Confirmation Dialog (Section 17) */}
      {productToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="max-w-md w-full bg-white rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-extrabold text-neutral-900 text-lg">
                Are you sure you want to delete this product?
              </h3>
              <p className="text-xs text-neutral-500 font-medium">
                "{productToDelete.name}" (SKU: {productToDelete.sku}) will be permanently removed from the storefront.
              </p>
            </div>
            <div className="pt-2 flex gap-2">
              <button
                type="button"
                onClick={() => setProductToDelete(null)}
                className="w-1/2 py-2.5 border border-neutral-300 rounded-xl text-xs font-bold uppercase text-neutral-700 hover:bg-neutral-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={confirmDelete}
                className="w-1/2 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer shadow-md"
              >
                {isDeleting ? 'Deleting...' : 'Yes, Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
