import React, { useState, useEffect } from 'react';
import { Search, UserCheck, UserX, ShoppingBag, Mail, Phone, Calendar } from 'lucide-react';
import { api } from '../../services/api';
import { useSettings } from '../../context/SettingsContext';
import { useToast } from '../../context/ToastContext';

export const AdminCustomersPage: React.FC = () => {
  const { formatPrice } = useSettings();
  const { showToast } = useToast();
  const [customers, setCustomers] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');

  const fetchCustomers = async () => {
    setIsLoading(true);
    try {
      const res = await api.getAdminCustomers();
      setCustomers(res.customers || []);
    } catch (err: any) {
      showToast(err.message || 'Failed to load customer list.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, []);

  const handleToggleStatus = async (customer: any) => {
    const nextStatus = !customer.isActive;
    try {
      await api.updateCustomerStatus(customer.id, nextStatus);
      showToast(`Account status updated for ${customer.fullName}.`, 'info');
      setCustomers(prev =>
        prev.map(c => (c.id === customer.id ? { ...c, isActive: nextStatus } : c))
      );
    } catch (err: any) {
      showToast(err.message || 'Status update failed.', 'error');
    }
  };

  const filtered = customers.filter(c => {
    const s = search.toLowerCase();
    return (
      !search ||
      c.fullName.toLowerCase().includes(s) ||
      c.email.toLowerCase().includes(s) ||
      (c.phoneNumber && c.phoneNumber.includes(s))
    );
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-neutral-900 tracking-tight">Customer Directory</h1>
        <p className="text-xs text-neutral-500 mt-0.5">
          View registered customer accounts, total shoe orders, and account status
        </p>
      </div>

      <div className="bg-white p-4 rounded-2xl border border-neutral-200/80 shadow-xs max-w-md">
        <div className="relative">
          <input
            type="text"
            placeholder="Search by customer name, email, phone..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900 font-medium"
          />
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-neutral-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-900 text-white uppercase text-[10px] tracking-wider font-extrabold">
              <tr>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-3">Contact</th>
                <th className="py-3 px-3 text-center">Orders</th>
                <th className="py-3 px-3 text-right">Lifetime Spend</th>
                <th className="py-3 px-3">Registered</th>
                <th className="py-3 px-3 text-center">Account Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 font-medium">
              {filtered.map(cust => (
                <tr key={cust.id} className="hover:bg-neutral-50/70 transition-colors">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-neutral-900 text-white font-bold flex items-center justify-center text-xs">
                        {cust.fullName.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-neutral-900 text-sm">{cust.fullName}</p>
                        <p className="text-[11px] text-neutral-400">ID: {cust.id.slice(-6)}</p>
                      </div>
                    </div>
                  </td>

                  <td className="py-3 px-3 text-neutral-600">
                    <p className="font-medium">{cust.email}</p>
                    <p className="text-[11px] font-mono text-neutral-500">{cust.phoneNumber || 'N/A'}</p>
                  </td>

                  <td className="py-3 px-3 text-center font-bold text-neutral-900">
                    {cust.ordersCount || 0}
                  </td>

                  <td className="py-3 px-3 text-right font-extrabold text-neutral-950">
                    {formatPrice(cust.totalSpent || 0)}
                  </td>

                  <td className="py-3 px-3 text-neutral-500">
                    {new Date(cust.createdAt).toLocaleDateString()}
                  </td>

                  <td className="py-3 px-3 text-center">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                        cust.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {cust.isActive ? 'Active' : 'Suspended'}
                    </span>
                  </td>

                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => handleToggleStatus(cust)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                        cust.isActive
                          ? 'border border-rose-200 text-rose-600 hover:bg-rose-50'
                          : 'border border-emerald-200 text-emerald-600 hover:bg-emerald-50'
                      }`}
                    >
                      {cust.isActive ? 'Suspend' : 'Activate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
