import React, { useState } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  Lock,
  Truck,
  ArrowRight,
  ChevronLeft,
  Package,
  AlertCircle,
  CreditCard,
  Wallet,
  Coins,
} from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import { useSettings } from '../../context/SettingsContext';
import { useToast } from '../../context/ToastContext';
import { api } from '../../services/api';
import { Order, PaymentMethod } from '../../types';
import { PaymentModal } from '../../components/common/PaymentModal';

interface CheckoutPageProps {
  onNavigate: (page: string, params?: any) => void;
}

const BD_DIVISIONS = [
  'Dhaka',
  'Chittagong',
  'Sylhet',
  'Rajshahi',
  'Khulna',
  'Barishal',
  'Rangpur',
  'Mymensingh',
];

export const CheckoutPage: React.FC<CheckoutPageProps> = ({ onNavigate }) => {
  const { cart, subtotal, couponCode, couponDiscount, shippingFee, shippingRegion, setShippingRegion, grandTotal, clearCart } = useCart();
  const { user } = useAuth();
  const { settings, formatPrice } = useSettings();
  const { showToast } = useToast();

  const [currentStep, setCurrentStep] = useState<number>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Active payment gateway modal state
  const [pendingOrderForPayment, setPendingOrderForPayment] = useState<Order | null>(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);

  // Form Fields
  const [fullName, setFullName] = useState(user?.fullName || '');
  const [phoneNumber, setPhoneNumber] = useState(user?.phoneNumber || '');
  const [email, setEmail] = useState(user?.email || '');
  const [division, setDivision] = useState('Dhaka');
  const [district, setDistrict] = useState('Dhaka');
  const [area, setArea] = useState('');
  const [fullAddress, setFullAddress] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cod');

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold text-neutral-900">Your Cart is Empty</h2>
        <p className="text-neutral-500 mt-2 text-sm">Please add shoes to your cart before proceeding to checkout.</p>
        <button
          onClick={() => onNavigate('shop')}
          className="mt-6 px-6 py-3 bg-neutral-900 text-white rounded-xl font-bold text-xs uppercase tracking-wider"
        >
          Return to Shop
        </button>
      </div>
    );
  }

  // Update shipping region automatically when division changes
  const handleDivisionChange = (div: string) => {
    setDivision(div);
    if (div === 'Dhaka') {
      setShippingRegion('inside_dhaka');
      setDistrict('Dhaka');
    } else {
      setShippingRegion('outside_dhaka');
      setDistrict(div);
    }
  };

  const validateStep1 = () => {
    if (!fullName.trim() || !phoneNumber.trim()) {
      setErrorMessage('Full name and mobile number are required.');
      return false;
    }
    // BD phone validation (e.g. 01XXXXXXXXX)
    const cleanPhone = phoneNumber.replace(/\s+/g, '');
    if (!/^01[3-9]\d{8}$/.test(cleanPhone)) {
      setErrorMessage('Please enter a valid 11-digit Bangladeshi mobile number (e.g. 017XXXXXXXX).');
      return false;
    }
    setErrorMessage(null);
    return true;
  };

  const validateStep2 = () => {
    if (!fullAddress.trim() || !area.trim()) {
      setErrorMessage('Please provide your complete street address and area.');
      return false;
    }
    setErrorMessage(null);
    return true;
  };

  const handleNextStep = () => {
    if (currentStep === 1 && !validateStep1()) return;
    if (currentStep === 2 && !validateStep2()) return;
    setCurrentStep(prev => prev + 1);
  };

  const handlePlaceOrder = async () => {
    if (!validateStep1() || !validateStep2()) return;

    setIsSubmitting(true);
    setErrorMessage(null);

    const orderPayload = {
      customerId: user?.id,
      shippingRegion,
      couponCode: couponDiscount > 0 ? couponCode : undefined,
      paymentMethod,
      shippingAddress: {
        fullName: fullName.trim(),
        phoneNumber: phoneNumber.trim(),
        email: email.trim(),
        division,
        district,
        area: area.trim(),
        fullAddress: fullAddress.trim(),
        postalCode: postalCode.trim(),
        notes: notes.trim(),
      },
      items: cart.map(it => ({
        productId: it.productId,
        productName: it.name,
        sku: it.productId,
        image: it.image,
        price: it.salePrice || it.price,
        quantity: it.quantity,
        selectedSize: it.selectedSize,
        selectedColor: it.selectedColor,
      })),
    };

    try {
      const res = await api.createOrder(orderPayload);
      const createdOrder = res.order;

      if (paymentMethod === 'cod') {
        // COD order is immediately confirmed
        clearCart();
        showToast(`Order #${createdOrder.orderNumber} placed successfully!`, 'success');
        onNavigate('order-success', { orderId: createdOrder.id });
      } else {
        // bKash, Nagad, or Card: trigger interactive sandbox payment gateway
        setPendingOrderForPayment(createdOrder);
        setIsPaymentModalOpen(true);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to place order. Please review your details.');
      showToast(err.message || 'Order creation failed.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePaymentSuccess = (paidOrder: Order) => {
    setIsPaymentModalOpen(false);
    clearCart();
    showToast('Payment verified successfully!', 'success');
    onNavigate('order-success', { orderId: paidOrder.id });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Checkout Header */}
      <div className="flex items-center justify-between border-b border-neutral-200 pb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight">
            Checkout
          </h1>
          <p className="text-xs text-neutral-500 mt-0.5">Complete your footwear purchase</p>
        </div>
        <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-200">
          <Lock className="w-3.5 h-3.5 text-emerald-600" />
          <span>SSL Secured</span>
        </div>
      </div>

      {/* Steps Indicator */}
      <div className="grid grid-cols-4 gap-2 text-xs font-bold">
        {[
          { step: 1, label: 'Contact' },
          { step: 2, label: 'Address' },
          { step: 3, label: 'Delivery' },
          { step: 4, label: 'Payment' },
        ].map(s => (
          <div
            key={s.step}
            className={`p-3 rounded-2xl border text-center transition-all ${
              currentStep === s.step
                ? 'bg-neutral-900 text-white border-neutral-900 shadow-sm'
                : currentStep > s.step
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                : 'bg-white text-neutral-400 border-neutral-200'
            }`}
          >
            <div className="text-[10px] uppercase tracking-wider opacity-80">Step {s.step}</div>
            <div className="font-extrabold text-xs sm:text-sm mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {errorMessage && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-rose-700 text-xs font-medium flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        {/* Step Forms */}
        <div className="lg:col-span-2 space-y-6">
          {/* STEP 1: Customer Contact Info */}
          {currentStep === 1 && (
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-5 animate-in fade-in">
              <h2 className="text-lg font-extrabold text-neutral-900 flex items-center gap-2">
                <span>1. Customer & Contact Information</span>
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                    Full Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={e => setFullName(e.target.value)}
                    placeholder="e.g. Kazi Farhan Ahmed"
                    className="w-full px-4 py-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900 font-medium"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                    Mobile Number (Bangladesh) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    value={phoneNumber}
                    onChange={e => setPhoneNumber(e.target.value)}
                    placeholder="017XXXXXXXX"
                    className="w-full px-4 py-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900 font-mono font-bold"
                    required
                  />
                  <p className="text-[11px] text-neutral-400 mt-1">Delivery rider will call this number</p>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                  Email Address (for Invoice & Tracking)
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="e.g. farhan@example.com"
                  className="w-full px-4 py-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900 font-medium"
                />
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  type="button"
                  onClick={handleNextStep}
                  className="px-8 py-3.5 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer shadow-md"
                >
                  <span>Continue to Shipping Address</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Shipping Address */}
          {currentStep === 2 && (
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-5 animate-in fade-in">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-extrabold text-neutral-900">
                  2. Shipping Address in Bangladesh
                </h2>
                <button
                  type="button"
                  onClick={() => setCurrentStep(1)}
                  className="text-xs text-neutral-500 hover:text-black font-semibold cursor-pointer"
                >
                  ← Edit Contact
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                    Division <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={division}
                    onChange={e => handleDivisionChange(e.target.value)}
                    className="w-full px-4 py-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900 font-bold cursor-pointer"
                  >
                    {BD_DIVISIONS.map(div => (
                      <option key={div} value={div}>
                        {div} Division
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                    District / City <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={district}
                    onChange={e => setDistrict(e.target.value)}
                    placeholder="e.g. Dhaka, Gazipur, Narayanganj"
                    className="w-full px-4 py-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900 font-medium"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                    Thana / Area <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={area}
                    onChange={e => setArea(e.target.value)}
                    placeholder="e.g. Banani, Dhanmondi, Agrabad"
                    className="w-full px-4 py-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900 font-medium"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                    Postal Code (Optional)
                  </label>
                  <input
                    type="text"
                    value={postalCode}
                    onChange={e => setPostalCode(e.target.value)}
                    placeholder="e.g. 1213"
                    className="w-full px-4 py-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                  Full Street Address (House, Road, Flat No.) <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={2}
                  value={fullAddress}
                  onChange={e => setFullAddress(e.target.value)}
                  placeholder="e.g. House 42, Road 11, Block D, Flat 4B"
                  className="w-full px-4 py-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900 font-medium"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                  Delivery Notes / Landmark (Optional)
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="e.g. Beside Prime Bank ATM, call upon arrival"
                  className="w-full px-4 py-2.5 text-xs bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900"
                />
              </div>

              <div className="pt-4 flex justify-between">
                <button
                  type="button"
                  onClick={() => setCurrentStep(1)}
                  className="px-6 py-3 border border-neutral-300 rounded-xl text-xs font-bold uppercase text-neutral-700 hover:bg-neutral-50"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={handleNextStep}
                  className="px-8 py-3.5 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer shadow-md"
                >
                  <span>Continue to Delivery Method</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Delivery Options */}
          {currentStep === 3 && (
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-5 animate-in fade-in">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-extrabold text-neutral-900">
                  3. Select Delivery Method
                </h2>
                <button
                  type="button"
                  onClick={() => setCurrentStep(2)}
                  className="text-xs text-neutral-500 hover:text-black font-semibold cursor-pointer"
                >
                  ← Edit Address
                </button>
              </div>

              <div className="space-y-3">
                <label
                  onClick={() => setShippingRegion('inside_dhaka')}
                  className={`flex items-center justify-between p-4 rounded-2xl border-2 transition-all cursor-pointer ${
                    shippingRegion === 'inside_dhaka'
                      ? 'border-neutral-900 bg-neutral-50 shadow-xs'
                      : 'border-neutral-200 hover:border-neutral-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="shippingRegion"
                      checked={shippingRegion === 'inside_dhaka'}
                      onChange={() => setShippingRegion('inside_dhaka')}
                      className="w-4 h-4 text-neutral-900"
                    />
                    <div>
                      <p className="font-bold text-neutral-900 text-sm">Inside Dhaka Metro (24-48 Hours)</p>
                      <p className="text-xs text-neutral-500">Fast doorstep courier delivery via Pathao / SteadFast</p>
                    </div>
                  </div>
                  <span className="font-extrabold text-sm text-neutral-900">
                    {subtotal >= settings.freeShippingThreshold ? 'FREE' : formatPrice(settings.insideDhakaShippingFee)}
                  </span>
                </label>

                <label
                  onClick={() => setShippingRegion('outside_dhaka')}
                  className={`flex items-center justify-between p-4 rounded-2xl border-2 transition-all cursor-pointer ${
                    shippingRegion === 'outside_dhaka'
                      ? 'border-neutral-900 bg-neutral-50 shadow-xs'
                      : 'border-neutral-200 hover:border-neutral-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="shippingRegion"
                      checked={shippingRegion === 'outside_dhaka'}
                      onChange={() => setShippingRegion('outside_dhaka')}
                      className="w-4 h-4 text-neutral-900"
                    />
                    <div>
                      <p className="font-bold text-neutral-900 text-sm">Outside Dhaka Nationwide (2-4 Days)</p>
                      <p className="text-xs text-neutral-500">Safe doorstep delivery across all 64 districts</p>
                    </div>
                  </div>
                  <span className="font-extrabold text-sm text-neutral-900">
                    {subtotal >= settings.freeShippingThreshold ? 'FREE' : formatPrice(settings.outsideDhakaShippingFee)}
                  </span>
                </label>
              </div>

              <div className="pt-4 flex justify-between">
                <button
                  type="button"
                  onClick={() => setCurrentStep(2)}
                  className="px-6 py-3 border border-neutral-300 rounded-xl text-xs font-bold uppercase text-neutral-700 hover:bg-neutral-50"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={handleNextStep}
                  className="px-8 py-3.5 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer shadow-md"
                >
                  <span>Continue to Payment</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: Payment Method & Place Order */}
          {currentStep === 4 && (
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-6 animate-in fade-in">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-extrabold text-neutral-900">
                  4. Payment Options (Bangladesh)
                </h2>
                <button
                  type="button"
                  onClick={() => setCurrentStep(3)}
                  className="text-xs text-neutral-500 hover:text-black font-semibold cursor-pointer"
                >
                  ← Edit Delivery
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Cash on Delivery */}
                <label
                  onClick={() => setPaymentMethod('cod')}
                  className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                    paymentMethod === 'cod'
                      ? 'border-emerald-600 bg-emerald-50/50 shadow-xs'
                      : 'border-neutral-200 hover:border-neutral-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
                      <Coins className="w-5 h-5" />
                    </div>
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={paymentMethod === 'cod'}
                      onChange={() => setPaymentMethod('cod')}
                      className="w-4 h-4 text-emerald-600"
                    />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-neutral-900 text-sm">Cash on Delivery</h4>
                    <p className="text-[11px] text-neutral-500 mt-0.5">
                      Pay in cash when rider delivers shoes to your doorstep.
                    </p>
                  </div>
                </label>

                {/* bKash */}
                <label
                  onClick={() => setPaymentMethod('bkash')}
                  className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                    paymentMethod === 'bkash'
                      ? 'border-[#E2136E] bg-pink-50/50 shadow-xs'
                      : 'border-neutral-200 hover:border-neutral-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="px-2.5 py-1 rounded-lg bg-[#E2136E] text-white font-black text-xs">
                      bKash
                    </div>
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={paymentMethod === 'bkash'}
                      onChange={() => setPaymentMethod('bkash')}
                      className="w-4 h-4 text-[#E2136E]"
                    />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-neutral-900 text-sm">bKash Online Payment</h4>
                    <p className="text-[11px] text-neutral-500 mt-0.5">
                      Instant mobile wallet payment (Sandbox / Demo active).
                    </p>
                  </div>
                </label>

                {/* Nagad */}
                <label
                  onClick={() => setPaymentMethod('nagad')}
                  className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                    paymentMethod === 'nagad'
                      ? 'border-[#F26522] bg-orange-50/50 shadow-xs'
                      : 'border-neutral-200 hover:border-neutral-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="px-2.5 py-1 rounded-lg bg-[#F26522] text-white font-black text-xs">
                      Nagad
                    </div>
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={paymentMethod === 'nagad'}
                      onChange={() => setPaymentMethod('nagad')}
                      className="w-4 h-4 text-[#F26522]"
                    />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-neutral-900 text-sm">Nagad Payment</h4>
                    <p className="text-[11px] text-neutral-500 mt-0.5">
                      Bangladesh Post Office digital wallet gateway.
                    </p>
                  </div>
                </label>

                {/* Credit / Debit Card */}
                <label
                  onClick={() => setPaymentMethod('card')}
                  className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                    paymentMethod === 'card'
                      ? 'border-neutral-900 bg-neutral-50 shadow-xs'
                      : 'border-neutral-200 hover:border-neutral-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="p-2 rounded-xl bg-neutral-900 text-white">
                      <CreditCard className="w-5 h-5" />
                    </div>
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={paymentMethod === 'card'}
                      onChange={() => setPaymentMethod('card')}
                      className="w-4 h-4 text-neutral-900"
                    />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-neutral-900 text-sm">Credit / Debit Card</h4>
                    <p className="text-[11px] text-neutral-500 mt-0.5">
                      Visa, Mastercard, American Express via secure gateway.
                    </p>
                  </div>
                </label>
              </div>

              {/* Order Placement Action */}
              <div className="pt-4 border-t border-neutral-100 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setCurrentStep(3)}
                  className="px-6 py-3 border border-neutral-300 rounded-xl text-xs font-bold uppercase text-neutral-700 hover:bg-neutral-50 cursor-pointer"
                >
                  Back
                </button>

                <button
                  type="button"
                  disabled={isSubmitting}
                  onClick={handlePlaceOrder}
                  className="px-8 py-4 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-extrabold text-sm uppercase tracking-wider rounded-2xl shadow-xl hover:shadow-amber-500/20 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <span>{isSubmitting ? 'Processing Order...' : `Place Order (${formatPrice(grandTotal)})`}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Order Summary Sidebar */}
        <div className="bg-white p-6 rounded-3xl border border-neutral-200/80 shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
            <h3 className="font-extrabold text-neutral-900 text-sm uppercase tracking-wider">
              Order Items ({cart.length})
            </h3>
            <button
              onClick={() => onNavigate('cart')}
              className="text-xs text-amber-600 font-bold hover:underline"
            >
              Edit Cart
            </button>
          </div>

          <div className="divide-y divide-neutral-100 max-h-72 overflow-y-auto space-y-3">
            {cart.map(item => (
              <div key={item.id} className="pt-3 first:pt-0 flex items-center gap-3">
                <img src={item.image} alt={item.name} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-neutral-900 truncate">{item.name}</p>
                  <p className="text-[11px] text-neutral-500">
                    EU {item.selectedSize} • {item.selectedColor?.name} × {item.quantity}
                  </p>
                  <p className="text-xs font-bold text-neutral-900">
                    {formatPrice((item.salePrice || item.price) * item.quantity)}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-neutral-100 space-y-2 text-xs">
            <div className="flex justify-between text-neutral-600">
              <span>Subtotal:</span>
              <span className="font-semibold text-neutral-900">{formatPrice(subtotal)}</span>
            </div>
            {couponDiscount > 0 && (
              <div className="flex justify-between text-rose-600">
                <span>Coupon Discount ({couponCode}):</span>
                <span className="font-bold">-{formatPrice(couponDiscount)}</span>
              </div>
            )}
            <div className="flex justify-between text-neutral-600">
              <span>Shipping ({shippingRegion === 'inside_dhaka' ? 'Dhaka' : 'Outside Dhaka'}):</span>
              <span className="font-semibold text-neutral-900">
                {shippingFee === 0 ? <strong className="text-emerald-600 uppercase">FREE</strong> : formatPrice(shippingFee)}
              </span>
            </div>
            <div className="pt-2 border-t-2 border-neutral-900 flex justify-between text-base font-extrabold text-neutral-950">
              <span>Total Payable:</span>
              <span className="text-amber-600">{formatPrice(grandTotal)}</span>
            </div>
          </div>

          <div className="p-3 bg-neutral-50 rounded-xl text-[11px] text-neutral-500 space-y-1">
            <p className="font-bold text-neutral-800">Delivery Guarantee:</p>
            <p>Inspect shoe size upon delivery. If size needs replacement, rider will provide doorstep return.</p>
          </div>
        </div>
      </div>

      {/* Payment Gateway Modal (for bKash / Nagad / Card) */}
      {pendingOrderForPayment && (
        <PaymentModal
          order={pendingOrderForPayment}
          isOpen={isPaymentModalOpen}
          onSuccess={handlePaymentSuccess}
          onCancel={() => {
            setIsPaymentModalOpen(false);
            showToast('Order saved as Pending. You can complete payment anytime from My Orders.', 'info');
            onNavigate('order-success', { orderId: pendingOrderForPayment.id });
          }}
        />
      )}
    </div>
  );
};
