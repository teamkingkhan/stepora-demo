import React, { useState, useEffect } from 'react';
import { ChevronRight, ArrowRight } from 'lucide-react';
import { Category } from '../../types';
import { api } from '../../services/api';

interface CategoriesPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const CategoriesPage: React.FC<CategoriesPageProps> = ({ onNavigate }) => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    api
      .getCategories()
      .then(res => setCategories(res.categories || []))
      .finally(() => setIsLoading(false));
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-neutral-400 font-medium">
        <button onClick={() => onNavigate('home')} className="hover:text-black cursor-pointer">
          Home
        </button>
        <span>/</span>
        <span className="text-neutral-900 font-bold">Categories</span>
      </div>

      <div className="max-w-2xl">
        <span className="text-xs font-bold uppercase tracking-widest text-amber-600">The STEPORA Catalog</span>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-neutral-900 tracking-tight mt-1">
          Browse by Shoe Category
        </h1>
        <p className="text-neutral-500 text-sm mt-2">
          From competition marathon spikes to artisanal Goodyear-welted oxfords, discover footwear curated for every facet of your lifestyle.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map(cat => (
          <div
            key={cat.id}
            onClick={() => onNavigate('shop', { category: cat.slug })}
            className="group relative rounded-3xl overflow-hidden aspect-4/3 bg-neutral-900 text-white cursor-pointer shadow-md hover:shadow-2xl transition-all duration-300"
          >
            <img
              src={cat.image}
              alt={cat.name}
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/40 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-6 flex flex-col justify-end">
              <span className="text-[11px] font-extrabold uppercase tracking-widest text-amber-400">
                {cat.itemCount} Designs Available
              </span>
              <h3 className="text-2xl font-extrabold text-white mt-1 group-hover:text-amber-200 transition-colors">
                {cat.name}
              </h3>
              <p className="text-xs text-neutral-300 mt-1 line-clamp-2">{cat.description}</p>
              <div className="mt-4 flex items-center gap-2 text-xs font-bold text-white group-hover:translate-x-1 transition-transform">
                <span>View Collection</span>
                <ArrowRight className="w-4 h-4 text-amber-400" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
