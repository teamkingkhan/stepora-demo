import React, { useState } from 'react';
import {
  Trash2,
  Plus,
  Minus,
  ArrowRight,
  ShoppingBag,
  ShieldCheck,
  Tag,
  Check,
  X,
  Truck,
  RotateCcw,
} from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { useSettings } from '../../context/SettingsContext';
import { ShoeSize } from '../../types';

interface CartPageProps {
  onNavigate: (page: string, params?: any) => void;
}

const ALL_SIZES: ShoeSize[] = ['36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46'];

export const CartPage: React.FC<CartPageProps> = ({ onNavigate }) => {
  const {
    cart,
    removeFromCart,
    updateQuantity,
    updateItemSize,
    clearCart,
    subtotal,
    shippingRegion,
    setShippingRegion,
    shippingFee,
    couponCode,
    couponDiscount,
    couponError,
    isApplyingCoupon,
    applyCoupon,
    removeCoupon,
    grandTotal,
  } = useCart();

  const { settings, formatPrice } = useSettings();
  const [inputCoupon, setInputCoupon] = useState('');

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputCoupon.trim()) {
      applyCoupon(inputCoupon.trim());
      setInputCoupon('');
    }
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <div className="max-w-md mx-auto p-8 bg-white rounded-3xl border border-neutral-200/80 shadow-xs space-y-4">
          <div className="w-16 h-16 rounded-full bg-neutral-100 flex items-center justify-center mx-auto text-neutral-400">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-extrabold text-neutral-900">Your Cart is Empty</h2>
          <p className="text-xs text-neutral-500">
            Looks like you haven't stepped into any new footwear yet. Explore our latest arrivals or best sellers!
          </p>
          <button
            onClick={() => onNavigate('shop')}
            className="w-full py-3.5 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
          >
            Start Shopping
          </button>
        </div>
      </div>
    );
  }

  const freeShippingProgress = Math.min(100, Math.round((subtotal / settings.freeShippingThreshold) * 100));
  const remainingForFreeShipping = Math.max(0, settings.freeShippingThreshold - subtotal);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-neutral-400 font-medium">
        <button onClick={() => onNavigate('home')} className="hover:text-black cursor-pointer">
          Home
        </button>
        <span>/</span>
        <button onClick={() => onNavigate('shop')} className="hover:text-black cursor-pointer">
          Shop
        </button>
        <span>/</span>
        <span className="text-neutral-900 font-bold">Shopping Cart</span>
      </div>

      <div className="flex items-baseline justify-between border-b border-neutral-200 pb-4">
        <div>
          <h1 className="text-3xl font-extrabold text-neutral-900 tracking-tight">Shopping Cart</h1>
          <p className="text-xs text-neutral-500 mt-1">Review your selected footwear items and sizes</p>
        </div>
        <button
          onClick={clearCart}
          className="text-xs text-neutral-500 hover:text-rose-600 font-semibold cursor-pointer transition-colors"
        >
          Clear Cart
        </button>
      </div>

      {/* Free Shipping Progress Indicator */}
      <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200/70 text-xs">
        <div className="flex justify-between font-bold text-amber-950 mb-1.5">
          <span>
            {remainingForFreeShipping > 0
              ? `Add ${formatPrice(remainingForFreeShipping)} more to qualify for FREE Nationwide Delivery!`
              : '🎉 Congratulations! You have unlocked FREE Nationwide Delivery!'}
          </span>
          <span>{freeShippingProgress}%</span>
        </div>
        <div className="w-full h-2 rounded-full bg-amber-200/80 overflow-hidden">
          <div
            className="h-full bg-amber-600 rounded-full transition-all duration-500"
            style={{ width: `${freeShippingProgress}%` }}
          />
        </div>
      </div>

      {/* Cart Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        {/* Cart Items List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-3xl border border-neutral-200/80 shadow-xs divide-y divide-neutral-100 overflow-hidden">
            {cart.map(item => (
              <div key={item.id} className="p-4 sm:p-6 flex flex-col sm:flex-row items-start sm:items-center gap-4">
                <img
                  src={item.image}
                  alt={item.name}
                  onClick={() => onNavigate('product-details', { id: item.slug || item.productId })}
                  className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover bg-neutral-100 shrink-0 cursor-pointer"
                />

                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-[10px] font-extrabold uppercase tracking-wider text-amber-700">
                        {item.brand}
                      </p>
                      <h3
                        onClick={() => onNavigate('product-details', { id: item.slug || item.productId })}
                        className="font-bold text-neutral-900 text-sm sm:text-base hover:text-amber-600 transition-colors cursor-pointer"
                      >
                        {item.name}
                      </h3>
                    </div>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="p-1.5 text-neutral-400 hover:text-rose-600 rounded-lg hover:bg-neutral-100 transition-colors cursor-pointer"
                      aria-label="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Size & Color options inline */}
                  <div className="flex flex-wrap items-center gap-3 text-xs pt-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-neutral-500 font-medium">Size:</span>
                      <select
                        value={item.selectedSize}
                        onChange={e => updateItemSize(item.id, e.target.value as ShoeSize)}
                        className="bg-neutral-100 border border-neutral-200 rounded-lg px-2 py-0.5 font-bold text-neutral-900 focus:outline-none cursor-pointer"
                      >
                        {ALL_SIZES.map(sz => (
                          <option key={sz} value={sz}>
                            EU {sz}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <span className="text-neutral-500 font-medium">Color:</span>
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-neutral-300"
                        style={{ backgroundColor: item.selectedColor?.hex }}
                      />
                      <span className="font-semibold text-neutral-800">{item.selectedColor?.name}</span>
                    </div>
                  </div>

                  {/* Quantity & Subtotal row */}
                  <div className="flex items-center justify-between pt-2">
                    <div className="flex items-center border border-neutral-200 rounded-lg bg-neutral-50 p-0.5">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-1 text-neutral-600 hover:text-black cursor-pointer"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-8 text-center font-bold text-xs text-neutral-900">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        disabled={item.quantity >= item.maxStock}
                        className="p-1 text-neutral-600 hover:text-black disabled:opacity-30 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="text-right">
                      <span className="text-sm sm:text-base font-extrabold text-neutral-950">
                        {formatPrice((item.salePrice || item.price) * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between text-xs text-neutral-500 pt-2">
            <button
              onClick={() => onNavigate('shop')}
              className="font-bold text-neutral-900 hover:text-amber-600 flex items-center gap-1 cursor-pointer"
            >
              <span>← Continue Shopping</span>
            </button>
            <span>Prices are inclusive of standard local taxes</span>
          </div>
        </div>

        {/* Order Summary & Coupon Card */}
        <div className="space-y-4">
          <div className="p-6 bg-white rounded-3xl border border-neutral-200/80 shadow-xs space-y-6">
            <h3 className="font-extrabold text-neutral-900 text-base uppercase tracking-wider">
              Order Summary
            </h3>

            {/* Shipping Destination selector */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-neutral-600 uppercase tracking-wider">
                Shipping Destination (Bangladesh)
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setShippingRegion('inside_dhaka')}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    shippingRegion === 'inside_dhaka'
                      ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
                      : 'border-neutral-200 text-neutral-700 hover:border-neutral-400'
                  }`}
                >
                  Inside Dhaka
                </button>
                <button
                  type="button"
                  onClick={() => setShippingRegion('outside_dhaka')}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    shippingRegion === 'outside_dhaka'
                      ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
                      : 'border-neutral-200 text-neutral-700 hover:border-neutral-400'
                  }`}
                >
                  Outside Dhaka
                </button>
              </div>
            </div>

            {/* Coupon Code Input */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-neutral-600 uppercase tracking-wider">
                Discount Coupon Code
              </label>
              {couponCode ? (
                <div className="flex items-center justify-between p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs">
                  <div className="flex items-center gap-2">
                    <Tag className="w-4 h-4 text-emerald-600" />
                    <div>
                      <span className="font-extrabold text-emerald-950 uppercase">{couponCode}</span>
                      <p className="text-[10px] text-emerald-700">Coupon applied successfully</p>
                    </div>
                  </div>
                  <button
                    onClick={removeCoupon}
                    className="p-1 text-emerald-800 hover:text-rose-600 transition-colors cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <input
                    type="text"
                    value={inputCoupon}
                    onChange={e => setInputCoupon(e.target.value)}
                    placeholder="e.g. WELCOME10, SAVE20"
                    className="flex-1 px-3 py-2 text-xs uppercase bg-neutral-50 border border-neutral-300 rounded-xl font-mono font-bold focus:outline-none focus:border-neutral-900"
                  />
                  <button
                    type="submit"
                    disabled={isApplyingCoupon || !inputCoupon.trim()}
                    className="px-4 py-2 bg-neutral-900 hover:bg-black text-white text-xs font-bold rounded-xl disabled:opacity-40 cursor-pointer"
                  >
                    {isApplyingCoupon ? 'Checking...' : 'Apply'}
                  </button>
                </form>
              )}
              {couponError && <p className="text-[11px] text-rose-600 font-medium">{couponError}</p>}
              <div className="text-[10px] text-neutral-400">
                Try codes: <strong className="text-neutral-600">WELCOME10</strong>, <strong className="text-neutral-600">SAVE20</strong>, <strong className="text-neutral-600">SHOE50</strong>
              </div>
            </div>

            {/* Calculations Breakdown */}
            <div className="pt-4 border-t border-neutral-100 space-y-2.5 text-xs sm:text-sm">
              <div className="flex justify-between text-neutral-600">
                <span>Subtotal:</span>
                <span className="font-semibold text-neutral-900">{formatPrice(subtotal)}</span>
              </div>
              {couponDiscount > 0 && (
                <div className="flex justify-between text-rose-600">
                  <span>Discount ({couponCode}):</span>
                  <span className="font-bold">-{formatPrice(couponDiscount)}</span>
                </div>
              )}
              <div className="flex justify-between text-neutral-600">
                <span>
                  Estimated Delivery ({shippingRegion === 'inside_dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'}):
                </span>
                <span className="font-semibold text-neutral-900">
                  {shippingFee === 0 ? (
                    <strong className="text-emerald-600 font-bold uppercase">FREE</strong>
                  ) : (
                    formatPrice(shippingFee)
                  )}
                </span>
              </div>
              <div className="pt-3 border-t-2 border-neutral-900 flex justify-between text-base font-extrabold text-neutral-950">
                <span>Grand Total:</span>
                <span className="text-amber-600">{formatPrice(grandTotal)}</span>
              </div>
            </div>

            {/* Checkout CTA */}
            <button
              onClick={() => onNavigate('checkout')}
              className="w-full py-4 bg-neutral-900 hover:bg-black text-white font-extrabold text-sm uppercase tracking-wider rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-200/80 space-y-2 text-xs text-neutral-500">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Safe & Secure 256-Bit SSL Checkout</span>
            </div>
            <div className="flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-amber-600 shrink-0" />
              <span>7 Days Doorstep Return & Sizing Exchange</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
