import React, { useState, useEffect } from 'react';
import {
  SlidersHorizontal,
  X,
  Search,
  ChevronDown,
  RotateCcw,
  Check,
  Star,
  PackageX,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { Product, Category, ShoeSize } from '../../types';
import { api } from '../../services/api';
import { ProductCard } from '../../components/common/ProductCard';
import { useSettings } from '../../context/SettingsContext';

interface ShopPageProps {
  onNavigate: (page: string, params?: any) => void;
  initialParams?: any;
}

const ALL_SIZES: ShoeSize[] = ['36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46'];
const POPULAR_COLORS = ['White', 'Black', 'Brown', 'Navy', 'Grey', 'Red', 'Pink'];

export const ShopPage: React.FC<ShopPageProps> = ({ onNavigate, initialParams = {} }) => {
  const { settings, formatPrice } = useSettings();

  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [totalProducts, setTotalProducts] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [isLoading, setIsLoading] = useState(true);

  // Filters State
  const [searchQuery, setSearchQuery] = useState(initialParams.q || '');
  const [selectedCategory, setSelectedCategory] = useState(initialParams.category || 'all');
  const [selectedGender, setSelectedGender] = useState(initialParams.gender || 'all');
  const [selectedSize, setSelectedSize] = useState<ShoeSize | ''>(initialParams.size || '');
  const [selectedColor, setSelectedColor] = useState(initialParams.color || '');
  const [minPrice, setMinPrice] = useState(initialParams.minPrice || '');
  const [maxPrice, setMaxPrice] = useState(initialParams.maxPrice || '');
  const [selectedRating, setSelectedRating] = useState(initialParams.rating || '');
  const [inStockOnly, setInStockOnly] = useState(initialParams.inStock === 'true');
  const [discountOnly, setDiscountOnly] = useState(initialParams.discountOnly === 'true');
  const [sortBy, setSortBy] = useState(initialParams.sort || 'newest');

  const [isMobileFiltersOpen, setIsMobileFiltersOpen] = useState(false);

  // Sync initialParams changes
  useEffect(() => {
    if (initialParams.category) setSelectedCategory(initialParams.category);
    if (initialParams.q !== undefined) setSearchQuery(initialParams.q);
    if (initialParams.discountOnly) setDiscountOnly(initialParams.discountOnly === 'true');
    if (initialParams.newArrival) setSortBy('newest');
    if (initialParams.sort) setSortBy(initialParams.sort);
  }, [initialParams]);

  // Fetch categories on mount
  useEffect(() => {
    api.getCategories().then(res => setCategories(res.categories || []));
  }, []);

  // Fetch filtered products
  const fetchProducts = async (page = 1) => {
    setIsLoading(true);
    try {
      const params: Record<string, string> = {
        page: page.toString(),
        limit: '12',
        sort: sortBy,
      };

      if (searchQuery.trim()) params.q = searchQuery.trim();
      if (selectedCategory && selectedCategory !== 'all') params.category = selectedCategory;
      if (selectedGender && selectedGender !== 'all') params.gender = selectedGender;
      if (selectedSize) params.size = selectedSize;
      if (selectedColor) params.color = selectedColor;
      if (minPrice) params.minPrice = minPrice;
      if (maxPrice) params.maxPrice = maxPrice;
      if (selectedRating) params.rating = selectedRating;
      if (inStockOnly) params.inStock = 'true';
      if (discountOnly) params.discountOnly = 'true';

      const res = await api.getProducts(params);
      setProducts(res.products || []);
      setTotalProducts(res.total || 0);
      setTotalPages(res.totalPages || 1);
      setCurrentPage(res.page || 1);
    } catch (err) {
      console.error('Failed to fetch filtered products:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts(1);
  }, [
    searchQuery,
    selectedCategory,
    selectedGender,
    selectedSize,
    selectedColor,
    minPrice,
    maxPrice,
    selectedRating,
    inStockOnly,
    discountOnly,
    sortBy,
  ]);

  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedGender('all');
    setSelectedSize('');
    setSelectedColor('');
    setMinPrice('');
    setMaxPrice('');
    setSelectedRating('');
    setInStockOnly(false);
    setDiscountOnly(false);
    setSortBy('newest');
  };

  const activeFiltersCount = [
    selectedCategory !== 'all' ? 1 : 0,
    selectedGender !== 'all' ? 1 : 0,
    selectedSize ? 1 : 0,
    selectedColor ? 1 : 0,
    minPrice ? 1 : 0,
    maxPrice ? 1 : 0,
    selectedRating ? 1 : 0,
    inStockOnly ? 1 : 0,
    discountOnly ? 1 : 0,
    searchQuery ? 1 : 0,
  ].reduce((a, b) => a + b, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header Banner & Breadcrumbs */}
      <div className="mb-8">
        <div className="flex items-center gap-2 text-xs text-neutral-400 font-medium mb-2">
          <button onClick={() => onNavigate('home')} className="hover:text-black cursor-pointer">
            Home
          </button>
          <span>/</span>
          <span className="text-neutral-900 font-bold">Footwear Shop</span>
          {selectedCategory !== 'all' && (
            <>
              <span>/</span>
              <span className="capitalize text-amber-600 font-bold">{selectedCategory}</span>
            </>
          )}
        </div>

        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight">
              {selectedCategory !== 'all'
                ? `${selectedCategory.toUpperCase()} COLLECTION`
                : 'ALL FOOTWEAR'}
            </h1>
            <p className="text-sm text-neutral-500 mt-1">
              Showing {products.length} of {totalProducts} premium shoes
            </p>
          </div>

          {/* Search bar & Sorting */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative w-full sm:w-64">
              <input
                type="text"
                placeholder="Search styles, brands..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 text-xs bg-white rounded-xl border border-neutral-300 focus:outline-none focus:border-neutral-900 shadow-2xs"
              />
              <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-black"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Sort Dropdown */}
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value)}
              className="px-4 py-2.5 bg-white border border-neutral-300 rounded-xl text-xs font-bold text-neutral-800 focus:outline-none focus:border-neutral-900 shadow-2xs cursor-pointer"
            >
              <option value="newest">Newest Arrivals</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="best-selling">Best Selling</option>
              <option value="rating">Highest Rated</option>
              <option value="popular">Most Popular</option>
            </select>

            {/* Mobile Filter Toggle */}
            <button
              onClick={() => setIsMobileFiltersOpen(true)}
              className="lg:hidden flex items-center gap-2 px-4 py-2.5 bg-neutral-900 text-white rounded-xl text-xs font-bold shadow-sm cursor-pointer"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Filters {activeFiltersCount > 0 && `(${activeFiltersCount})`}</span>
            </button>
          </div>
        </div>
      </div>

      <div className="flex gap-8 items-start">
        {/* DESKTOP SIDEBAR FILTERS */}
        <aside className="hidden lg:block w-64 shrink-0 bg-white p-6 rounded-3xl border border-neutral-200/80 shadow-xs space-y-6 sticky top-28">
          <div className="flex items-center justify-between pb-4 border-b border-neutral-100">
            <span className="font-extrabold text-sm uppercase tracking-wider text-neutral-900">
              Filters {activeFiltersCount > 0 && `(${activeFiltersCount})`}
            </span>
            {activeFiltersCount > 0 && (
              <button
                onClick={handleClearFilters}
                className="text-xs text-rose-600 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset</span>
              </button>
            )}
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-500 mb-2.5">
              Categories
            </h4>
            <div className="space-y-1 text-xs">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`w-full text-left px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer ${
                  selectedCategory === 'all' ? 'bg-neutral-900 text-white' : 'text-neutral-600 hover:bg-neutral-50'
                }`}
              >
                All Categories
              </button>
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.slug)}
                  className={`w-full text-left px-3 py-1.5 rounded-lg font-semibold transition-colors flex justify-between items-center cursor-pointer ${
                    selectedCategory === cat.slug
                      ? 'bg-neutral-900 text-white'
                      : 'text-neutral-600 hover:bg-neutral-50'
                  }`}
                >
                  <span>{cat.name}</span>
                  <span className={`text-[10px] ${selectedCategory === cat.slug ? 'text-amber-400' : 'text-neutral-400'}`}>
                    {cat.itemCount}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Gender */}
          <div className="pt-4 border-t border-neutral-100">
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-500 mb-2.5">
              Gender
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {['all', 'men', 'women', 'kids'].map(g => (
                <button
                  key={g}
                  onClick={() => setSelectedGender(g)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-colors cursor-pointer ${
                    selectedGender === g
                      ? 'bg-neutral-900 text-white'
                      : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          {/* Shoe Sizes */}
          <div className="pt-4 border-t border-neutral-100">
            <div className="flex justify-between items-center mb-2.5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-500">
                Shoe Size (EU)
              </h4>
              {selectedSize && (
                <button
                  onClick={() => setSelectedSize('')}
                  className="text-[10px] text-amber-600 font-bold hover:underline"
                >
                  Clear
                </button>
              )}
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {ALL_SIZES.map(sz => (
                <button
                  key={sz}
                  onClick={() => setSelectedSize(selectedSize === sz ? '' : sz)}
                  className={`py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                    selectedSize === sz
                      ? 'bg-neutral-900 text-white border-neutral-900 shadow-sm'
                      : 'border-neutral-200 text-neutral-700 hover:border-neutral-900'
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div className="pt-4 border-t border-neutral-100">
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-500 mb-2.5">
              Price Range ({settings.currency})
            </h4>
            <div className="flex items-center gap-2">
              <input
                type="number"
                placeholder="Min"
                value={minPrice}
                onChange={e => setMinPrice(e.target.value)}
                className="w-1/2 px-2.5 py-1.5 text-xs bg-neutral-50 border border-neutral-200 rounded-lg focus:outline-none focus:border-neutral-900 font-medium"
              />
              <span className="text-neutral-400 text-xs">-</span>
              <input
                type="number"
                placeholder="Max"
                value={maxPrice}
                onChange={e => setMaxPrice(e.target.value)}
                className="w-1/2 px-2.5 py-1.5 text-xs bg-neutral-50 border border-neutral-200 rounded-lg focus:outline-none focus:border-neutral-900 font-medium"
              />
            </div>
          </div>

          {/* Quick Toggles */}
          <div className="pt-4 border-t border-neutral-100 space-y-2.5">
            <label className="flex items-center gap-2.5 text-xs font-semibold text-neutral-700 cursor-pointer">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={e => setInStockOnly(e.target.checked)}
                className="rounded border-neutral-300 text-neutral-900 focus:ring-neutral-900 w-4 h-4"
              />
              <span>In Stock Only</span>
            </label>

            <label className="flex items-center gap-2.5 text-xs font-semibold text-rose-600 cursor-pointer">
              <input
                type="checkbox"
                checked={discountOnly}
                onChange={e => setDiscountOnly(e.target.checked)}
                className="rounded border-neutral-300 text-rose-600 focus:ring-rose-600 w-4 h-4"
              />
              <span>Discounted Items %</span>
            </label>
          </div>
        </aside>

        {/* PRODUCTS GRID */}
        <main className="flex-1 min-w-0">
          {isLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-white rounded-2xl p-4 border border-neutral-100 space-y-3 animate-pulse">
                  <div className="aspect-square bg-neutral-200 rounded-xl" />
                  <div className="h-4 bg-neutral-200 rounded w-2/3" />
                  <div className="h-3 bg-neutral-200 rounded w-1/2" />
                  <div className="h-4 bg-neutral-200 rounded w-1/3" />
                </div>
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-20 bg-white rounded-3xl border border-neutral-200/80 p-8 shadow-xs">
              <PackageX className="w-16 h-16 text-neutral-300 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-neutral-900">No shoes found matching your filters</h3>
              <p className="text-neutral-500 text-sm mt-1 max-w-sm mx-auto">
                Try loosening your filters, changing sizes, or searching with broader keywords.
              </p>
              <button
                onClick={handleClearFilters}
                className="mt-6 px-6 py-2.5 bg-neutral-900 text-white rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-neutral-800 transition-colors cursor-pointer"
              >
                Clear All Filters
              </button>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
                {products.map(product => (
                  <ProductCard key={product.id} product={product} onNavigate={onNavigate} />
                ))}
              </div>

              {/* Pagination Controls */}
              {totalPages > 1 && (
                <div className="mt-12 pt-8 border-t border-neutral-200 flex items-center justify-between">
                  <button
                    disabled={currentPage <= 1}
                    onClick={() => fetchProducts(currentPage - 1)}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-neutral-300 text-xs font-bold text-neutral-700 hover:bg-neutral-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Previous</span>
                  </button>

                  <div className="flex items-center gap-1">
                    {[...Array(totalPages)].map((_, i) => {
                      const pNum = i + 1;
                      return (
                        <button
                          key={pNum}
                          onClick={() => fetchProducts(pNum)}
                          className={`w-8 h-8 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                            currentPage === pNum
                              ? 'bg-neutral-900 text-white shadow-sm'
                              : 'text-neutral-600 hover:bg-neutral-100'
                          }`}
                        >
                          {pNum}
                        </button>
                      );
                    })}
                  </div>

                  <button
                    disabled={currentPage >= totalPages}
                    onClick={() => fetchProducts(currentPage + 1)}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-neutral-300 text-xs font-bold text-neutral-700 hover:bg-neutral-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                  >
                    <span>Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </>
          )}
        </main>
      </div>

      {/* MOBILE FILTERS MODAL */}
      {isMobileFiltersOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex">
          <div className="w-4/5 max-w-sm bg-white h-full shadow-2xl flex flex-col p-6 overflow-y-auto animate-in slide-in-from-right ml-auto">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-200">
              <span className="font-extrabold text-base uppercase text-neutral-900">
                Filter Shoes
              </span>
              <button
                onClick={() => setIsMobileFiltersOpen(false)}
                className="p-1 text-neutral-500 hover:text-black cursor-pointer"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="py-4 space-y-6">
              {/* Category */}
              <div>
                <h4 className="text-xs font-bold uppercase text-neutral-500 mb-2">Category</h4>
                <div className="grid grid-cols-2 gap-1.5 text-xs">
                  <button
                    onClick={() => setSelectedCategory('all')}
                    className={`py-2 px-3 rounded-lg font-bold ${
                      selectedCategory === 'all' ? 'bg-neutral-900 text-white' : 'bg-neutral-100 text-neutral-700'
                    }`}
                  >
                    All
                  </button>
                  {categories.map(c => (
                    <button
                      key={c.id}
                      onClick={() => setSelectedCategory(c.slug)}
                      className={`py-2 px-3 rounded-lg font-bold text-left truncate ${
                        selectedCategory === c.slug ? 'bg-neutral-900 text-white' : 'bg-neutral-100 text-neutral-700'
                      }`}
                    >
                      {c.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sizes */}
              <div>
                <h4 className="text-xs font-bold uppercase text-neutral-500 mb-2">EU Size</h4>
                <div className="grid grid-cols-4 gap-1.5">
                  {ALL_SIZES.map(sz => (
                    <button
                      key={sz}
                      onClick={() => setSelectedSize(selectedSize === sz ? '' : sz)}
                      className={`py-2 rounded-lg font-bold text-xs ${
                        selectedSize === sz ? 'bg-neutral-900 text-white' : 'bg-neutral-100 text-neutral-700'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
              </div>

              {/* Discount & Stock */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-bold text-neutral-800">
                  <input
                    type="checkbox"
                    checked={inStockOnly}
                    onChange={e => setInStockOnly(e.target.checked)}
                    className="w-4 h-4"
                  />
                  <span>In Stock Only</span>
                </label>
                <label className="flex items-center gap-2 text-xs font-bold text-rose-600">
                  <input
                    type="checkbox"
                    checked={discountOnly}
                    onChange={e => setDiscountOnly(e.target.checked)}
                    className="w-4 h-4"
                  />
                  <span>Sale Items Only %</span>
                </label>
              </div>
            </div>

            <div className="mt-auto pt-4 border-t border-neutral-200 flex gap-2">
              <button
                onClick={handleClearFilters}
                className="w-1/2 py-3 border border-neutral-300 rounded-xl text-xs font-bold text-neutral-700"
              >
                Reset
              </button>
              <button
                onClick={() => setIsMobileFiltersOpen(false)}
                className="w-1/2 py-3 bg-neutral-900 text-white rounded-xl text-xs font-bold uppercase tracking-wider"
              >
                Apply
              </button>
            </div>
          </div>
          <div className="flex-1" onClick={() => setIsMobileFiltersOpen(false)} />
        </div>
      )}
    </div>
  );
};
