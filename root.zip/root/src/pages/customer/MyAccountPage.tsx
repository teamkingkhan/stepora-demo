import React, { useState, useEffect } from 'react';
import {
  User as UserIcon,
  Package,
  MapPin,
  Lock,
  LogOut,
  ChevronRight,
  Printer,
  Truck,
  CheckCircle2,
  Clock,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useSettings } from '../../context/SettingsContext';
import { useToast } from '../../context/ToastContext';
import { api } from '../../services/api';
import { Order } from '../../types';
import { InvoiceModal } from '../../components/common/InvoiceModal';

interface MyAccountPageProps {
  initialTab?: 'profile' | 'orders' | 'addresses' | 'password';
  onNavigate: (page: string, params?: any) => void;
}

export const MyAccountPage: React.FC<MyAccountPageProps> = ({ initialTab = 'profile', onNavigate }) => {
  const { user, customerLogout, updateCustomerProfile, isCustomerAuthenticated } = useAuth();
  const { formatPrice } = useSettings();
  const { showToast } = useToast();

  const [activeTab, setActiveTab] = useState<'profile' | 'orders' | 'addresses' | 'password'>(initialTab);
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedOrderForInvoice, setSelectedOrderForInvoice] = useState<Order | null>(null);

  // Profile fields
  const [name, setName] = useState(user?.fullName || '');
  const [phone, setPhone] = useState(user?.phoneNumber || '');
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);

  // Password fields
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [isUpdatingPassword, setIsUpdatingPassword] = useState(false);

  useEffect(() => {
    if (isCustomerAuthenticated) {
      api.getCustomerOrders().then(res => setOrders(res.orders || []));
    }
  }, [isCustomerAuthenticated]);

  if (!isCustomerAuthenticated) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-neutral-900">Please Sign In</h2>
        <p className="text-xs text-neutral-500">Sign in to view your orders, addresses, and personal profile.</p>
        <button
          onClick={() => onNavigate('login')}
          className="px-6 py-3 bg-neutral-900 text-white rounded-xl text-xs font-bold uppercase tracking-wider"
        >
          Sign In Now
        </button>
      </div>
    );
  }

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdatingProfile(true);
    try {
      await updateCustomerProfile({ fullName: name, phoneNumber: phone });
      showToast('Profile updated successfully!', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to update profile.', 'error');
    } finally {
      setIsUpdatingProfile(false);
    }
  };

  const handlePasswordSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 6) {
      showToast('New password must be at least 6 characters.', 'error');
      return;
    }
    setIsUpdatingPassword(true);
    try {
      await api.changePassword({ currentPassword, newPassword });
      showToast('Password changed successfully!', 'success');
      setCurrentPassword('');
      setNewPassword('');
    } catch (err: any) {
      showToast(err.message || 'Failed to change password.', 'error');
    } finally {
      setIsUpdatingPassword(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200/80 shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-neutral-900 text-white font-extrabold text-xl flex items-center justify-center shadow-md">
            {user?.fullName.charAt(0) || 'U'}
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-neutral-900">{user?.fullName}</h1>
            <p className="text-xs text-neutral-500">{user?.email} • {user?.phoneNumber}</p>
          </div>
        </div>
        <button
          onClick={customerLogout}
          className="flex items-center gap-2 px-4 py-2 border border-rose-200 text-rose-600 hover:bg-rose-50 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer w-fit"
        >
          <LogOut className="w-4 h-4" />
          <span>Sign Out</span>
        </button>
      </div>

      {/* Grid: Tabs + Content */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8 items-start">
        {/* Sidebar Nav */}
        <aside className="bg-white p-3 rounded-2xl border border-neutral-200/80 shadow-xs space-y-1">
          <button
            onClick={() => setActiveTab('profile')}
            className={`w-full flex items-center gap-2.5 px-4 py-3 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
              activeTab === 'profile' ? 'bg-neutral-900 text-white' : 'text-neutral-600 hover:bg-neutral-50'
            }`}
          >
            <UserIcon className="w-4 h-4" />
            <span>Profile Details</span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
              activeTab === 'orders' ? 'bg-neutral-900 text-white' : 'text-neutral-600 hover:bg-neutral-50'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Package className="w-4 h-4" />
              <span>My Orders</span>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-neutral-100 text-neutral-800">
              {orders.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('password')}
            className={`w-full flex items-center gap-2.5 px-4 py-3 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
              activeTab === 'password' ? 'bg-neutral-900 text-white' : 'text-neutral-600 hover:bg-neutral-50'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>Change Password</span>
          </button>
        </aside>

        {/* Content Panel */}
        <main className="md:col-span-3">
          {/* PROFILE TAB */}
          {activeTab === 'profile' && (
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-6">
              <h2 className="text-lg font-extrabold text-neutral-900">Personal Information</h2>
              <form onSubmit={handleProfileSave} className="space-y-4 max-w-lg">
                <div>
                  <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">Full Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    className="w-full px-4 py-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl font-medium focus:bg-white focus:outline-none focus:border-neutral-900"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">Email</label>
                  <input
                    type="email"
                    value={user?.email}
                    disabled
                    className="w-full px-4 py-3 text-sm bg-neutral-100 border border-neutral-200 rounded-xl font-medium text-neutral-500 cursor-not-allowed"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">Mobile Number</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    className="w-full px-4 py-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl font-mono focus:bg-white focus:outline-none focus:border-neutral-900"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isUpdatingProfile}
                  className="px-6 py-3 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer transition-colors shadow-md"
                >
                  {isUpdatingProfile ? 'Saving...' : 'Save Profile Changes'}
                </button>
              </form>
            </div>
          )}

          {/* ORDERS TAB */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              <h2 className="text-lg font-extrabold text-neutral-900">Order History ({orders.length})</h2>
              {orders.length === 0 ? (
                <div className="bg-white p-12 rounded-3xl border border-neutral-200/80 text-center space-y-3">
                  <Package className="w-12 h-12 text-neutral-300 mx-auto" />
                  <p className="font-bold text-neutral-800 text-sm">No orders placed yet</p>
                  <p className="text-xs text-neutral-500">Your footwear orders will appear here once placed.</p>
                  <button
                    onClick={() => onNavigate('shop')}
                    className="mt-2 px-6 py-2.5 bg-neutral-900 text-white rounded-xl text-xs font-bold uppercase tracking-wider"
                  >
                    Start Shopping
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {orders.map(order => (
                    <div
                      key={order.id}
                      className="bg-white p-6 rounded-3xl border border-neutral-200/80 shadow-xs space-y-4"
                    >
                      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-neutral-100 pb-3">
                        <div>
                          <span className="font-mono text-xs font-bold text-amber-700">
                            {order.orderNumber}
                          </span>
                          <p className="text-[11px] text-neutral-400">
                            {new Date(order.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-3 py-1 rounded-full text-[10px] font-extrabold uppercase ${
                              order.orderStatus === 'Delivered'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {order.orderStatus}
                          </span>
                          <button
                            onClick={() => setSelectedOrderForInvoice(order)}
                            className="p-1.5 text-neutral-500 hover:text-black rounded-lg border border-neutral-200 hover:bg-neutral-50 cursor-pointer"
                            title="Invoice"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onNavigate('track-order', { query: order.orderNumber })}
                            className="p-1.5 text-neutral-500 hover:text-black rounded-lg border border-neutral-200 hover:bg-neutral-50 cursor-pointer"
                            title="Track"
                          >
                            <Truck className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <div className="divide-y divide-neutral-100">
                        {order.items.map((it, idx) => (
                          <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                            <div className="flex items-center gap-3">
                              <img src={it.image} alt={it.productName} className="w-12 h-12 rounded-xl object-cover" />
                              <div>
                                <p className="font-bold text-neutral-900">{it.productName}</p>
                                <p className="text-[11px] text-neutral-500">
                                  Size {it.selectedSize} • {it.selectedColor?.name} × {it.quantity}
                                </p>
                              </div>
                            </div>
                            <span className="font-bold text-neutral-900">{formatPrice(it.itemTotal)}</span>
                          </div>
                        ))}
                      </div>

                      <div className="pt-3 border-t border-neutral-100 flex justify-between items-center text-xs">
                        <span className="text-neutral-500">
                          Payment: <strong className="uppercase text-neutral-900">{order.paymentMethod}</strong> (
                          {order.paymentStatus})
                        </span>
                        <span className="text-sm font-extrabold text-neutral-950">
                          Total: {formatPrice(order.total)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* PASSWORD TAB */}
          {activeTab === 'password' && (
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-6">
              <h2 className="text-lg font-extrabold text-neutral-900">Change Password</h2>
              <form onSubmit={handlePasswordSave} className="space-y-4 max-w-lg">
                <div>
                  <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">
                    Current Password
                  </label>
                  <input
                    type="password"
                    value={currentPassword}
                    onChange={e => setCurrentPassword(e.target.value)}
                    className="w-full px-4 py-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">
                    New Password
                  </label>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={e => setNewPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full px-4 py-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={isUpdatingPassword}
                  className="px-6 py-3 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer shadow-md transition-colors"
                >
                  {isUpdatingPassword ? 'Saving...' : 'Update Password'}
                </button>
              </form>
            </div>
          )}
        </main>
      </div>

      {selectedOrderForInvoice && (
        <InvoiceModal
          order={selectedOrderForInvoice}
          isOpen={Boolean(selectedOrderForInvoice)}
          onClose={() => setSelectedOrderForInvoice(null)}
        />
      )}
    </div>
  );
};
