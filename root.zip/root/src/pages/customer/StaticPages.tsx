import React, { useState } from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  ShieldCheck,
  Send,
  HelpCircle,
  Truck,
  RotateCcw,
  ChevronDown,
} from 'lucide-react';
import { useSettings } from '../../context/SettingsContext';
import { useToast } from '../../context/ToastContext';

interface StaticPagesProps {
  page: 'about' | 'contact' | 'faq' | 'shipping' | 'return' | 'privacy' | 'terms';
  onNavigate: (page: string, params?: any) => void;
}

export const StaticPages: React.FC<StaticPagesProps> = ({ page, onNavigate }) => {
  const { settings, formatPrice } = useSettings();
  const { showToast } = useToast();

  // Contact form
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [isSending, setIsSending] = useState(false);

  // FAQ Accordion
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSending(true);
    setTimeout(() => {
      showToast('Thank you! Your message has been sent to our Banani showroom team.', 'success');
      setContactName('');
      setContactEmail('');
      setContactMessage('');
      setIsSending(false);
    }, 600);
  };

  const FAQS = [
    {
      q: 'How does shoe sizing work for STEPORA in Bangladesh?',
      a: 'We use standard European (EU) footwear sizing ranging from EU 36 to 46. This directly corresponds to standard Bangladeshi sizes (e.g. Size 41 or 42). You can consult our interactive Size Guide on any product details page for exact centimeter foot measurements.',
    },
    {
      q: 'How does the 7-day doorstep size exchange work?',
      a: 'If your shoes are too tight or too loose, simply contact our support hotline (+880 1712 345678) or WhatsApp within 7 days of delivery. Our courier rider will bring the replacement size right to your doorstep and collect the original pair, unworn and in original box.',
    },
    {
      q: 'How fast is delivery inside and outside Dhaka?',
      a: `Inside Dhaka Metro delivery typically takes 24 to 48 hours for standard fee of ${formatPrice(settings.insideDhakaShippingFee)}. Outside Dhaka (all 64 districts) takes 2 to 4 business days for ${formatPrice(settings.outsideDhakaShippingFee)}. Orders above ${formatPrice(settings.freeShippingThreshold)} receive 100% FREE nationwide delivery.`,
    },
    {
      q: 'Which payment methods do you accept?',
      a: 'We accept Cash on Delivery (COD) anywhere in Bangladesh, official bKash tokenized digital payment, Nagad mobile wallet, and all major Credit and Debit Cards (Visa, Mastercard, Amex).',
    },
    {
      q: 'Are your leather shoes made from genuine leather?',
      a: 'Yes! All our formal footwear and leather boots are handcrafted using 100% genuine full-grain and top-grain cowhide leather sourced from certified eco-friendly tanneries, finished with artisanal hand-burnishing.',
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* ABOUT US */}
      {page === 'about' && (
        <div className="space-y-10">
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-extrabold uppercase tracking-widest text-amber-600">
              The STEPORA Story
            </span>
            <h1 className="text-4xl font-extrabold text-neutral-900 tracking-tight">
              Crafting Modern Footwear for Bangladesh & Beyond
            </h1>
            <p className="text-sm text-neutral-500 leading-relaxed">
              Founded with a radical premise: Bangladeshi craftsmanship produces some of the world's most exquisite leather and athletic footwear. We brought that mastery directly to our homegrown market.
            </p>
          </div>

          <div className="rounded-3xl overflow-hidden aspect-16/9 bg-neutral-900 shadow-xl">
            <img
              src="https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=1400&q=80"
              alt="Footwear Workshop"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-4">
            <div className="p-6 bg-white rounded-2xl border border-neutral-200/80 shadow-xs space-y-2">
              <span className="text-2xl font-black text-amber-600">200+</span>
              <h4 className="font-bold text-neutral-900 text-sm">Artisanal Steps</h4>
              <p className="text-xs text-neutral-500">Every shoe is built over anatomical lasts with reinforced double-stitching.</p>
            </div>
            <div className="p-6 bg-white rounded-2xl border border-neutral-200/80 shadow-xs space-y-2">
              <span className="text-2xl font-black text-amber-600">100%</span>
              <h4 className="font-bold text-neutral-900 text-sm">Genuine Materials</h4>
              <p className="text-xs text-neutral-500">Full-grain calfskins, nitrogen-infused EVA, and high-abrasion rubber soles.</p>
            </div>
            <div className="p-6 bg-white rounded-2xl border border-neutral-200/80 shadow-xs space-y-2">
              <span className="text-2xl font-black text-amber-600">15,000+</span>
              <h4 className="font-bold text-neutral-900 text-sm">Happy Walkers</h4>
              <p className="text-xs text-neutral-500">From boardroom executives to daily marathoners in Dhaka and Chittagong.</p>
            </div>
          </div>
        </div>
      )}

      {/* CONTACT US */}
      {page === 'contact' && (
        <div className="space-y-10">
          <div className="text-center max-w-xl mx-auto space-y-2">
            <span className="text-xs font-extrabold uppercase tracking-widest text-amber-600">Get in Touch</span>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight">
              We're Here to Help
            </h1>
            <p className="text-xs text-neutral-500">
              Have questions about sizing, corporate orders, or store visits? Reach out to our Banani concierge.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Contact details */}
            <div className="p-8 bg-neutral-950 text-white rounded-3xl space-y-6 shadow-xl">
              <div>
                <span className="text-xs text-amber-400 font-bold uppercase tracking-wider">Atelier & Showroom</span>
                <h3 className="text-xl font-extrabold mt-1">STEPORA Banani Flagship</h3>
              </div>
              <div className="space-y-4 text-xs text-neutral-300">
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <span>{settings.storeAddress}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>{settings.storePhone}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Mail className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>{settings.storeEmail}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>Saturday – Thursday: 10:00 AM – 9:00 PM</span>
                </div>
              </div>
            </div>

            {/* Inquiry Form */}
            <form onSubmit={handleContactSubmit} className="bg-white p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">Your Name</label>
                <input
                  type="text"
                  value={contactName}
                  onChange={e => setContactName(e.target.value)}
                  placeholder="e.g. Sakib Al Hasan"
                  className="w-full px-4 py-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">Email or Mobile</label>
                <input
                  type="text"
                  value={contactEmail}
                  onChange={e => setContactEmail(e.target.value)}
                  placeholder="e.g. sakib@gmail.com or 017XXXXXXXX"
                  className="w-full px-4 py-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-neutral-600 mb-1">Message</label>
                <textarea
                  rows={4}
                  value={contactMessage}
                  onChange={e => setContactMessage(e.target.value)}
                  placeholder="How can we assist you with footwear sizing or orders?"
                  className="w-full px-4 py-3 text-sm bg-neutral-50 border border-neutral-300 rounded-xl focus:bg-white focus:outline-none focus:border-neutral-900"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isSending}
                className="w-full py-3.5 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-md cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>{isSending ? 'Sending Message...' : 'Send Inquiry'}</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* FAQ */}
      {page === 'faq' && (
        <div className="space-y-8">
          <div className="text-center max-w-xl mx-auto space-y-2">
            <span className="text-xs font-extrabold uppercase tracking-widest text-amber-600">Help & Knowledge Base</span>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight">
              Frequently Asked Questions
            </h1>
            <p className="text-xs text-neutral-500">
              Clear answers regarding shoe sizes, deliveries, doorstep replacement, and payment methods.
            </p>
          </div>

          <div className="space-y-3">
            {FAQS.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div
                  key={idx}
                  className="bg-white rounded-2xl border border-neutral-200/80 shadow-xs overflow-hidden transition-colors"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full p-5 text-left font-bold text-neutral-900 text-sm flex justify-between items-center gap-4 cursor-pointer"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown className={`w-4 h-4 text-neutral-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 text-xs text-neutral-600 leading-relaxed border-t border-neutral-100 pt-3">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SHIPPING POLICY */}
      {page === 'shipping' && (
        <div className="bg-white p-8 sm:p-12 rounded-3xl border border-neutral-200/80 shadow-xs space-y-6">
          <span className="text-xs font-extrabold uppercase tracking-widest text-amber-600">Delivery Guidelines</span>
          <h1 className="text-3xl font-extrabold text-neutral-900">Nationwide Shipping Policy</h1>
          <div className="space-y-4 text-sm text-neutral-600 leading-relaxed">
            <p>
              STEPORA guarantees prompt, fully insured delivery throughout all 64 districts in Bangladesh using reputable courier partners including Pathao, SteadFast, and Paperfly.
            </p>
            <h3 className="text-base font-extrabold text-neutral-900">Delivery Rates & Speed</h3>
            <ul className="list-disc pl-5 space-y-1 text-xs sm:text-sm">
              <li><strong>Inside Dhaka Metro:</strong> ৳ {settings.insideDhakaShippingFee} (Delivered within 24 to 48 hours).</li>
              <li><strong>Outside Dhaka Metro:</strong> ৳ {settings.outsideDhakaShippingFee} (Delivered within 2 to 4 business days).</li>
              <li><strong>Free Nationwide Shipping:</strong> Applicable automatically on all cart orders of ৳ {settings.freeShippingThreshold} or higher.</li>
            </ul>
          </div>
        </div>
      )}

      {/* RETURN & REFUND POLICY */}
      {page === 'return' && (
        <div className="bg-white p-8 sm:p-12 rounded-3xl border border-neutral-200/80 shadow-xs space-y-6">
          <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-600">Peace of Mind</span>
          <h1 className="text-3xl font-extrabold text-neutral-900">7-Day Return & Sizing Exchange</h1>
          <div className="space-y-4 text-sm text-neutral-600 leading-relaxed">
            <p>
              We want your shoes to feel like custom gloves. If you receive an item with sizing mismatch or craftsmanship defect, we offer effortless doorstep replacement within 7 calendar days.
            </p>
            <h3 className="text-base font-extrabold text-neutral-900">Exchange Conditions</h3>
            <ul className="list-disc pl-5 space-y-1 text-xs sm:text-sm">
              <li>Footwear must remain unworn on outdoor surfaces and in pristine original packaging with tags.</li>
              <li>Our rider will exchange the pair directly at your doorstep in Dhaka and major divisional hubs.</li>
              <li>Full cash or digital refund is issued if an exchange size is permanently unavailable.</li>
            </ul>
          </div>
        </div>
      )}

      {/* PRIVACY & TERMS */}
      {(page === 'privacy' || page === 'terms') && (
        <div className="bg-white p-8 sm:p-12 rounded-3xl border border-neutral-200/80 shadow-xs space-y-6">
          <h1 className="text-3xl font-extrabold text-neutral-900">
            {page === 'privacy' ? 'Privacy Policy' : 'Terms & Conditions'}
          </h1>
          <p className="text-xs text-neutral-500">Effective Date: October 2026</p>
          <div className="space-y-4 text-sm text-neutral-600 leading-relaxed">
            <p>
              At STEPORA, your privacy and customer rights are sacred. We store your contact and delivery data exclusively for processing shoe deliveries and authenticating account orders.
            </p>
            <p>
              We will never sell or rent your personal telephone number or email to third-party marketing brokers. Financial transactions via bKash, Nagad, and Cards are encrypted using 256-bit SSL protocols.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
