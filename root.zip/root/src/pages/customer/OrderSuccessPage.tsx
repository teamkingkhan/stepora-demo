import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import {
  CheckCircle2,
  Package,
  Printer,
  Truck,
  ArrowRight,
  ShieldCheck,
  PhoneCall,
  Calendar,
} from 'lucide-react';
import { Order } from '../../types';
import { api } from '../../services/api';
import { useSettings } from '../../context/SettingsContext';
import { InvoiceModal } from '../../components/common/InvoiceModal';

interface OrderSuccessPageProps {
  orderId: string;
  onNavigate: (page: string, params?: any) => void;
}

export const OrderSuccessPage: React.FC<OrderSuccessPageProps> = ({ orderId, onNavigate }) => {
  const { settings, formatPrice } = useSettings();
  const [order, setOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false);

  useEffect(() => {
    // Trigger confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#F59E0B', '#10B981', '#111827', '#E2136E'],
      });
    } catch (e) {
      console.warn('Confetti error:', e);
    }

    if (orderId) {
      api
        .getOrderById(orderId)
        .then(res => setOrder(res.order))
        .catch(err => console.error('Failed to load order:', err))
        .finally(() => setIsLoading(false));
    } else {
      setIsLoading(false);
    }
  }, [orderId]);

  if (isLoading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center animate-pulse">
        <div className="w-16 h-16 rounded-full bg-neutral-200 mx-auto mb-4" />
        <div className="h-8 bg-neutral-200 rounded w-1/2 mx-auto mb-2" />
        <div className="h-4 bg-neutral-200 rounded w-1/3 mx-auto" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold text-neutral-900">Order Placed</h2>
        <p className="text-neutral-500 mt-2 text-sm">Thank you for shopping with STEPORA.</p>
        <button
          onClick={() => onNavigate('shop')}
          className="mt-6 px-6 py-3 bg-neutral-900 text-white rounded-xl text-xs font-bold uppercase tracking-wider"
        >
          Continue Shopping
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Success Badge Banner */}
      <div className="text-center space-y-3 bg-white p-8 sm:p-10 rounded-3xl border border-neutral-200/80 shadow-xs">
        <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-md">
          <CheckCircle2 className="w-9 h-9" />
        </div>
        <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-600">
          Order Successfully Placed
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight">
          Thank you, {order.customerName.split(' ')[0]}!
        </h1>
        <p className="text-sm text-neutral-500 max-w-md mx-auto">
          We have received your order. We are preparing your footwear for inspection and dispatch from our Dhaka warehouse.
        </p>

        <div className="pt-2 inline-flex items-center gap-2 px-4 py-2 bg-neutral-100 rounded-xl font-mono text-sm font-bold text-neutral-900">
          <span>Order Number:</span>
          <span className="text-amber-600">{order.orderNumber}</span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap items-center justify-center gap-3">
        <button
          onClick={() => setIsInvoiceOpen(true)}
          className="px-6 py-3 bg-white border border-neutral-300 hover:border-neutral-900 text-neutral-800 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer shadow-xs transition-colors"
        >
          <Printer className="w-4 h-4 text-amber-600" />
          <span>View / Print Official Invoice</span>
        </button>

        <button
          onClick={() => onNavigate('track-order', { query: order.orderNumber })}
          className="px-6 py-3 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer shadow-md transition-colors"
        >
          <Truck className="w-4 h-4" />
          <span>Live Track Order</span>
        </button>

        <button
          onClick={() => onNavigate('shop')}
          className="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-md transition-colors"
        >
          <span>Continue Shopping</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Order Summary Card */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200/80 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-neutral-100 pb-4">
          <div>
            <span className="text-xs text-neutral-400 uppercase tracking-wider">Estimated Delivery</span>
            <p className="font-extrabold text-neutral-900 text-base flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-600" />
              <span>
                {order.shippingRegion === 'inside_dhaka'
                  ? 'Within 24 - 48 Hours'
                  : 'Within 2 - 4 Business Days'}
              </span>
            </p>
          </div>
          <div className="text-left sm:text-right">
            <span className="text-xs text-neutral-400 uppercase tracking-wider">Payment Method</span>
            <p className="font-extrabold uppercase text-neutral-900 text-sm">
              {order.paymentMethod} •{' '}
              <span className={order.paymentStatus === 'Paid' ? 'text-emerald-600' : 'text-amber-600'}>
                {order.paymentStatus}
              </span>
            </p>
          </div>
        </div>

        {/* Items */}
        <div className="divide-y divide-neutral-100">
          {order.items.map((item, idx) => (
            <div key={idx} className="py-4 first:pt-0 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <img src={item.image} alt={item.productName} className="w-16 h-16 rounded-xl object-cover" />
                <div>
                  <h4 className="font-bold text-neutral-900 text-sm">{item.productName}</h4>
                  <p className="text-xs text-neutral-500">
                    EU Size: <strong>{item.selectedSize}</strong> • Color:{' '}
                    <strong>{item.selectedColor?.name || 'Standard'}</strong> • Qty: {item.quantity}
                  </p>
                </div>
              </div>
              <span className="font-extrabold text-neutral-900 text-sm">{formatPrice(item.itemTotal)}</span>
            </div>
          ))}
        </div>

        {/* Pricing breakdown */}
        <div className="pt-4 border-t border-neutral-100 space-y-2 text-xs">
          <div className="flex justify-between text-neutral-600">
            <span>Subtotal:</span>
            <span className="font-semibold text-neutral-900">{formatPrice(order.subtotal)}</span>
          </div>
          {order.discount > 0 && (
            <div className="flex justify-between text-rose-600">
              <span>Coupon Discount:</span>
              <span className="font-bold">-{formatPrice(order.discount)}</span>
            </div>
          )}
          <div className="flex justify-between text-neutral-600">
            <span>Shipping:</span>
            <span className="font-semibold text-neutral-900">
              {order.shippingFee === 0 ? <strong className="text-emerald-600">FREE</strong> : formatPrice(order.shippingFee)}
            </span>
          </div>
          <div className="pt-2 border-t-2 border-neutral-900 flex justify-between text-base font-extrabold text-neutral-950">
            <span>Total:</span>
            <span className="text-amber-600">{formatPrice(order.total)}</span>
          </div>
        </div>

        {/* Shipping address details */}
        <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-200 text-xs space-y-1">
          <h4 className="font-bold text-neutral-900 uppercase tracking-wider text-[11px] mb-1">
            Shipping Address
          </h4>
          <p className="font-bold text-neutral-800">{order.shippingAddress.fullName}</p>
          <p className="text-neutral-600">{order.shippingAddress.phoneNumber}</p>
          <p className="text-neutral-600">
            {order.shippingAddress.fullAddress}, {order.shippingAddress.area}, {order.shippingAddress.district}, {order.shippingAddress.division}
          </p>
        </div>
      </div>

      {/* Invoice modal */}
      <InvoiceModal order={order} isOpen={isInvoiceOpen} onClose={() => setIsInvoiceOpen(false)} />
    </div>
  );
};
