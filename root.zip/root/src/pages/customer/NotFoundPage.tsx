import React from 'react';
import { ShoppingBag, ArrowLeft, Home } from 'lucide-react';

interface NotFoundPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const NotFoundPage: React.FC<NotFoundPageProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-md mx-auto px-4 py-28 text-center space-y-6">
      <div className="w-20 h-20 rounded-3xl bg-neutral-900 text-amber-400 font-black text-3xl flex items-center justify-center mx-auto shadow-xl">
        404
      </div>
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight">
          Oops! We couldn't find that page.
        </h1>
        <p className="text-xs text-neutral-500 mt-2 leading-relaxed">
          The link you followed may be broken, or the footwear collection may have been relocated.
        </p>
      </div>

      <div className="pt-2 flex flex-col sm:flex-row gap-3 justify-center">
        <button
          onClick={() => onNavigate('home')}
          className="px-6 py-3.5 bg-neutral-900 hover:bg-black text-white text-xs font-bold uppercase tracking-wider rounded-xl flex items-center justify-center gap-2 shadow-md cursor-pointer"
        >
          <Home className="w-4 h-4" />
          <span>Go to Homepage</span>
        </button>

        <button
          onClick={() => onNavigate('shop')}
          className="px-6 py-3.5 bg-white border border-neutral-300 hover:border-neutral-900 text-neutral-800 text-xs font-bold uppercase tracking-wider rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-xs"
        >
          <ShoppingBag className="w-4 h-4 text-amber-600" />
          <span>Explore Footwear</span>
        </button>
      </div>
    </div>
  );
};
