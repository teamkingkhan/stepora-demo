import React, { useState } from 'react';
import { Heart, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';
import { useWishlist } from '../../context/WishlistContext';
import { useCart } from '../../context/CartContext';
import { useSettings } from '../../context/SettingsContext';
import { Product, ShoeSize } from '../../types';

interface WishlistPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const WishlistPage: React.FC<WishlistPageProps> = ({ onNavigate }) => {
  const { wishlist, removeFromWishlist, clearWishlist } = useWishlist();
  const { addToCart } = useCart();
  const { formatPrice } = useSettings();

  const [selectedSizes, setSelectedSizes] = useState<Record<string, ShoeSize>>({});

  const handleMoveToCart = (product: Product) => {
    const size = selectedSizes[product.id] || product.availableSizes[0];
    addToCart(product, size);
    removeFromWishlist(product.id);
  };

  if (wishlist.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center">
        <div className="max-w-md mx-auto p-8 bg-white rounded-3xl border border-neutral-200 shadow-xs space-y-4">
          <div className="w-16 h-16 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mx-auto">
            <Heart className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-extrabold text-neutral-900">Your Wishlist is Empty</h2>
          <p className="text-xs text-neutral-500">
            Save shoes you love by tapping the heart icon on any product card or details page.
          </p>
          <button
            onClick={() => onNavigate('shop')}
            className="w-full py-3.5 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
          >
            Explore Footwear Catalog
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-neutral-400 font-medium">
        <button onClick={() => onNavigate('home')} className="hover:text-black cursor-pointer">
          Home
        </button>
        <span>/</span>
        <span className="text-neutral-900 font-bold">My Wishlist</span>
      </div>

      <div className="flex items-baseline justify-between border-b border-neutral-200 pb-4">
        <div>
          <h1 className="text-3xl font-extrabold text-neutral-900 tracking-tight">Saved Wishlist</h1>
          <p className="text-xs text-neutral-500 mt-0.5">{wishlist.length} footwear items saved</p>
        </div>
        <button
          onClick={clearWishlist}
          className="text-xs text-neutral-500 hover:text-rose-600 font-semibold cursor-pointer"
        >
          Clear All
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {wishlist.map(product => {
          const currentSize = selectedSizes[product.id] || product.availableSizes[0];
          return (
            <div
              key={product.id}
              className="bg-white rounded-3xl border border-neutral-200/80 shadow-xs overflow-hidden flex flex-col justify-between"
            >
              <div className="relative aspect-square w-full bg-neutral-100 overflow-hidden">
                <img
                  src={product.mainImage}
                  alt={product.name}
                  onClick={() => onNavigate('product-details', { id: product.slug || product.id })}
                  className="w-full h-full object-cover object-center cursor-pointer hover:scale-105 transition-transform duration-300"
                />
                <button
                  onClick={() => removeFromWishlist(product.id)}
                  className="absolute top-3 right-3 p-2 rounded-full bg-white/90 text-neutral-500 hover:text-rose-600 shadow-md cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-extrabold uppercase text-amber-700">{product.brand}</span>
                  <h3
                    onClick={() => onNavigate('product-details', { id: product.slug || product.id })}
                    className="font-bold text-neutral-900 text-sm hover:text-amber-600 line-clamp-1 cursor-pointer"
                  >
                    {product.name}
                  </h3>
                  <p className="font-extrabold text-neutral-950 text-base mt-1">
                    {formatPrice(product.salePrice || product.price)}
                  </p>
                </div>

                <div className="space-y-2 pt-2 border-t border-neutral-100">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-neutral-500 font-semibold">Select Size:</span>
                    <select
                      value={currentSize}
                      onChange={e =>
                        setSelectedSizes(prev => ({ ...prev, [product.id]: e.target.value as ShoeSize }))
                      }
                      className="px-2 py-1 bg-neutral-100 rounded-lg text-xs font-bold text-neutral-900 border border-neutral-200"
                    >
                      {product.availableSizes.map(sz => (
                        <option key={sz} value={sz}>
                          EU {sz}
                        </option>
                      ))}
                    </select>
                  </div>

                  <button
                    onClick={() => handleMoveToCart(product)}
                    className="w-full py-2.5 bg-neutral-900 hover:bg-black text-white text-xs font-bold uppercase tracking-wider rounded-xl flex items-center justify-center gap-1.5 shadow-md transition-colors cursor-pointer"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Move to Cart</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
