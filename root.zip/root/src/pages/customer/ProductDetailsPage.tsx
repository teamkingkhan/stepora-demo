import React, { useState, useEffect } from 'react';
import {
  Star,
  Heart,
  ShoppingBag,
  Truck,
  RotateCcw,
  ShieldCheck,
  Ruler,
  CheckCircle2,
  AlertCircle,
  Share2,
  ChevronRight,
  Plus,
  Minus,
  MessageSquare,
  Sparkles,
} from 'lucide-react';
import { Product, ShoeSize, ProductColor, Review } from '../../types';
import { api } from '../../services/api';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { useSettings } from '../../context/SettingsContext';
import { useToast } from '../../context/ToastContext';
import { ProductCard } from '../../components/common/ProductCard';
import { SizeGuideModal } from '../../components/common/SizeGuideModal';

interface ProductDetailsPageProps {
  productId: string;
  onNavigate: (page: string, params?: any) => void;
}

export const ProductDetailsPage: React.FC<ProductDetailsPageProps> = ({ productId, onNavigate }) => {
  const { addToCart } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { settings, formatPrice } = useSettings();
  const { showToast } = useToast();

  const [product, setProduct] = useState<Product | null>(null);
  const [related, setRelated] = useState<Product[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // User selections
  const [activeImage, setActiveImage] = useState<string>('');
  const [selectedSize, setSelectedSize] = useState<ShoeSize | null>(null);
  const [selectedColor, setSelectedColor] = useState<ProductColor | null>(null);
  const [quantity, setQuantity] = useState<number>(1);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);

  // Review form state
  const [reviewName, setReviewName] = useState('');
  const [reviewEmail, setReviewEmail] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewComment, setReviewComment] = useState('');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);

  useEffect(() => {
    const loadProductData = async () => {
      setIsLoading(true);
      try {
        const res = await api.getProductById(productId);
        if (res?.product) {
          setProduct(res.product);
          setRelated(res.related || []);
          setActiveImage(res.product.mainImage);
          setSelectedColor(res.product.availableColors?.[0] || null);

          // Find first available in-stock size
          const available = res.product.availableSizes.find(sz => {
            const stock = res.product.sizeStock?.find(s => s.size === sz)?.stock;
            return stock === undefined || stock > 0;
          });
          if (available) setSelectedSize(available);

          // Fetch reviews
          const revRes = await api.getProductReviews(res.product.id);
          setReviews(revRes.reviews || []);
        }
      } catch (err) {
        console.error('Failed to load product:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadProductData();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [productId]);

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 animate-pulse">
          <div className="aspect-square bg-neutral-200 rounded-3xl" />
          <div className="space-y-4">
            <div className="h-6 bg-neutral-200 rounded w-1/3" />
            <div className="h-10 bg-neutral-200 rounded w-3/4" />
            <div className="h-6 bg-neutral-200 rounded w-1/4" />
            <div className="h-24 bg-neutral-200 rounded" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center">
        <h2 className="text-2xl font-bold text-neutral-900">Product Not Found</h2>
        <p className="text-neutral-500 mt-2">Sorry, this product is currently unavailable or has been retired.</p>
        <button
          onClick={() => onNavigate('shop')}
          className="mt-6 px-6 py-3 bg-neutral-900 text-white rounded-xl font-bold text-sm"
        >
          Return to Footwear Shop
        </button>
      </div>
    );
  }

  const inWishlist = isInWishlist(product.id);
  const currentSizeStock = product.sizeStock?.find(s => s.size === selectedSize)?.stock ?? product.stockQuantity;
  const isOutOfStock = currentSizeStock <= 0;

  const handleAddToCart = () => {
    if (!selectedSize) {
      showToast('Please select a shoe size first', 'error');
      return;
    }
    addToCart(product, selectedSize, selectedColor || undefined, quantity);
  };

  const handleBuyNow = () => {
    if (!selectedSize) {
      showToast('Please select a shoe size first', 'error');
      return;
    }
    const success = addToCart(product, selectedSize, selectedColor || undefined, quantity);
    if (success) {
      onNavigate('checkout');
    }
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewName || !reviewComment) {
      showToast('Please provide your name and review details.', 'error');
      return;
    }

    setIsSubmittingReview(true);
    try {
      const res = await api.submitReview(product.id, {
        userName: reviewName,
        userEmail: reviewEmail,
        rating: reviewRating,
        title: reviewTitle || 'Customer Review',
        comment: reviewComment,
      });

      showToast(res.message || 'Review submitted successfully!', 'success');
      setReviews(prev => [res.review, ...prev]);
      setReviewName('');
      setReviewEmail('');
      setReviewTitle('');
      setReviewComment('');
    } catch (err: any) {
      showToast(err.message || 'Failed to submit review.', 'error');
    } finally {
      setIsSubmittingReview(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-16">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-neutral-400 font-medium">
        <button onClick={() => onNavigate('home')} className="hover:text-black cursor-pointer">
          Home
        </button>
        <span>/</span>
        <button onClick={() => onNavigate('shop')} className="hover:text-black cursor-pointer">
          Shop
        </button>
        <span>/</span>
        <button
          onClick={() => onNavigate('shop', { category: product.category })}
          className="capitalize hover:text-black cursor-pointer"
        >
          {product.category}
        </button>
        <span>/</span>
        <span className="text-neutral-900 font-bold truncate max-w-xs">{product.name}</span>
      </div>

      {/* Main Product Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 xl:gap-14">
        {/* Left: Gallery */}
        <div className="space-y-4">
          <div className="relative aspect-square w-full rounded-3xl overflow-hidden bg-neutral-100 border border-neutral-200/80 shadow-md">
            <img
              src={activeImage}
              alt={product.name}
              className="w-full h-full object-cover object-center transition-all duration-300"
            />
            {product.salePrice < product.price && (
              <span className="absolute top-4 left-4 px-3 py-1.5 bg-rose-600 text-white text-xs font-black uppercase rounded-xl shadow-md">
                -{product.discountPercentage}% OFF
              </span>
            )}
            <button
              onClick={() => toggleWishlist(product)}
              className="absolute top-4 right-4 p-3 rounded-full bg-white/90 backdrop-blur-md shadow-lg text-neutral-700 hover:text-rose-600 transition-colors cursor-pointer"
              aria-label="Wishlist"
            >
              <Heart className={`w-5 h-5 ${inWishlist ? 'fill-rose-600 text-rose-600' : ''}`} />
            </button>
          </div>

          {/* Thumbnails */}
          {product.images && product.images.length > 1 && (
            <div className="flex items-center gap-3 overflow-x-auto pb-2">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImage(img)}
                  className={`w-20 h-20 rounded-2xl overflow-hidden border-2 shrink-0 transition-all cursor-pointer ${
                    activeImage === img ? 'border-neutral-950 shadow-md scale-95' : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt={`${product.name} ${idx}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right: Info & Purchase Controls */}
        <div className="space-y-6">
          <div>
            <div className="flex items-center justify-between text-xs text-neutral-500 mb-1.5">
              <span className="font-extrabold uppercase tracking-widest text-amber-600 text-xs">
                {product.brand}
              </span>
              <span className="font-mono text-neutral-400">SKU: {product.sku}</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight leading-tight">
              {product.name}
            </h1>

            {/* Ratings & Reviews summary */}
            <div className="flex items-center gap-3 mt-2.5">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < Math.round(product.rating)
                        ? 'fill-amber-400 text-amber-400'
                        : 'fill-neutral-200 text-neutral-200'
                    }`}
                  />
                ))}
              </div>
              <span className="font-bold text-neutral-900 text-sm">{product.rating}</span>
              <span className="text-neutral-400 text-sm">•</span>
              <a href="#reviews" className="text-neutral-500 hover:text-black text-sm font-medium underline">
                {reviews.length} Customer Reviews
              </a>
            </div>
          </div>

          {/* Pricing */}
          <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200/80 flex items-baseline gap-3">
            <span className="text-3xl font-extrabold text-neutral-950">
              {formatPrice(product.salePrice || product.price)}
            </span>
            {product.salePrice < product.price && (
              <>
                <span className="text-lg text-neutral-400 line-through">
                  {formatPrice(product.price)}
                </span>
                <span className="text-xs font-black text-rose-600 uppercase bg-rose-50 px-2 py-0.5 rounded-md">
                  Save {formatPrice(product.price - product.salePrice)}
                </span>
              </>
            )}
          </div>

          {/* Short description */}
          <p className="text-sm text-neutral-600 leading-relaxed">
            {product.shortDescription || product.description}
          </p>

          {/* Colors Selection */}
          {product.availableColors && product.availableColors.length > 0 && (
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold uppercase tracking-wider text-neutral-600">
                  Color: <strong className="text-neutral-900">{selectedColor?.name}</strong>
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                {product.availableColors.map((color, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedColor(color)}
                    className={`group relative p-1 rounded-full border-2 transition-all cursor-pointer ${
                      selectedColor?.name === color.name
                        ? 'border-neutral-900 scale-110 shadow-sm'
                        : 'border-transparent hover:scale-105'
                    }`}
                  >
                    <span
                      className="block w-6 h-6 rounded-full border border-neutral-300"
                      style={{ backgroundColor: color.hex }}
                    />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Size Selector (36 to 46) */}
          <div className="space-y-2.5">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-600">
                Select EU Size:
              </span>
              <button
                onClick={() => setIsSizeGuideOpen(true)}
                className="text-xs text-amber-700 hover:text-amber-800 font-bold flex items-center gap-1 cursor-pointer"
              >
                <Ruler className="w-3.5 h-3.5" />
                <span>Size Guide & Chart</span>
              </button>
            </div>

            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
              {product.availableSizes.map(size => {
                const stock = product.sizeStock?.find(s => s.size === size)?.stock;
                const isAvailable = stock === undefined || stock > 0;
                const isSelected = selectedSize === size;

                return (
                  <button
                    key={size}
                    disabled={!isAvailable}
                    onClick={() => setSelectedSize(size)}
                    className={`py-3 rounded-xl text-xs font-bold flex flex-col items-center justify-center transition-all cursor-pointer ${
                      !isAvailable
                        ? 'bg-neutral-100 text-neutral-400 line-through border border-neutral-200 cursor-not-allowed'
                        : isSelected
                        ? 'bg-neutral-900 text-white shadow-md border-2 border-neutral-900'
                        : 'bg-white text-neutral-800 border border-neutral-300 hover:border-neutral-900'
                    }`}
                  >
                    <span className="text-sm font-extrabold">{size}</span>
                    <span className={`text-[10px] ${!isAvailable ? 'text-neutral-400' : isSelected ? 'text-amber-400' : 'text-neutral-500'}`}>
                      {!isAvailable ? 'Out' : stock !== undefined && stock <= 3 ? `${stock} left` : 'Available'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quantity Selector & Stock Status */}
          <div className="flex items-center gap-4">
            <div className="flex items-center border border-neutral-300 rounded-xl bg-white p-1">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                disabled={quantity <= 1}
                className="p-2 text-neutral-600 hover:text-black disabled:opacity-30 cursor-pointer"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="w-10 text-center font-bold text-sm text-neutral-900">{quantity}</span>
              <button
                onClick={() => setQuantity(Math.min(currentSizeStock, quantity + 1))}
                disabled={quantity >= currentSizeStock}
                className="p-2 text-neutral-600 hover:text-black disabled:opacity-30 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs">
              {isOutOfStock ? (
                <span className="text-rose-600 font-bold flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" />
                  Currently Out of Stock in Size {selectedSize}
                </span>
              ) : (
                <span className="text-emerald-700 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  In Stock ({currentSizeStock} pairs remaining)
                </span>
              )}
            </div>
          </div>

          {/* CTA Buttons: Add to Cart & Buy Now */}
          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <button
              onClick={handleAddToCart}
              disabled={isOutOfStock}
              className="flex-1 py-4 px-6 bg-neutral-900 hover:bg-black text-white font-extrabold text-sm uppercase tracking-wider rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer disabled:bg-neutral-300 disabled:cursor-not-allowed"
            >
              <ShoppingBag className="w-5 h-5" />
              <span>Add to Cart</span>
            </button>

            <button
              onClick={handleBuyNow}
              disabled={isOutOfStock}
              className="flex-1 py-4 px-6 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-extrabold text-sm uppercase tracking-wider rounded-2xl shadow-xl hover:shadow-amber-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:bg-neutral-300 disabled:cursor-not-allowed"
            >
              <Sparkles className="w-5 h-5" />
              <span>Buy Now</span>
            </button>
          </div>

          {/* Shipping & Guarantee badges */}
          <div className="pt-4 border-t border-neutral-200/80 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-neutral-600">
            <div className="flex items-center gap-2 p-3 bg-neutral-50 rounded-xl">
              <Truck className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Dhaka: 24-48h (৳{settings.insideDhakaShippingFee}) • Outside: ৳{settings.outsideDhakaShippingFee}</span>
            </div>
            <div className="flex items-center gap-2 p-3 bg-neutral-50 rounded-xl">
              <RotateCcw className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>7-Day Doorstep Size Replacement</span>
            </div>
          </div>
        </div>
      </div>

      {/* Specifications & Craftsmanship Tabs */}
      <div className="pt-10 border-t border-neutral-200">
        <h3 className="text-xl font-extrabold text-neutral-900 mb-6">Technical Specifications & Materials</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="p-5 rounded-2xl bg-white border border-neutral-200/80 shadow-xs">
            <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">Upper Construction</span>
            <p className="font-bold text-neutral-900 text-sm mt-1">{product.specifications?.upperMaterial || 'Full Grain Cowhide'}</p>
          </div>
          <div className="p-5 rounded-2xl bg-white border border-neutral-200/80 shadow-xs">
            <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">Outsole & Traction</span>
            <p className="font-bold text-neutral-900 text-sm mt-1">{product.specifications?.soleMaterial || 'Anti-Slip Vulcanized Rubber'}</p>
          </div>
          <div className="p-5 rounded-2xl bg-white border border-neutral-200/80 shadow-xs">
            <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">Insole Cushioning</span>
            <p className="font-bold text-neutral-900 text-sm mt-1">{product.specifications?.insole || 'Ergonomic Arch Memory Foam'}</p>
          </div>
          <div className="p-5 rounded-2xl bg-white border border-neutral-200/80 shadow-xs">
            <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">Closure Type</span>
            <p className="font-bold text-neutral-900 text-sm mt-1">{product.specifications?.closure || 'Speed Lacing'}</p>
          </div>
          <div className="p-5 rounded-2xl bg-white border border-neutral-200/80 shadow-xs">
            <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">Weight</span>
            <p className="font-bold text-neutral-900 text-sm mt-1">{product.specifications?.weight || '320g'}</p>
          </div>
          <div className="p-5 rounded-2xl bg-white border border-neutral-200/80 shadow-xs">
            <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">Manufacture Origin</span>
            <p className="font-bold text-neutral-900 text-sm mt-1">{product.specifications?.origin || 'Bangladesh'}</p>
          </div>
        </div>
      </div>

      {/* Customer Reviews Section */}
      <section id="reviews" className="pt-10 border-t border-neutral-200">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h3 className="text-2xl font-extrabold text-neutral-900">Customer Reviews</h3>
            <p className="text-xs text-neutral-500 mt-1">Real feedback from verified purchasers</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-amber-400 text-amber-400" />
              ))}
            </div>
            <span className="text-lg font-black text-neutral-900">{product.rating}</span>
            <span className="text-xs text-neutral-500">({reviews.length} reviews)</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Reviews List */}
          <div className="lg:col-span-2 space-y-4">
            {reviews.length === 0 ? (
              <p className="text-neutral-500 text-sm italic p-6 bg-white rounded-2xl border border-neutral-200 text-center">
                No reviews yet. Be the first to share your thoughts on this pair!
              </p>
            ) : (
              reviews.map(rev => (
                <div key={rev.id} className="p-6 bg-white rounded-2xl border border-neutral-200/80 shadow-xs space-y-2.5">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-neutral-900 text-sm">{rev.userName}</span>
                        {rev.isVerifiedPurchase && (
                          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            Verified Purchaser
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-neutral-400">{new Date(rev.createdAt).toLocaleDateString()}</p>
                    </div>
                    <div className="flex items-center gap-0.5">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-3.5 h-3.5 ${
                            i < rev.rating ? 'fill-amber-400 text-amber-400' : 'fill-neutral-200 text-neutral-200'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <h4 className="font-bold text-neutral-900 text-sm">{rev.title}</h4>
                  <p className="text-xs text-neutral-600 leading-relaxed">{rev.comment}</p>
                </div>
              ))
            )}
          </div>

          {/* Submit Review Form */}
          <div className="p-6 bg-white rounded-3xl border border-neutral-200/80 shadow-xs h-fit space-y-4">
            <h4 className="font-extrabold text-neutral-900 text-base">Write a Review</h4>
            <form onSubmit={handleReviewSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-neutral-600 mb-1">Your Rating</label>
                <div className="flex items-center gap-1.5 cursor-pointer">
                  {[1, 2, 3, 4, 5].map(star => (
                    <button
                      type="button"
                      key={star}
                      onClick={() => setReviewRating(star)}
                      className="p-1 hover:scale-110 transition-transform"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          star <= reviewRating ? 'fill-amber-400 text-amber-400' : 'fill-neutral-200 text-neutral-200'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-600 mb-1">Full Name</label>
                <input
                  type="text"
                  value={reviewName}
                  onChange={e => setReviewName(e.target.value)}
                  placeholder="e.g. Tanvir Ahmed"
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-neutral-300 focus:outline-none focus:border-neutral-900"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-600 mb-1">Email</label>
                <input
                  type="email"
                  value={reviewEmail}
                  onChange={e => setReviewEmail(e.target.value)}
                  placeholder="e.g. tanvir@example.com"
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-neutral-300 focus:outline-none focus:border-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-600 mb-1">Headline</label>
                <input
                  type="text"
                  value={reviewTitle}
                  onChange={e => setReviewTitle(e.target.value)}
                  placeholder="Summary of your experience..."
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-neutral-300 focus:outline-none focus:border-neutral-900"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-600 mb-1">Review</label>
                <textarea
                  rows={3}
                  value={reviewComment}
                  onChange={e => setReviewComment(e.target.value)}
                  placeholder="Tell other shoe enthusiasts about the fit, comfort, and leather feel..."
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-neutral-300 focus:outline-none focus:border-neutral-900"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isSubmittingReview}
                className="w-full py-3 bg-neutral-900 hover:bg-black text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors cursor-pointer"
              >
                {isSubmittingReview ? 'Submitting...' : 'Post Review'}
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Related Products */}
      {related.length > 0 && (
        <section className="pt-10 border-t border-neutral-200">
          <h3 className="text-2xl font-extrabold text-neutral-900 mb-6">You May Also Like</h3>
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {related.map(p => (
              <ProductCard key={p.id} product={p} onNavigate={onNavigate} />
            ))}
          </div>
        </section>
      )}

      {/* Size Guide Modal */}
      <SizeGuideModal isOpen={isSizeGuideOpen} onClose={() => setIsSizeGuideOpen(false)} />
    </div>
  );
};
