import React, { useState, useEffect } from 'react';
import {
  Truck,
  Search,
  Package,
  CheckCircle2,
  Clock,
  MapPin,
  AlertCircle,
  Printer,
  ChevronRight,
} from 'lucide-react';
import { api } from '../../services/api';
import { Order, OrderStatus } from '../../types';
import { useSettings } from '../../context/SettingsContext';
import { InvoiceModal } from '../../components/common/InvoiceModal';

interface TrackOrderPageProps {
  initialQuery?: string;
  onNavigate: (page: string, params?: any) => void;
}

const TIMELINE_STEPS: { status: OrderStatus; label: string; desc: string }[] = [
  { status: 'Pending', label: 'Order Placed', desc: 'Received and awaiting warehouse queuing' },
  { status: 'Confirmed', label: 'Confirmed', desc: 'Payment verified & order approved' },
  { status: 'Processing', label: 'Packed & Dispatched', desc: 'Securely packaged in dust bag' },
  { status: 'Out for Delivery', label: 'Out for Delivery', desc: 'Rider is on the way to your doorstep' },
  { status: 'Delivered', label: 'Delivered', desc: 'Package received & signed by customer' },
];

export const TrackOrderPage: React.FC<TrackOrderPageProps> = ({ initialQuery = '', onNavigate }) => {
  const { formatPrice } = useSettings();
  const [query, setQuery] = useState(initialQuery);
  const [order, setOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false);

  const handleTrack = async (searchVal: string) => {
    if (!searchVal.trim()) return;
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const res = await api.trackOrder(searchVal.trim());
      setOrder(res.order);
    } catch (err: any) {
      setOrder(null);
      setErrorMessage(err.message || 'No order found matching your tracking details.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (initialQuery) {
      handleTrack(initialQuery);
    }
  }, [initialQuery]);

  const getStepState = (targetStatus: OrderStatus) => {
    if (!order) return 'upcoming';
    const statusOrder: OrderStatus[] = [
      'Pending',
      'Confirmed',
      'Processing',
      'Packed',
      'Shipped',
      'Out for Delivery',
      'Delivered',
    ];
    const currentIndex = statusOrder.indexOf(order.orderStatus);
    const targetIndex = statusOrder.indexOf(targetStatus);

    if (order.orderStatus === 'Cancelled') return 'cancelled';
    if (currentIndex >= targetIndex) return 'completed';
    return 'upcoming';
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Header */}
      <div className="text-center max-w-xl mx-auto space-y-2">
        <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-600 flex items-center justify-center mx-auto mb-2">
          <Truck className="w-6 h-6" />
        </div>
        <h1 className="text-3xl font-extrabold text-neutral-900 tracking-tight">
          Track Your Footwear Order
        </h1>
        <p className="text-xs text-neutral-500">
          Enter your Order Number (e.g. <strong>ORD-2026-000101</strong>) or your Bangladeshi Mobile Number to track delivery status.
        </p>
      </div>

      {/* Tracking Search Input */}
      <div className="max-w-xl mx-auto">
        <form
          onSubmit={e => {
            e.preventDefault();
            handleTrack(query);
          }}
          className="flex gap-2"
        >
          <div className="relative flex-1">
            <input
              type="text"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="e.g. ORD-2026-000101 or 017XXXXXXXX"
              className="w-full pl-10 pr-4 py-3.5 bg-white border border-neutral-300 rounded-2xl text-sm font-semibold focus:outline-none focus:border-neutral-900 shadow-xs"
              required
            />
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          </div>
          <button
            type="submit"
            disabled={isLoading}
            className="px-6 py-3.5 bg-neutral-900 hover:bg-black text-white text-xs font-bold uppercase tracking-wider rounded-2xl shadow-md transition-colors cursor-pointer"
          >
            {isLoading ? 'Searching...' : 'Track'}
          </button>
        </form>

        {errorMessage && (
          <div className="mt-4 p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}
      </div>

      {/* Tracking Result View */}
      {order && (
        <div className="bg-white rounded-3xl border border-neutral-200/80 shadow-xs p-6 sm:p-8 space-y-8 animate-in fade-in">
          {/* Status summary header */}
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 pb-6 border-b border-neutral-100">
            <div>
              <span className="text-[11px] font-mono text-neutral-400 uppercase">Tracking Details for</span>
              <h2 className="text-2xl font-extrabold text-neutral-900 mt-0.5">{order.orderNumber}</h2>
              <p className="text-xs text-neutral-500">
                Ordered on {new Date(order.createdAt).toLocaleDateString()}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <span
                className={`px-4 py-1.5 rounded-full text-xs font-extrabold uppercase tracking-wider shadow-2xs ${
                  order.orderStatus === 'Delivered'
                    ? 'bg-emerald-100 text-emerald-800'
                    : order.orderStatus === 'Cancelled'
                    ? 'bg-rose-100 text-rose-800'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                {order.orderStatus}
              </span>
              <button
                onClick={() => setIsInvoiceOpen(true)}
                className="p-2 text-neutral-600 hover:text-black rounded-xl border border-neutral-200 hover:bg-neutral-50 cursor-pointer"
                title="View Invoice"
              >
                <Printer className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Timeline Visualizer */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-500">
              Delivery Progress
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
              {TIMELINE_STEPS.map((step, idx) => {
                const state = getStepState(step.status);
                return (
                  <div
                    key={idx}
                    className={`p-4 rounded-2xl border transition-all ${
                      state === 'completed'
                        ? 'bg-emerald-50/60 border-emerald-200 text-emerald-950'
                        : 'bg-neutral-50/50 border-neutral-200 text-neutral-400'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1.5">
                      {state === 'completed' ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      ) : (
                        <Clock className="w-4 h-4 text-neutral-400 shrink-0" />
                      )}
                      <span className="font-extrabold text-xs">{step.label}</span>
                    </div>
                    <p className="text-[11px] leading-tight text-neutral-500">{step.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Destination & Order Items */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-neutral-100 text-xs">
            {/* Delivery address */}
            <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-200 space-y-1.5">
              <h4 className="font-bold text-neutral-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-amber-600" />
                <span>Shipping Destination</span>
              </h4>
              <p className="font-bold text-neutral-900">{order.shippingAddress.fullName}</p>
              <p className="text-neutral-600">{order.shippingAddress.phoneNumber}</p>
              <p className="text-neutral-600">
                {order.shippingAddress.fullAddress}, {order.shippingAddress.area}, {order.shippingAddress.district}
              </p>
            </div>

            {/* Items */}
            <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-200 space-y-2">
              <h4 className="font-bold text-neutral-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                <Package className="w-3.5 h-3.5 text-amber-600" />
                <span>Items in Parcel ({order.items.length})</span>
              </h4>
              <div className="space-y-2 max-h-36 overflow-y-auto">
                {order.items.map((it, idx) => (
                  <div key={idx} className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-neutral-800 truncate max-w-[200px]">
                      {it.productName} (EU {it.selectedSize})
                    </span>
                    <span className="font-bold text-neutral-900">{formatPrice(it.itemTotal)}</span>
                  </div>
                ))}
              </div>
              <div className="pt-2 border-t border-neutral-200 flex justify-between font-extrabold text-sm text-neutral-900">
                <span>Grand Total:</span>
                <span className="text-amber-600">{formatPrice(order.total)}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {order && (
        <InvoiceModal order={order} isOpen={isInvoiceOpen} onClose={() => setIsInvoiceOpen(false)} />
      )}
    </div>
  );
};
