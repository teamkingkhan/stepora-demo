import React, { useState, useEffect } from 'react';
import {
  ArrowRight,
  ShieldCheck,
  Truck,
  RotateCcw,
  Sparkles,
  Award,
  Star,
  ChevronRight,
  Flame,
  CheckCircle2,
} from 'lucide-react';
import { Product, Category } from '../../types';
import { api } from '../../services/api';
import { ProductCard } from '../../components/common/ProductCard';
import { useSettings } from '../../context/SettingsContext';

interface HomePageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const { settings, formatPrice } = useSettings();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [prodRes, catRes] = await Promise.all([
          api.getProducts({ limit: '24' }),
          api.getCategories(),
        ]);
        setProducts(prodRes.products || []);
        setCategories(catRes.categories || []);
      } catch (err) {
        console.error('Home load error:', err);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  const featuredProducts = products.filter(p => p.featured).slice(0, 4);
  const bestSellers = products.filter(p => p.bestSeller).slice(0, 8);
  const newArrivals = products.filter(p => p.newArrival).slice(0, 8);
  const discountProducts = products.filter(p => p.discountPercentage > 0).slice(0, 4);

  return (
    <div className="space-y-16 sm:space-y-24">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden bg-neutral-900 text-white rounded-3xl mx-4 sm:mx-6 lg:mx-8 mt-4 shadow-2xl">
        <div className="absolute inset-0 z-0 opacity-40">
          <img
            src="https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=1800&q=80"
            alt="Hero Footwear"
            className="w-full h-full object-cover object-center filter brightness-75 scale-105 transform hover:scale-100 transition-transform duration-1000"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-neutral-950 via-neutral-950/80 to-transparent" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-12 lg:px-16 py-20 sm:py-28 lg:py-36">
          <div className="max-w-2xl space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-amber-400 text-xs font-extrabold tracking-widest uppercase shadow-sm">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Autumn / Winter 2026 Collection</span>
            </div>

            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight leading-[1.08] text-white">
              Step Into <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-200 to-amber-500">
                Your Style.
              </span>
            </h1>

            <p className="text-base sm:text-lg text-neutral-300 leading-relaxed font-normal max-w-lg">
              Engineered with premium calfskin leathers, responsive nitrogen-cushion foam, and handcrafted durability. Designed in Dhaka for world-class strides.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={() => onNavigate('shop')}
                className="px-8 py-4 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold rounded-2xl text-sm sm:text-base shadow-xl hover:shadow-amber-500/30 transition-all transform hover:-translate-y-0.5 flex items-center gap-2.5 cursor-pointer"
              >
                <span>Shop Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onNavigate('categories')}
                className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white font-semibold rounded-2xl text-sm sm:text-base backdrop-blur-md border border-white/20 transition-all cursor-pointer"
              >
                Explore Collection
              </button>
            </div>

            {/* Quick Hero Highlights */}
            <div className="pt-8 border-t border-neutral-800 grid grid-cols-3 gap-4 text-xs text-neutral-300">
              <div>
                <p className="font-extrabold text-xl sm:text-2xl text-white">100%</p>
                <p className="text-neutral-400 text-[11px] sm:text-xs">Genuine Materials</p>
              </div>
              <div>
                <p className="font-extrabold text-xl sm:text-2xl text-white">7 Days</p>
                <p className="text-neutral-400 text-[11px] sm:text-xs">Doorstep Exchange</p>
              </div>
              <div>
                <p className="font-extrabold text-xl sm:text-2xl text-white">24-48h</p>
                <p className="text-neutral-400 text-[11px] sm:text-xs">Dhaka Delivery</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US STRIP */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-6 rounded-2xl bg-white border border-neutral-200/80 shadow-xs flex items-start gap-4">
            <div className="p-3 bg-amber-50 text-amber-600 rounded-xl shrink-0">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-neutral-900 text-sm">Swift Nationwide Shipping</h4>
              <p className="text-xs text-neutral-500 mt-1">Inside Dhaka within 24-48h, across 64 districts in 2-4 days.</p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-neutral-200/80 shadow-xs flex items-start gap-4">
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl shrink-0">
              <RotateCcw className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-neutral-900 text-sm">7-Day Size Exchange</h4>
              <p className="text-xs text-neutral-500 mt-1">Doesn't fit? We will swap the size directly at your doorstep.</p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-neutral-200/80 shadow-xs flex items-start gap-4">
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-neutral-900 text-sm">Authentic Craftsmanship</h4>
              <p className="text-xs text-neutral-500 mt-1">Hand-selected leathers & high-abrasion non-slip outsoles.</p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-neutral-200/80 shadow-xs flex items-start gap-4">
            <div className="p-3 bg-rose-50 text-rose-600 rounded-xl shrink-0">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-neutral-900 text-sm">bKash, Nagad & COD</h4>
              <p className="text-xs text-neutral-500 mt-1">Convenient Bangladesh digital wallets or pay cash upon receipt.</p>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURED CATEGORIES CIRCLES / CARDS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-8">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-600">Curated Collections</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 mt-0.5">Explore by Category</h2>
          </div>
          <button
            onClick={() => onNavigate('categories')}
            className="text-xs sm:text-sm font-bold text-neutral-900 hover:text-amber-600 flex items-center gap-1 cursor-pointer transition-colors"
          >
            <span>View All Categories</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.slice(0, 6).map(cat => (
            <div
              key={cat.id}
              onClick={() => onNavigate('shop', { category: cat.slug })}
              className="group relative rounded-2xl overflow-hidden aspect-4/5 bg-neutral-100 shadow-sm cursor-pointer transform hover:-translate-y-1 transition-all duration-300"
            >
              <img
                src={cat.image}
                alt={cat.name}
                className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/80 via-neutral-950/20 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-4 text-white">
                <p className="font-bold text-sm sm:text-base leading-tight group-hover:text-amber-300 transition-colors">
                  {cat.name}
                </p>
                <p className="text-[11px] text-neutral-300 font-medium mt-0.5">
                  {cat.itemCount} items
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* TRENDING / BEST SELLERS SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-8">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-amber-600">
              <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
              <span>Most Loved by Customers</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 mt-0.5">Best Sellers</h2>
          </div>
          <button
            onClick={() => onNavigate('shop', { sort: 'best-selling' })}
            className="text-xs sm:text-sm font-bold text-neutral-900 hover:text-amber-600 flex items-center gap-1 cursor-pointer transition-colors"
          >
            <span>See More</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {bestSellers.map(product => (
            <ProductCard key={product.id} product={product} onNavigate={onNavigate} />
          ))}
        </div>
      </section>

      {/* PROMOTIONAL SHOWCASE BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-neutral-950 text-white shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-2 items-center">
            <div className="p-8 sm:p-14 lg:p-16 space-y-6 z-10">
              <span className="px-3 py-1 bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-extrabold uppercase rounded-full tracking-widest">
                Artisanal Heritage
              </span>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight leading-tight">
                Goodyear Welted <br />
                <span className="text-amber-400">Formal Excellence.</span>
              </h2>
              <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
                Hand-stained Argentine crust leathers, closed lacing, and 200+ precision steps per shoe. Built to be recrafted for decades of commanding elegance.
              </p>
              <div className="pt-2 flex items-center gap-4">
                <button
                  onClick={() => onNavigate('shop', { category: 'formal' })}
                  className="px-6 py-3.5 bg-white hover:bg-neutral-100 text-neutral-950 font-extrabold rounded-xl text-sm transition-all shadow-md cursor-pointer"
                >
                  Explore Formal Footwear
                </button>
                <span className="text-xs text-neutral-400 font-semibold">
                  Starting from ৳ 5,850
                </span>
              </div>
            </div>
            <div className="relative h-72 sm:h-96 lg:h-full min-h-[380px]">
              <img
                src="https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?auto=format&fit=crop&w=1000&q=80"
                alt="Formal Leather Shoes"
                className="w-full h-full object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-neutral-950 via-neutral-950/40 to-transparent" />
            </div>
          </div>
        </div>
      </section>

      {/* NEW ARRIVALS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-8">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-600">Fresh Drops</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 mt-0.5">New Arrivals</h2>
          </div>
          <button
            onClick={() => onNavigate('shop', { newArrival: 'true' })}
            className="text-xs sm:text-sm font-bold text-neutral-900 hover:text-amber-600 flex items-center gap-1 cursor-pointer transition-colors"
          >
            <span>View All New</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {newArrivals.map(product => (
            <ProductCard key={product.id} product={product} onNavigate={onNavigate} />
          ))}
        </div>
      </section>

      {/* DUAL SPOTLIGHT: MEN & WOMEN */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Men's Spotlight */}
          <div
            onClick={() => onNavigate('shop', { gender: 'men' })}
            className="group relative rounded-3xl overflow-hidden aspect-16/10 bg-neutral-900 text-white cursor-pointer shadow-lg"
          >
            <img
              src="https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=1000&q=80"
              alt="Men's Footwear"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/40 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-6 sm:p-8">
              <span className="text-xs font-bold uppercase tracking-widest text-amber-400">Gents Collection</span>
              <h3 className="text-2xl sm:text-3xl font-extrabold mt-1">The Men's Edit</h3>
              <p className="text-xs sm:text-sm text-neutral-300 mt-1 max-w-xs">
                Performance runners, Italian style loafers, and heritage leather oxfords.
              </p>
              <div className="mt-4 inline-flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-white group-hover:text-amber-400 transition-colors">
                <span>Shop Men</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Women's Spotlight */}
          <div
            onClick={() => onNavigate('shop', { gender: 'women' })}
            className="group relative rounded-3xl overflow-hidden aspect-16/10 bg-neutral-900 text-white cursor-pointer shadow-lg"
          >
            <img
              src="https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=1000&q=80"
              alt="Women's Footwear"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/40 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-6 sm:p-8">
              <span className="text-xs font-bold uppercase tracking-widest text-rose-300">Ladies Collection</span>
              <h3 className="text-2xl sm:text-3xl font-extrabold mt-1">The Women's Edit</h3>
              <p className="text-xs sm:text-sm text-neutral-300 mt-1 max-w-xs">
                Featherlight cloud runners, festive block heels, and chic knit slip-ons.
              </p>
              <div className="mt-4 inline-flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-white group-hover:text-rose-300 transition-colors">
                <span>Shop Women</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CUSTOMER REVIEWS & TESTIMONIALS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-widest text-amber-600">Verified Customer Stories</span>
          <h2 className="text-3xl font-extrabold text-neutral-900 mt-1">Trusted Across Bangladesh</h2>
          <p className="text-neutral-500 text-sm mt-2">
            Over 15,000+ shoe enthusiasts, athletes, and professionals wear STEPORA daily.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-8 rounded-3xl bg-white border border-neutral-200/80 shadow-xs flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-1 text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400" />
                ))}
              </div>
              <p className="text-neutral-800 text-sm leading-relaxed font-medium">
                "The Apex Nitro runners are unmatched. I run 10k regularly at Hatirjheel and had constant heel pain with other local brands. STEPORA gives the exact bounce and arch support I needed."
              </p>
            </div>
            <div className="pt-6 border-t border-neutral-100 flex items-center gap-3 mt-6">
              <div className="w-10 h-10 rounded-full bg-neutral-900 text-white font-bold flex items-center justify-center text-sm">
                TH
              </div>
              <div>
                <p className="font-bold text-neutral-900 text-sm">Tanvir Hossain</p>
                <div className="flex items-center gap-1 text-emerald-600 text-xs">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Verified Buyer • Dhaka</span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-8 rounded-3xl bg-white border border-neutral-200/80 shadow-xs flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-1 text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400" />
                ))}
              </div>
              <p className="text-neutral-800 text-sm leading-relaxed font-medium">
                "Ordered the Napa White Sneakers. The leather is so supple right out of the box, no break-in blisters. Delivery took only 24 hours to Dhanmondi with Cash on Delivery."
              </p>
            </div>
            <div className="pt-6 border-t border-neutral-100 flex items-center gap-3 mt-6">
              <div className="w-10 h-10 rounded-full bg-neutral-900 text-white font-bold flex items-center justify-center text-sm">
                SR
              </div>
              <div>
                <p className="font-bold text-neutral-900 text-sm">Sadia Rahman</p>
                <div className="flex items-center gap-1 text-emerald-600 text-xs">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Verified Buyer • Dhanmondi</span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-8 rounded-3xl bg-white border border-neutral-200/80 shadow-xs flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-1 text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400" />
                ))}
              </div>
              <p className="text-neutral-800 text-sm leading-relaxed font-medium">
                "The Goodyear Welt Oxford is genuinely European luxury grade. Solid oak leather sole, immaculate stitchwork. Wearing them to my wedding reception!"
              </p>
            </div>
            <div className="pt-6 border-t border-neutral-100 flex items-center gap-3 mt-6">
              <div className="w-10 h-10 rounded-full bg-neutral-900 text-white font-bold flex items-center justify-center text-sm">
                MH
              </div>
              <div>
                <p className="font-bold text-neutral-900 text-sm">Mahmudul Hasan</p>
                <div className="flex items-center gap-1 text-emerald-600 text-xs">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Verified Buyer • Chittagong</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
