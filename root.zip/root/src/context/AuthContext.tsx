import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { api } from '../services/api';

interface AuthContextType {
  user: User | null;
  admin: User | null;
  isCustomerAuthenticated: boolean;
  isAdminAuthenticated: boolean;
  customerLogin: (credentials: any) => Promise<User>;
  customerRegister: (userData: any) => Promise<User>;
  customerLogout: () => void;
  adminLogin: (credentials: any) => Promise<{ admin: User; isDefaultPassword?: boolean }>;
  adminLogout: () => void;
  updateCustomerProfile: (data: any) => Promise<void>;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [admin, setAdmin] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Restore authenticated sessions
  useEffect(() => {
    const restoreAuth = async () => {
      // Customer
      const custToken = localStorage.getItem('stepora_customer_token');
      if (custToken) {
        try {
          const res = await api.getMe();
          if (res?.user) setUser(res.user);
        } catch {
          localStorage.removeItem('stepora_customer_token');
        }
      }

      // Admin
      const admToken = localStorage.getItem('stepora_admin_token');
      if (admToken) {
        try {
          const res = await api.getAdminMe();
          if (res?.admin) setAdmin(res.admin);
        } catch {
          localStorage.removeItem('stepora_admin_token');
        }
      }

      setIsLoading(false);
    };

    restoreAuth();
  }, []);

  const customerLogin = async (credentials: any) => {
    const res = await api.login(credentials);
    localStorage.setItem('stepora_customer_token', res.token);
    setUser(res.user);
    return res.user;
  };

  const customerRegister = async (userData: any) => {
    const res = await api.register(userData);
    localStorage.setItem('stepora_customer_token', res.token);
    setUser(res.user);
    return res.user;
  };

  const customerLogout = () => {
    localStorage.removeItem('stepora_customer_token');
    setUser(null);
  };

  const adminLogin = async (credentials: any) => {
    const res = await api.adminLogin(credentials);
    localStorage.setItem('stepora_admin_token', res.token);
    setAdmin(res.admin);
    return { admin: res.admin, isDefaultPassword: res.isDefaultPassword };
  };

  const adminLogout = () => {
    localStorage.removeItem('stepora_admin_token');
    setAdmin(null);
  };

  const updateCustomerProfile = async (data: any) => {
    const res = await api.updateProfile(data);
    setUser(res.user);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        admin,
        isCustomerAuthenticated: Boolean(user),
        isAdminAuthenticated: Boolean(admin),
        customerLogin,
        customerRegister,
        customerLogout,
        adminLogin,
        adminLogout,
        updateCustomerProfile,
        isLoading,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
