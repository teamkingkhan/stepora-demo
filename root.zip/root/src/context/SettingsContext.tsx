import React, { createContext, useContext, useState, useEffect } from 'react';
import { StoreSettings } from '../types';
import { api } from '../services/api';

interface SettingsContextType {
  settings: StoreSettings;
  formatPrice: (amount: number) => string;
  refreshSettings: () => Promise<void>;
  isLoading: boolean;
}

const DEFAULT_SETTINGS: StoreSettings = {
  storeName: 'STEPORA Footwear',
  logoUrl: '/stepora-logo.svg',
  storeEmail: 'support@stepora.com.bd',
  storePhone: '+880 1712 345678',
  storeAddress: 'House 42, Road 11, Banani, Dhaka-1213, Bangladesh',
  currency: '৳',
  currencyCode: 'BDT',
  insideDhakaShippingFee: 80,
  outsideDhakaShippingFee: 150,
  freeShippingThreshold: 3500,
  taxPercentage: 0,
  enableBkash: true,
  enableNagad: true,
  enableCard: true,
  enableCod: true,
  paymentTestMode: true,
  facebookUrl: 'https://facebook.com',
  instagramUrl: 'https://instagram.com',
  youtubeUrl: 'https://youtube.com',
  tiktokUrl: 'https://tiktok.com',
};

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<StoreSettings>(DEFAULT_SETTINGS);
  const [isLoading, setIsLoading] = useState(true);

  const refreshSettings = async () => {
    try {
      const data = await api.getSettings();
      if (data?.settings) {
        setSettings(data.settings);
      }
    } catch (err) {
      console.warn('Failed to fetch settings from server, using defaults:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshSettings();
  }, []);

  const formatPrice = (amount: number): string => {
    if (isNaN(amount) || amount === null || amount === undefined) return `${settings.currency} 0`;
    const rounded = Math.round(amount);
    const formattedNum = new Intl.NumberFormat('en-BD').format(rounded);
    return `${settings.currency} ${formattedNum}`;
  };

  return (
    <SettingsContext.Provider value={{ settings, formatPrice, refreshSettings, isLoading }}>
      {children}
    </SettingsContext.Provider>
  );
};

export function useSettings() {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}
