import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem, Product, ShoeSize, ProductColor } from '../types';
import { useSettings } from './SettingsContext';
import { useToast } from './ToastContext';
import { api } from '../services/api';

interface CartContextType {
  cart: CartItem[];
  addToCart: (product: Product, selectedSize: ShoeSize, selectedColor?: ProductColor, quantity?: number) => boolean;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, newQty: number) => void;
  updateItemSize: (cartItemId: string, newSize: ShoeSize) => void;
  updateItemColor: (cartItemId: string, newColor: ProductColor) => void;
  clearCart: () => void;
  totalItemCount: number;
  subtotal: number;
  shippingRegion: 'inside_dhaka' | 'outside_dhaka';
  setShippingRegion: (region: 'inside_dhaka' | 'outside_dhaka') => void;
  shippingFee: number;
  couponCode: string;
  couponDiscount: number;
  couponError: string | null;
  isApplyingCoupon: boolean;
  applyCoupon: (code: string) => Promise<boolean>;
  removeCoupon: () => void;
  grandTotal: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

const CART_STORAGE_KEY = 'stepora_cart_v1';
const COUPON_STORAGE_KEY = 'stepora_applied_coupon_v1';

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { settings } = useSettings();
  const { showToast } = useToast();

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const stored = localStorage.getItem(CART_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [shippingRegion, setShippingRegion] = useState<'inside_dhaka' | 'outside_dhaka'>('inside_dhaka');
  const [couponCode, setCouponCode] = useState<string>(() => {
    try {
      return localStorage.getItem(COUPON_STORAGE_KEY) || '';
    } catch {
      return '';
    }
  });
  const [couponDiscount, setCouponDiscount] = useState<number>(0);
  const [couponError, setCouponError] = useState<string | null>(null);
  const [isApplyingCoupon, setIsApplyingCoupon] = useState<boolean>(false);

  // Persist cart to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
    } catch (e) {
      console.error('Failed to save cart:', e);
    }
  }, [cart]);

  // Subtotal calculation
  const subtotal = cart.reduce((acc, item) => acc + (item.salePrice || item.price) * item.quantity, 0);

  // Recalculate coupon discount whenever subtotal changes
  useEffect(() => {
    if (couponCode && subtotal > 0) {
      api
        .applyCoupon(couponCode, subtotal)
        .then(res => {
          if (res.valid) {
            setCouponDiscount(res.discountAmount);
            setCouponError(null);
          } else {
            setCouponDiscount(0);
          }
        })
        .catch(() => {
          setCouponDiscount(0);
        });
    } else {
      setCouponDiscount(0);
    }
  }, [subtotal, couponCode]);

  // Shipping calculation
  let shippingFee = 0;
  if (cart.length > 0) {
    if (subtotal >= settings.freeShippingThreshold) {
      shippingFee = 0;
    } else {
      shippingFee = shippingRegion === 'outside_dhaka' ? settings.outsideDhakaShippingFee : settings.insideDhakaShippingFee;
    }
  }

  const grandTotal = Math.max(0, subtotal - couponDiscount + shippingFee);
  const totalItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const addToCart = (product: Product, selectedSize: ShoeSize, selectedColor?: ProductColor, quantity = 1): boolean => {
    if (!selectedSize) {
      showToast('Please select your shoe size before adding to cart', 'error');
      return false;
    }

    // Check size stock
    const sStock = product.sizeStock?.find(s => s.size === selectedSize);
    const maxAvailable = sStock ? sStock.stock : product.stockQuantity;

    if (maxAvailable <= 0) {
      showToast(`Size ${selectedSize} is currently out of stock`, 'error');
      return false;
    }

    const color = selectedColor || product.availableColors[0] || { name: 'Standard', hex: '#000000' };
    const cartItemId = `${product.id}-${selectedSize}-${color.name.replace(/\s+/g, '')}`;

    setCart(prev => {
      const existingIndex = prev.findIndex(item => item.id === cartItemId);
      if (existingIndex > -1) {
        const updated = [...prev];
        const newQty = Math.min(updated[existingIndex].quantity + quantity, maxAvailable);
        updated[existingIndex].quantity = newQty;
        return updated;
      } else {
        const newItem: CartItem = {
          id: cartItemId,
          productId: product.id,
          name: product.name,
          slug: product.slug,
          price: product.price,
          salePrice: product.salePrice || product.price,
          image: product.mainImage,
          brand: product.brand,
          selectedSize,
          selectedColor: color,
          quantity: Math.min(quantity, maxAvailable),
          maxStock: maxAvailable,
        };
        return [...prev, newItem];
      }
    });

    showToast(`Added ${product.name} (Size ${selectedSize}) to cart!`, 'success');
    return true;
  };

  const removeFromCart = (cartItemId: string) => {
    setCart(prev => {
      const item = prev.find(i => i.id === cartItemId);
      if (item) {
        showToast(`Removed ${item.name} from cart`, 'info');
      }
      return prev.filter(i => i.id !== cartItemId);
    });
  };

  const updateQuantity = (cartItemId: string, newQty: number) => {
    if (newQty <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setCart(prev =>
      prev.map(item => {
        if (item.id === cartItemId) {
          const clamped = Math.min(newQty, item.maxStock || 99);
          return { ...item, quantity: clamped };
        }
        return item;
      })
    );
  };

  const updateItemSize = (cartItemId: string, newSize: ShoeSize) => {
    setCart(prev =>
      prev.map(item => {
        if (item.id === cartItemId) {
          const newId = `${item.productId}-${newSize}-${item.selectedColor.name.replace(/\s+/g, '')}`;
          return { ...item, id: newId, selectedSize: newSize };
        }
        return item;
      })
    );
  };

  const updateItemColor = (cartItemId: string, newColor: ProductColor) => {
    setCart(prev =>
      prev.map(item => {
        if (item.id === cartItemId) {
          const newId = `${item.productId}-${item.selectedSize}-${newColor.name.replace(/\s+/g, '')}`;
          return { ...item, id: newId, selectedColor: newColor };
        }
        return item;
      })
    );
  };

  const clearCart = () => {
    setCart([]);
    setCouponCode('');
    setCouponDiscount(0);
    localStorage.removeItem(CART_STORAGE_KEY);
    localStorage.removeItem(COUPON_STORAGE_KEY);
  };

  const applyCoupon = async (code: string): Promise<boolean> => {
    if (!code || !code.trim()) {
      setCouponError('Please enter a coupon code.');
      return false;
    }

    setIsApplyingCoupon(true);
    setCouponError(null);

    try {
      const res = await api.applyCoupon(code, subtotal);
      if (res.valid) {
        setCouponCode(res.code);
        setCouponDiscount(res.discountAmount);
        localStorage.setItem(COUPON_STORAGE_KEY, res.code);
        showToast(`Coupon "${res.code}" applied! You saved ${settings.currency} ${res.discountAmount}`, 'success');
        setIsApplyingCoupon(false);
        return true;
      }
      return false;
    } catch (err: any) {
      setCouponError(err.message || 'Invalid coupon.');
      showToast(err.message || 'Invalid coupon.', 'error');
      setIsApplyingCoupon(false);
      return false;
    }
  };

  const removeCoupon = () => {
    setCouponCode('');
    setCouponDiscount(0);
    setCouponError(null);
    localStorage.removeItem(COUPON_STORAGE_KEY);
    showToast('Coupon removed.', 'info');
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        updateItemSize,
        updateItemColor,
        clearCart,
        totalItemCount,
        subtotal,
        shippingRegion,
        setShippingRegion,
        shippingFee,
        couponCode,
        couponDiscount,
        couponError,
        isApplyingCoupon,
        applyCoupon,
        removeCoupon,
        grandTotal,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
