import React, { useState } from 'react';
import { X, ShieldCheck, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { Order, PaymentMethod } from '../../types';
import { useSettings } from '../../context/SettingsContext';
import { api } from '../../services/api';
import { useToast } from '../../context/ToastContext';

interface PaymentModalProps {
  order: Order;
  isOpen: boolean;
  onSuccess: (updatedOrder: Order) => void;
  onCancel: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({ order, isOpen, onSuccess, onCancel }) => {
  const { formatPrice } = useSettings();
  const { showToast } = useToast();

  const [step, setStep] = useState<'input' | 'otp' | 'pin' | 'processing'>('input');
  const [walletNumber, setWalletNumber] = useState(order.customerPhone || '01700000000');
  const [otp, setOtp] = useState('123456');
  const [pin, setPin] = useState('');
  const [cardNumber, setCardNumber] = useState('4242 •••• •••• 4242');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvc, setCardCvc] = useState('123');
  const [cardName, setCardName] = useState(order.customerName || 'Customer Name');
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const method = order.paymentMethod;

  const handleProceedToOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!walletNumber || walletNumber.length < 11) {
      setErrorMessage('Please enter a valid 11-digit mobile number.');
      return;
    }
    setErrorMessage(null);
    setStep('otp');
  };

  const handleProceedToPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!otp || otp.length < 4) {
      setErrorMessage('Please enter the 6-digit OTP code.');
      return;
    }
    setErrorMessage(null);
    setStep('pin');
  };

  const handleExecutePayment = async (statusOverride?: 'Cancelled' | 'Failed') => {
    setIsProcessing(true);
    setErrorMessage(null);

    try {
      const res = await api.verifyPayment({
        orderId: order.id,
        paymentMethod: method,
        transactionId: `${method.toUpperCase()}_TRX_${Date.now()}`,
        otpOrPin: pin,
        status: statusOverride,
      });

      if (res.success && res.paymentStatus === 'Paid') {
        showToast(`Payment of ${formatPrice(order.total)} confirmed!`, 'success');
        const updated = await api.getOrderById(order.id);
        onSuccess(updated.order);
      } else {
        setErrorMessage(res.message || 'Payment failed. Please try again.');
        showToast(res.message || 'Payment failed.', 'error');
        if (statusOverride === 'Cancelled') {
          onCancel();
        }
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Payment verification encountered an error.');
    } finally {
      setIsProcessing(false);
    }
  };

  const isBkash = method === 'bkash';
  const isNagad = method === 'nagad';
  const isCard = method === 'card';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden border border-neutral-200 flex flex-col">
        {/* Sandbox Notice Banner */}
        <div className="bg-amber-500 text-black px-4 py-1.5 text-center text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Bangladesh Official Payment Sandbox Mode</span>
        </div>

        {/* Brand Bar */}
        <div
          className={`p-6 text-white flex items-center justify-between ${
            isBkash
              ? 'bg-[#E2136E]'
              : isNagad
              ? 'bg-[#F26522]'
              : 'bg-neutral-900'
          }`}
        >
          <div>
            <span className="text-xs uppercase tracking-widest opacity-80">
              {isBkash ? 'bKash Payment Gateway' : isNagad ? 'Nagad Payment Gateway' : 'Secure Card Gateway'}
            </span>
            <h3 className="text-2xl font-black mt-0.5">{formatPrice(order.total)}</h3>
            <p className="text-[11px] opacity-90 mt-0.5">Invoice: {order.orderNumber}</p>
          </div>
          <button
            onClick={() => handleExecutePayment('Cancelled')}
            className="p-1.5 rounded-full hover:bg-black/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Gateway Content Body */}
        <div className="p-6">
          {errorMessage && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-rose-700 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* BKASH / NAGAD FLOW */}
          {(isBkash || isNagad) && (
            <div>
              {step === 'input' && (
                <form onSubmit={handleProceedToOtp} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 mb-1.5">
                      Your {isBkash ? 'bKash' : 'Nagad'} Account Number
                    </label>
                    <input
                      type="text"
                      value={walletNumber}
                      onChange={e => setWalletNumber(e.target.value)}
                      placeholder="e.g. 017XXXXXXXX"
                      className="w-full px-4 py-3 rounded-xl border border-neutral-300 focus:border-neutral-900 focus:outline-none text-base font-mono font-bold"
                      required
                    />
                    <p className="text-[11px] text-neutral-400 mt-1">
                      (Demo default test wallet is pre-filled)
                    </p>
                  </div>
                  <div className="pt-2 flex gap-2">
                    <button
                      type="button"
                      onClick={() => handleExecutePayment('Cancelled')}
                      className="w-1/3 py-3 border border-neutral-300 text-neutral-700 rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer hover:bg-neutral-50"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className={`w-2/3 py-3 rounded-xl text-white text-xs font-bold uppercase tracking-wider shadow-md transition-all cursor-pointer ${
                        isBkash ? 'bg-[#E2136E] hover:bg-[#c70f5f]' : 'bg-[#F26522] hover:bg-[#d85317]'
                      }`}
                    >
                      Confirm Wallet
                    </button>
                  </div>
                </form>
              )}

              {step === 'otp' && (
                <form onSubmit={handleProceedToPin} className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-1.5">
                      <label className="text-xs font-bold uppercase tracking-wider text-neutral-600">
                        Enter Verification Code (OTP)
                      </label>
                      <span className="text-[11px] font-bold text-amber-600">Default: 123456</span>
                    </div>
                    <input
                      type="text"
                      value={otp}
                      onChange={e => setOtp(e.target.value)}
                      placeholder="123456"
                      className="w-full px-4 py-3 rounded-xl border border-neutral-300 focus:border-neutral-900 focus:outline-none text-center text-xl font-mono font-bold tracking-widest"
                      required
                    />
                    <p className="text-[11px] text-neutral-500 mt-1 text-center">
                      Sent to: {walletNumber}
                    </p>
                  </div>
                  <div className="pt-2 flex gap-2">
                    <button
                      type="button"
                      onClick={() => setStep('input')}
                      className="w-1/3 py-3 border border-neutral-300 text-neutral-700 rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer hover:bg-neutral-50"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      className={`w-2/3 py-3 rounded-xl text-white text-xs font-bold uppercase tracking-wider shadow-md transition-all cursor-pointer ${
                        isBkash ? 'bg-[#E2136E] hover:bg-[#c70f5f]' : 'bg-[#F26522] hover:bg-[#d85317]'
                      }`}
                    >
                      Verify OTP
                    </button>
                  </div>
                </form>
              )}

              {step === 'pin' && (
                <form onSubmit={e => { e.preventDefault(); handleExecutePayment(); }} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-neutral-600 mb-1.5">
                      Enter 5-Digit PIN (Sandbox)
                    </label>
                    <input
                      type="password"
                      maxLength={5}
                      value={pin}
                      onChange={e => setPin(e.target.value)}
                      placeholder="•••••"
                      className="w-full px-4 py-3 rounded-xl border border-neutral-300 focus:border-neutral-900 focus:outline-none text-center text-2xl font-mono tracking-widest"
                      required
                      autoFocus
                    />
                    <p className="text-[11px] text-neutral-400 mt-1 text-center">
                      (Enter any 5-digit PIN to simulate sandbox approval)
                    </p>
                  </div>
                  <div className="pt-2 flex gap-2">
                    <button
                      type="button"
                      onClick={() => handleExecutePayment('Failed')}
                      disabled={isProcessing}
                      className="w-1/3 py-3 border border-rose-200 text-rose-600 rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer hover:bg-rose-50"
                    >
                      Simulate Fail
                    </button>
                    <button
                      type="submit"
                      disabled={isProcessing}
                      className={`w-2/3 py-3 rounded-xl text-white text-xs font-bold uppercase tracking-wider shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer ${
                        isBkash ? 'bg-[#E2136E] hover:bg-[#c70f5f]' : 'bg-[#F26522] hover:bg-[#d85317]'
                      }`}
                    >
                      {isProcessing ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Verifying...</span>
                        </>
                      ) : (
                        <span>Pay {formatPrice(order.total)}</span>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* CARD PAYMENT FLOW */}
          {isCard && (
            <form onSubmit={e => { e.preventDefault(); handleExecutePayment(); }} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-neutral-600 mb-1">Cardholder Name</label>
                <input
                  type="text"
                  value={cardName}
                  onChange={e => setCardName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-sm font-medium focus:outline-none focus:border-neutral-900"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-neutral-600 mb-1">Card Number</label>
                <input
                  type="text"
                  value={cardNumber}
                  onChange={e => setCardNumber(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 font-mono text-sm focus:outline-none focus:border-neutral-900"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-neutral-600 mb-1">Expiry Date</label>
                  <input
                    type="text"
                    value={cardExpiry}
                    onChange={e => setCardExpiry(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-sm font-mono focus:outline-none focus:border-neutral-900"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-neutral-600 mb-1">CVC / CVV</label>
                  <input
                    type="password"
                    maxLength={4}
                    value={cardCvc}
                    onChange={e => setCardCvc(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-sm font-mono focus:outline-none focus:border-neutral-900"
                    required
                  />
                </div>
              </div>

              <div className="pt-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => handleExecutePayment('Failed')}
                  disabled={isProcessing}
                  className="w-1/3 py-3 border border-rose-200 text-rose-600 rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer hover:bg-rose-50"
                >
                  Decline
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="w-2/3 py-3 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Charging Card...</span>
                    </>
                  ) : (
                    <span>Authorize {formatPrice(order.total)}</span>
                  )}
                </button>
              </div>
            </form>
          )}

          <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center justify-center gap-2 text-[11px] text-neutral-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>256-Bit SSL Encrypted Sandbox Gateway</span>
          </div>
        </div>
      </div>
    </div>
  );
};
