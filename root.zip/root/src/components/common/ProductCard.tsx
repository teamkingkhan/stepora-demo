import React, { useState } from 'react';
import { Heart, Star, ShoppingBag, Eye, Check } from 'lucide-react';
import { Product, ShoeSize } from '../../types';
import { useSettings } from '../../context/SettingsContext';
import { useWishlist } from '../../context/WishlistContext';
import { useCart } from '../../context/CartContext';

interface ProductCardProps {
  product: Product;
  onNavigate: (page: string, params?: any) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onNavigate }) => {
  const { formatPrice } = useSettings();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { addToCart } = useCart();

  const [isHovered, setIsHovered] = useState(false);
  const [selectedQuickSize, setSelectedQuickSize] = useState<ShoeSize | null>(null);
  const [showQuickSizePicker, setShowQuickSizePicker] = useState(false);

  const inWishlist = isInWishlist(product.id);
  const hasDiscount = product.salePrice && product.salePrice < product.price;
  const isOutOfStock = product.stockQuantity === 0;

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isOutOfStock) return;
    if (product.availableSizes.length === 1) {
      addToCart(product, product.availableSizes[0]);
    } else {
      setShowQuickSizePicker(true);
    }
  };

  const handleSelectSizeAndAdd = (e: React.MouseEvent, size: ShoeSize) => {
    e.stopPropagation();
    addToCart(product, size);
    setShowQuickSizePicker(false);
  };

  return (
    <div
      onClick={() => onNavigate('product-details', { id: product.slug || product.id })}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        setShowQuickSizePicker(false);
      }}
      className="group relative bg-white rounded-2xl border border-neutral-200/80 hover:border-neutral-300 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden cursor-pointer"
    >
      {/* Product Image Area */}
      <div className="relative aspect-square w-full bg-neutral-100 overflow-hidden">
        <img
          src={isHovered && product.images[1] ? product.images[1] : product.mainImage}
          alt={product.name}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
          loading="lazy"
        />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
          {hasDiscount && (
            <span className="px-2.5 py-1 bg-rose-600 text-white text-[11px] font-extrabold uppercase rounded-lg shadow-sm tracking-wider">
              -{product.discountPercentage}% OFF
            </span>
          )}
          {product.newArrival && (
            <span className="px-2.5 py-0.5 bg-neutral-900 text-white text-[10px] font-bold uppercase rounded-lg shadow-sm">
              New
            </span>
          )}
          {product.bestSeller && (
            <span className="px-2.5 py-0.5 bg-amber-500 text-black text-[10px] font-bold uppercase rounded-lg shadow-sm">
              Hot
            </span>
          )}
          {isOutOfStock && (
            <span className="px-2.5 py-0.5 bg-neutral-600 text-white text-[10px] font-bold uppercase rounded-lg">
              Out of Stock
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={e => {
            e.stopPropagation();
            toggleWishlist(product);
          }}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition-all duration-200 z-10 cursor-pointer shadow-md ${
            inWishlist
              ? 'bg-rose-50 text-rose-600'
              : 'bg-white/80 text-neutral-600 hover:text-black hover:bg-white'
          }`}
          aria-label="Wishlist"
        >
          <Heart className={`w-4 h-4 ${inWishlist ? 'fill-rose-600' : ''}`} />
        </button>

        {/* Quick Add Overlay on Hover */}
        <div className="absolute inset-x-3 bottom-3 z-10 transition-all duration-300 opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0">
          {showQuickSizePicker ? (
            <div
              onClick={e => e.stopPropagation()}
              className="bg-white/95 backdrop-blur-md p-3 rounded-xl shadow-xl border border-neutral-200 animate-in fade-in zoom-in-95"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold uppercase text-neutral-600">Select EU Size:</span>
                <span className="text-[10px] text-amber-600 font-semibold cursor-pointer" onClick={() => setShowQuickSizePicker(false)}>Close</span>
              </div>
              <div className="flex flex-wrap gap-1.5 justify-center">
                {product.availableSizes.map(size => {
                  const sStock = product.sizeStock?.find(s => s.size === size);
                  const isAvailable = sStock ? sStock.stock > 0 : true;
                  return (
                    <button
                      key={size}
                      disabled={!isAvailable}
                      onClick={e => handleSelectSizeAndAdd(e, size)}
                      className={`w-8 h-8 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        !isAvailable
                          ? 'bg-neutral-100 text-neutral-400 line-through cursor-not-allowed'
                          : 'bg-neutral-900 text-white hover:bg-amber-500 hover:text-black shadow-sm'
                      }`}
                    >
                      {size}
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            <button
              onClick={handleQuickAdd}
              disabled={isOutOfStock}
              className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all duration-200 cursor-pointer ${
                isOutOfStock
                  ? 'bg-neutral-300 text-neutral-500 cursor-not-allowed'
                  : 'bg-neutral-900 hover:bg-black text-white hover:shadow-neutral-900/30'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>{isOutOfStock ? 'Sold Out' : 'Quick Add'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Product Content Details */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between text-xs text-neutral-500 mb-1">
            <span className="font-semibold uppercase tracking-wider text-[10px] text-amber-700">
              {product.brand}
            </span>
            <div className="flex items-center gap-1">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span className="font-bold text-neutral-800 text-[11px]">{product.rating}</span>
              <span className="text-[10px] text-neutral-400">({product.reviewCount})</span>
            </div>
          </div>

          <h3 className="font-bold text-neutral-900 text-sm leading-snug line-clamp-2 group-hover:text-amber-600 transition-colors">
            {product.name}
          </h3>

          {/* Color preview dots */}
          {product.availableColors && product.availableColors.length > 0 && (
            <div className="flex items-center gap-1.5 mt-2">
              {product.availableColors.slice(0, 4).map((c, idx) => (
                <span
                  key={idx}
                  title={c.name}
                  className="w-3 h-3 rounded-full border border-neutral-300 shadow-2xs"
                  style={{ backgroundColor: c.hex }}
                />
              ))}
              {product.availableColors.length > 4 && (
                <span className="text-[10px] text-neutral-400 font-semibold">
                  +{product.availableColors.length - 4}
                </span>
              )}
            </div>
          )}
        </div>

        {/* Pricing */}
        <div className="mt-3 pt-2.5 border-t border-neutral-100 flex items-baseline justify-between">
          <div className="flex items-baseline gap-2">
            <span className="text-base font-extrabold text-neutral-900">
              {formatPrice(product.salePrice || product.price)}
            </span>
            {hasDiscount && (
              <span className="text-xs text-neutral-400 line-through">
                {formatPrice(product.price)}
              </span>
            )}
          </div>

          <span className="text-[11px] font-semibold text-neutral-500 uppercase">
            {product.gender}
          </span>
        </div>
      </div>
    </div>
  );
};
