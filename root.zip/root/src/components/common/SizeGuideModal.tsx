import React from 'react';
import { X, Ruler, CheckCircle2 } from 'lucide-react';

interface SizeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const SIZE_CHART = [
  { eu: '36', usMen: '4.5', usWomen: '6.0', uk: '3.5', cm: '22.5', inches: '8.8"' },
  { eu: '37', usMen: '5.0', usWomen: '6.5', uk: '4.0', cm: '23.0', inches: '9.0"' },
  { eu: '38', usMen: '6.0', usWomen: '7.5', uk: '5.0', cm: '24.0', inches: '9.4"' },
  { eu: '39', usMen: '6.5', usWomen: '8.0', uk: '5.5', cm: '24.5', inches: '9.6"' },
  { eu: '40', usMen: '7.5', usWomen: '9.0', uk: '6.5', cm: '25.5', inches: '10.0"' },
  { eu: '41', usMen: '8.0', usWomen: '9.5', uk: '7.0', cm: '26.0', inches: '10.2"' },
  { eu: '42', usMen: '8.5', usWomen: '10.0', uk: '7.5', cm: '26.5', inches: '10.4"' },
  { eu: '43', usMen: '9.5', usWomen: '11.0', uk: '8.5', cm: '27.5', inches: '10.8"' },
  { eu: '44', usMen: '10.0', usWomen: '11.5', uk: '9.0', cm: '28.0', inches: '11.0"' },
  { eu: '45', usMen: '11.0', usWomen: '12.5', uk: '10.0', cm: '29.0', inches: '11.4"' },
  { eu: '46', usMen: '12.0', usWomen: '13.5', uk: '11.0', cm: '30.0', inches: '11.8"' },
];

export const SizeGuideModal: React.FC<SizeGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-neutral-200 bg-neutral-50/50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-neutral-900 text-white rounded-xl">
              <Ruler className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-neutral-900 text-lg">Footwear Sizing Chart</h3>
              <p className="text-xs text-neutral-500">Standard EU/Bangladesh size conversion</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-neutral-900 rounded-full hover:bg-neutral-200/50 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Size Chart Table */}
          <div className="overflow-x-auto border border-neutral-200 rounded-2xl">
            <table className="w-full text-left border-collapse text-xs sm:text-sm">
              <thead>
                <tr className="bg-neutral-900 text-white font-bold">
                  <th className="py-3 px-4">EU / BD</th>
                  <th className="py-3 px-3">US Men</th>
                  <th className="py-3 px-3">US Women</th>
                  <th className="py-3 px-3">UK</th>
                  <th className="py-3 px-3">Foot (CM)</th>
                  <th className="py-3 px-3">Inches</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100 font-medium">
                {SIZE_CHART.map((row, idx) => (
                  <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-neutral-50/70'}>
                    <td className="py-2.5 px-4 font-bold text-neutral-900 bg-amber-50/50">{row.eu}</td>
                    <td className="py-2.5 px-3 text-neutral-700">{row.usMen}</td>
                    <td className="py-2.5 px-3 text-neutral-700">{row.usWomen}</td>
                    <td className="py-2.5 px-3 text-neutral-700">{row.uk}</td>
                    <td className="py-2.5 px-3 font-semibold text-neutral-900">{row.cm} cm</td>
                    <td className="py-2.5 px-3 text-neutral-500">{row.inches}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* How to Measure Guide */}
          <div className="bg-neutral-50 p-5 rounded-2xl border border-neutral-200/80">
            <h4 className="font-bold text-neutral-900 text-sm mb-3">How to Measure Your Feet Accurately</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-neutral-600">
              <div className="flex gap-2.5 items-start">
                <span className="w-5 h-5 rounded-full bg-neutral-900 text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">1</span>
                <p>Tape a sheet of paper to a hard floor and stand flat against a straight wall.</p>
              </div>
              <div className="flex gap-2.5 items-start">
                <span className="w-5 h-5 rounded-full bg-neutral-900 text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">2</span>
                <p>Mark the tip of your longest toe and back of your heel with a pencil.</p>
              </div>
              <div className="flex gap-2.5 items-start">
                <span className="w-5 h-5 rounded-full bg-neutral-900 text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">3</span>
                <p>Measure the distance in CM. If between sizes, we recommend sizing up by +1.</p>
              </div>
            </div>
          </div>

          {/* Doorstep Exchange guarantee */}
          <div className="flex items-center gap-3 p-4 bg-emerald-50 rounded-2xl border border-emerald-200/60 text-emerald-900 text-xs">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <p>
              <strong className="font-bold">Hassle-Free Size Exchange:</strong> If your shoes don't fit perfectly upon delivery, we provide doorstep size replacement within 7 days anywhere in Bangladesh!
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-200 bg-neutral-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
