import React, { useRef } from 'react';
import { X, Printer, Download, CheckCircle, Package } from 'lucide-react';
import { Order } from '../../types';
import { useSettings } from '../../context/SettingsContext';

interface InvoiceModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({ order, isOpen, onClose }) => {
  const { settings, formatPrice } = useSettings();
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !order) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    // Generate clean HTML printable document for download
    const invoiceHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Invoice - ${order.orderNumber}</title>
        <style>
          body { font-family: 'Helvetica Neue', Arial, sans-serif; color: #111; padding: 40px; margin: 0; line-height: 1.5; }
          .header { display: flex; justify-content: space-between; border-bottom: 2px solid #000; padding-bottom: 20px; }
          .logo { font-size: 26px; font-weight: 800; letter-spacing: -1px; text-transform: uppercase; }
          .invoice-tag { font-size: 28px; font-weight: 900; color: #d97706; }
          .info-grid { display: flex; justify-content: space-between; margin-top: 30px; font-size: 14px; }
          table { width: 100%; border-collapse: collapse; margin-top: 30px; }
          th { background: #111; color: #fff; padding: 12px; text-align: left; font-size: 12px; text-transform: uppercase; }
          td { padding: 12px; border-bottom: 1px solid #ddd; font-size: 14px; }
          .total-box { margin-top: 30px; margin-left: auto; width: 300px; font-size: 14px; }
          .total-row { display: flex; justify-content: space-between; padding: 6px 0; }
          .grand-total { font-size: 18px; font-weight: 800; border-top: 2px solid #111; padding-top: 10px; margin-top: 10px; }
          .footer { margin-top: 60px; text-align: center; font-size: 12px; color: #666; border-top: 1px solid #eee; padding-top: 20px; }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <div class="logo">${settings.storeName}</div>
            <div style="font-size: 12px; color: #666; margin-top: 5px;">${settings.storeAddress}</div>
            <div style="font-size: 12px; color: #666;">Phone: ${settings.storePhone} | Email: ${settings.storeEmail}</div>
          </div>
          <div style="text-align: right;">
            <div class="invoice-tag">INVOICE</div>
            <div style="font-size: 14px; font-weight: bold; margin-top: 5px;">#${order.orderNumber}</div>
            <div style="font-size: 12px; color: #666;">Date: ${new Date(order.createdAt).toLocaleDateString()}</div>
          </div>
        </div>
        <div class="info-grid">
          <div>
            <strong>BILLED TO:</strong><br>
            ${order.shippingAddress.fullName}<br>
            Phone: ${order.shippingAddress.phoneNumber}<br>
            Email: ${order.shippingAddress.email || order.customerEmail}<br>
            ${order.shippingAddress.fullAddress}<br>
            ${order.shippingAddress.area}, ${order.shippingAddress.district}, ${order.shippingAddress.division}
          </div>
          <div style="text-align: right;">
            <strong>ORDER SUMMARY:</strong><br>
            Status: <strong>${order.orderStatus.toUpperCase()}</strong><br>
            Payment: <strong>${order.paymentMethod.toUpperCase()} (${order.paymentStatus})</strong><br>
            ${order.transactionId ? `TrxID: ${order.transactionId}<br>` : ''}
          </div>
        </div>
        <table>
          <thead>
            <tr>
              <th>Item Description</th>
              <th>SKU</th>
              <th>Size</th>
              <th>Color</th>
              <th>Qty</th>
              <th style="text-align: right;">Price</th>
              <th style="text-align: right;">Total</th>
            </tr>
          </thead>
          <tbody>
            ${order.items
              .map(
                it => `
              <tr>
                <td><strong>${it.productName}</strong></td>
                <td>${it.sku}</td>
                <td>EU ${it.selectedSize}</td>
                <td>${it.selectedColor?.name || 'Standard'}</td>
                <td>${it.quantity}</td>
                <td style="text-align: right;">${formatPrice(it.price)}</td>
                <td style="text-align: right;">${formatPrice(it.itemTotal)}</td>
              </tr>
            `
              )
              .join('')}
          </tbody>
        </table>
        <div class="total-box">
          <div class="total-row"><span>Subtotal:</span><span>${formatPrice(order.subtotal)}</span></div>
          ${order.discount > 0 ? `<div class="total-row"><span>Discount ${order.couponCode ? `(${order.couponCode})` : ''}:</span><span>-${formatPrice(order.discount)}</span></div>` : ''}
          <div class="total-row"><span>Shipping (${order.shippingRegion === 'inside_dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'}):</span><span>${order.shippingFee === 0 ? 'FREE' : formatPrice(order.shippingFee)}</span></div>
          <div class="total-row grand-total"><span>Grand Total:</span><span>${formatPrice(order.total)}</span></div>
        </div>
        <div class="footer">
          Thank you for choosing ${settings.storeName}! For queries, please contact ${settings.storeEmail}.
        </div>
      </body>
      </html>
    `;

    const blob = new Blob([invoiceHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Invoice_${order.orderNumber}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
        {/* Modal Controls */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 bg-neutral-900 text-white print:hidden">
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5 text-amber-400" />
            <span className="font-extrabold text-sm sm:text-base tracking-wide">
              Official Tax Invoice • {order.orderNumber}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>
            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-black rounded-lg text-xs font-bold transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Invoice Printable View */}
        <div ref={printRef} className="p-8 sm:p-12 overflow-y-auto space-y-8 bg-white text-neutral-900">
          {/* Top Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 border-b-2 border-neutral-900 pb-6">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-neutral-900 flex items-center justify-center text-white font-extrabold text-base">
                  S
                </div>
                <h1 className="text-2xl font-extrabold tracking-tight text-neutral-950 uppercase font-sans">
                  {settings.storeName}
                </h1>
              </div>
              <p className="text-xs text-neutral-500 mt-1 max-w-xs">{settings.storeAddress}</p>
              <p className="text-xs text-neutral-500">Phone: {settings.storePhone} | {settings.storeEmail}</p>
            </div>

            <div className="text-left sm:text-right">
              <span className="text-amber-600 font-extrabold text-2xl uppercase tracking-wider block">
                INVOICE
              </span>
              <p className="text-sm font-bold text-neutral-900 mt-1">#{order.orderNumber}</p>
              <p className="text-xs text-neutral-500">
                Date: {new Date(order.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
              </p>
            </div>
          </div>

          {/* Billing & Order info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 text-xs sm:text-sm">
            <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-200">
              <h4 className="font-extrabold text-neutral-900 uppercase tracking-wider text-xs mb-2">
                Customer Shipping Address
              </h4>
              <p className="font-bold text-neutral-950 text-base">{order.shippingAddress.fullName}</p>
              <p className="text-neutral-600 mt-0.5">{order.shippingAddress.phoneNumber}</p>
              <p className="text-neutral-600">{order.shippingAddress.email || order.customerEmail}</p>
              <p className="text-neutral-700 mt-2 font-medium">
                {order.shippingAddress.fullAddress}, {order.shippingAddress.area}, {order.shippingAddress.district}, {order.shippingAddress.division}
              </p>
            </div>

            <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-200 flex flex-col justify-between">
              <div>
                <h4 className="font-extrabold text-neutral-900 uppercase tracking-wider text-xs mb-2">
                  Order Details
                </h4>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between">
                    <span className="text-neutral-500">Order Status:</span>
                    <span className="font-bold text-neutral-900">{order.orderStatus}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-500">Payment Method:</span>
                    <span className="font-bold uppercase text-neutral-900">{order.paymentMethod}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-500">Payment Status:</span>
                    <span className={`font-bold ${order.paymentStatus === 'Paid' ? 'text-emerald-600' : 'text-amber-600'}`}>
                      {order.paymentStatus}
                    </span>
                  </div>
                  {order.transactionId && (
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Transaction ID:</span>
                      <span className="font-mono text-neutral-700">{order.transactionId}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Items Table */}
          <div className="overflow-x-auto border border-neutral-200 rounded-2xl">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-neutral-900 text-white font-bold">
                <tr>
                  <th className="py-3 px-4">Item Details</th>
                  <th className="py-3 px-3">Size</th>
                  <th className="py-3 px-3">Color</th>
                  <th className="py-3 px-3 text-center">Qty</th>
                  <th className="py-3 px-3 text-right">Price</th>
                  <th className="py-3 px-4 text-right">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100 font-medium">
                {order.items.map((item, idx) => (
                  <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-neutral-50/50'}>
                    <td className="py-3 px-4">
                      <p className="font-bold text-neutral-900">{item.productName}</p>
                      <p className="text-[11px] text-neutral-500 font-mono">SKU: {item.sku}</p>
                    </td>
                    <td className="py-3 px-3 font-semibold text-neutral-800">EU {item.selectedSize}</td>
                    <td className="py-3 px-3 text-neutral-600">{item.selectedColor?.name || 'Standard'}</td>
                    <td className="py-3 px-3 text-center font-bold text-neutral-900">{item.quantity}</td>
                    <td className="py-3 px-3 text-right text-neutral-700">{formatPrice(item.price)}</td>
                    <td className="py-3 px-4 text-right font-extrabold text-neutral-950">{formatPrice(item.itemTotal)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pricing Totals */}
          <div className="flex justify-end">
            <div className="w-full max-w-xs space-y-2 text-xs sm:text-sm">
              <div className="flex justify-between text-neutral-600">
                <span>Subtotal:</span>
                <span className="font-semibold text-neutral-900">{formatPrice(order.subtotal)}</span>
              </div>
              {order.discount > 0 && (
                <div className="flex justify-between text-rose-600">
                  <span>Coupon Discount {order.couponCode ? `(${order.couponCode})` : ''}:</span>
                  <span className="font-semibold">-{formatPrice(order.discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-neutral-600">
                <span>Shipping ({order.shippingRegion === 'inside_dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'}):</span>
                <span className="font-semibold text-neutral-900">
                  {order.shippingFee === 0 ? 'FREE' : formatPrice(order.shippingFee)}
                </span>
              </div>
              <div className="pt-2 border-t-2 border-neutral-900 flex justify-between text-base font-extrabold text-neutral-950">
                <span>Grand Total:</span>
                <span className="text-amber-600">{formatPrice(order.total)}</span>
              </div>
            </div>
          </div>

          {/* Footer Notice */}
          <div className="pt-6 border-t border-neutral-200 text-center text-xs text-neutral-500">
            <p className="font-medium">Thank you for your order with {settings.storeName}!</p>
            <p className="text-[11px] text-neutral-400 mt-1">
              For return requests or customer support, please call {settings.storePhone} within 7 days of delivery.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
