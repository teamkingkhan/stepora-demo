import React, { useState, useEffect, useRef } from 'react';
import {
  ShoppingBag,
  Heart,
  User as UserIcon,
  Search,
  Menu,
  X,
  ChevronDown,
  ShieldCheck,
  Truck,
  PhoneCall,
  SlidersHorizontal,
  LogOut,
  Package,
} from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { useAuth } from '../../context/AuthContext';
import { useSettings } from '../../context/SettingsContext';
import { api } from '../../services/api';
import { Product } from '../../types';

interface HeaderProps {
  onNavigate: (page: string, params?: any) => void;
  currentPage: string;
}

export const Header: React.FC<HeaderProps> = ({ onNavigate, currentPage }) => {
  const { totalItemCount, subtotal } = useCart();
  const { totalWishlistCount } = useWishlist();
  const { user, isCustomerAuthenticated, customerLogout, isAdminAuthenticated } = useAuth();
  const { settings, formatPrice } = useSettings();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isAccountDropdownOpen, setIsAccountDropdownOpen] = useState(false);

  const searchRef = useRef<HTMLDivElement>(null);
  const accountRef = useRef<HTMLDivElement>(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setSearchResults([]);
      }
      if (accountRef.current && !accountRef.current.contains(e.target as Node)) {
        setIsAccountDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Live search debouncing
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }
    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const res = await api.getProducts({ q: searchQuery.trim(), limit: '5' });
        setSearchResults(res.products || []);
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setIsSearching(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onNavigate('shop', { q: searchQuery.trim() });
      setSearchResults([]);
      setIsSearchOpen(false);
    }
  };

  const navLinks = [
    { label: 'Home', page: 'home' },
    { label: 'Shop All', page: 'shop' },
    { label: "Men's", page: 'shop', params: { category: 'men' } },
    { label: "Women's", page: 'shop', params: { category: 'women' } },
    { label: 'Sneakers', page: 'shop', params: { category: 'sneakers' } },
    { label: 'Sports', page: 'shop', params: { category: 'sports' } },
    { label: 'Formal', page: 'shop', params: { category: 'formal' } },
    { label: 'Kids', page: 'shop', params: { category: 'kids' } },
    { label: 'Sale %', page: 'shop', params: { discountOnly: 'true' }, isSale: true },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-neutral-200 transition-all">
      {/* Top Announcement Bar */}
      <div className="bg-neutral-900 text-white text-xs py-2 px-4 transition-colors">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2">
          <div className="flex items-center gap-4 text-neutral-300">
            <span className="flex items-center gap-1.5 font-medium">
              <Truck className="w-3.5 h-3.5 text-amber-400" />
              Free shipping over {formatPrice(settings.freeShippingThreshold)}
            </span>
            <span className="hidden md:inline-block text-neutral-600">•</span>
            <span className="hidden md:flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              100% Authentic Footwear Guarantee
            </span>
          </div>

          <div className="flex items-center gap-4 text-neutral-300">
            <button
              onClick={() => onNavigate('track-order')}
              className="hover:text-amber-400 transition-colors font-medium cursor-pointer"
            >
              Track Order
            </button>
            <span className="text-neutral-600">•</span>
            <a
              href={`tel:${settings.storePhone.replace(/\s+/g, '')}`}
              className="flex items-center gap-1 hover:text-white transition-colors"
            >
              <PhoneCall className="w-3 h-3 text-amber-400" />
              {settings.storePhone}
            </a>
            {isAdminAuthenticated && (
              <>
                <span className="text-neutral-600">•</span>
                <button
                  onClick={() => onNavigate('admin-dashboard')}
                  className="bg-amber-500 hover:bg-amber-400 text-black px-2 py-0.5 rounded text-[11px] font-bold transition-colors cursor-pointer"
                >
                  Admin Panel
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-4">
          {/* Mobile Menu Button */}
          <div className="flex items-center lg:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 -ml-2 text-neutral-700 hover:text-black focus:outline-none cursor-pointer"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Brand Logo */}
          <div className="flex items-center cursor-pointer select-none" onClick={() => onNavigate('home')}>
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-neutral-900 flex items-center justify-center text-white font-extrabold text-xl shadow-md tracking-tighter">
                S
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-extrabold tracking-tight text-neutral-900 font-sans uppercase">
                  {settings.storeName.split(' ')[0] || 'STEPORA'}
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest text-amber-600 -mt-1">
                  Footwear Atelier
                </span>
              </div>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navLinks.map((link, idx) => (
              <button
                key={idx}
                onClick={() => onNavigate(link.page, link.params)}
                className={`px-3 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                  link.isSale
                    ? 'text-rose-600 hover:text-rose-700 hover:bg-rose-50'
                    : currentPage === link.page && (!link.params || link.params.category === undefined)
                    ? 'text-neutral-950 bg-neutral-100'
                    : 'text-neutral-600 hover:text-neutral-950 hover:bg-neutral-50'
                }`}
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Actions: Search, Wishlist, Account, Cart */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Desktop Search Bar */}
            <div className="relative hidden md:block w-52 xl:w-72" ref={searchRef}>
              <form onSubmit={handleSearchSubmit}>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search shoes, sneakers, boots..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 text-xs lg:text-sm bg-neutral-100 hover:bg-neutral-50 focus:bg-white rounded-full border border-neutral-200 focus:border-neutral-900 focus:outline-none transition-all"
                  />
                  <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </form>

              {/* Live Search Results Popup */}
              {searchResults.length > 0 && (
                <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl shadow-2xl border border-neutral-200 overflow-hidden z-50">
                  <div className="p-2 border-b border-neutral-100 text-xs font-semibold text-neutral-500 uppercase tracking-wider flex justify-between items-center">
                    <span>Products Found</span>
                    <button
                      onClick={handleSearchSubmit}
                      className="text-amber-600 hover:underline cursor-pointer"
                    >
                      View All
                    </button>
                  </div>
                  <div className="divide-y divide-neutral-100 max-h-80 overflow-y-auto">
                    {searchResults.map(prod => (
                      <div
                        key={prod.id}
                        onClick={() => {
                          onNavigate('product-details', { id: prod.slug || prod.id });
                          setSearchResults([]);
                        }}
                        className="flex items-center gap-3 p-3 hover:bg-neutral-50 cursor-pointer transition-colors"
                      >
                        <img
                          src={prod.mainImage}
                          alt={prod.name}
                          className="w-12 h-12 rounded-lg object-cover bg-neutral-100 shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-neutral-900 truncate">{prod.name}</p>
                          <p className="text-[11px] text-neutral-500">{prod.brand} • {prod.category}</p>
                          <p className="text-xs font-bold text-neutral-900 mt-0.5">
                            {formatPrice(prod.salePrice || prod.price)}
                            {prod.salePrice < prod.price && (
                              <span className="line-through text-neutral-400 text-[10px] ml-1.5">
                                {formatPrice(prod.price)}
                              </span>
                            )}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Mobile Search Icon Toggle */}
            <button
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="md:hidden p-2 text-neutral-700 hover:text-black rounded-full hover:bg-neutral-100 cursor-pointer"
              aria-label="Search"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Wishlist Button */}
            <button
              onClick={() => onNavigate('wishlist')}
              className="relative p-2 text-neutral-700 hover:text-black rounded-full hover:bg-neutral-100 transition-colors cursor-pointer"
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {totalWishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center shadow-sm">
                  {totalWishlistCount}
                </span>
              )}
            </button>

            {/* Cart Button */}
            <button
              onClick={() => onNavigate('cart')}
              className="relative p-2 text-neutral-700 hover:text-black rounded-full hover:bg-neutral-100 transition-colors cursor-pointer flex items-center gap-1.5"
              aria-label="Shopping Cart"
            >
              <div className="relative">
                <ShoppingBag className="w-5 h-5" />
                {totalItemCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-neutral-900 text-white text-[10px] font-bold flex items-center justify-center shadow-sm animate-pulse">
                    {totalItemCount}
                  </span>
                )}
              </div>
              <span className="hidden sm:inline-block text-xs font-bold text-neutral-900">
                {formatPrice(subtotal)}
              </span>
            </button>

            {/* Account Dropdown */}
            <div className="relative" ref={accountRef}>
              <button
                onClick={() => setIsAccountDropdownOpen(!isAccountDropdownOpen)}
                className="flex items-center gap-1.5 p-2 text-neutral-700 hover:text-black rounded-full hover:bg-neutral-100 transition-colors cursor-pointer"
                aria-label="Account"
              >
                <UserIcon className="w-5 h-5" />
                <ChevronDown className="w-3.5 h-3.5 hidden sm:block text-neutral-500" />
              </button>

              {isAccountDropdownOpen && (
                <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-2xl shadow-2xl border border-neutral-200 py-2 z-50 animate-in fade-in zoom-in-95">
                  {isCustomerAuthenticated ? (
                    <>
                      <div className="px-4 py-2 border-b border-neutral-100">
                        <p className="text-xs text-neutral-500">Signed in as</p>
                        <p className="text-sm font-bold text-neutral-900 truncate">{user?.fullName}</p>
                        <p className="text-xs text-neutral-500 truncate">{user?.email}</p>
                      </div>
                      <button
                        onClick={() => {
                          onNavigate('my-account');
                          setIsAccountDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-sm text-neutral-700 hover:bg-neutral-50 font-medium flex items-center gap-2.5 cursor-pointer"
                      >
                        <UserIcon className="w-4 h-4 text-neutral-400" />
                        My Profile
                      </button>
                      <button
                        onClick={() => {
                          onNavigate('my-orders');
                          setIsAccountDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-sm text-neutral-700 hover:bg-neutral-50 font-medium flex items-center gap-2.5 cursor-pointer"
                      >
                        <Package className="w-4 h-4 text-neutral-400" />
                        My Orders
                      </button>
                      <button
                        onClick={() => {
                          onNavigate('track-order');
                          setIsAccountDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-sm text-neutral-700 hover:bg-neutral-50 font-medium flex items-center gap-2.5 cursor-pointer"
                      >
                        <Truck className="w-4 h-4 text-neutral-400" />
                        Track Order
                      </button>
                      <div className="border-t border-neutral-100 my-1"></div>
                      <button
                        onClick={() => {
                          customerLogout();
                          setIsAccountDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-sm text-rose-600 hover:bg-rose-50 font-medium flex items-center gap-2.5 cursor-pointer"
                      >
                        <LogOut className="w-4 h-4 text-rose-500" />
                        Sign Out
                      </button>
                    </>
                  ) : (
                    <>
                      <div className="px-4 py-2 border-b border-neutral-100">
                        <p className="text-xs font-semibold text-neutral-900">Welcome to STEPORA</p>
                        <p className="text-[11px] text-neutral-500">Access orders & fast checkout</p>
                      </div>
                      <button
                        onClick={() => {
                          onNavigate('login');
                          setIsAccountDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-sm text-neutral-900 font-semibold hover:bg-neutral-50 flex items-center gap-2.5 cursor-pointer"
                      >
                        <UserIcon className="w-4 h-4 text-amber-500" />
                        Customer Login
                      </button>
                      <button
                        onClick={() => {
                          onNavigate('register');
                          setIsAccountDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-sm text-neutral-700 hover:bg-neutral-50 font-medium flex items-center gap-2.5 cursor-pointer"
                      >
                        Create an Account
                      </button>
                      <div className="border-t border-neutral-100 my-1"></div>
                      <button
                        onClick={() => {
                          onNavigate('track-order');
                          setIsAccountDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-sm text-neutral-700 hover:bg-neutral-50 font-medium flex items-center gap-2.5 cursor-pointer"
                      >
                        <Truck className="w-4 h-4 text-neutral-400" />
                        Track Order
                      </button>
                    </>
                  )}

                  {/* Admin Gateway link */}
                  <div className="border-t border-neutral-100 my-1"></div>
                  <button
                    onClick={() => {
                      onNavigate('admin-login');
                      setIsAccountDropdownOpen(false);
                    }}
                    className="w-full text-left px-4 py-2 text-xs text-amber-700 bg-amber-50/60 hover:bg-amber-100/70 font-semibold flex items-center gap-2 cursor-pointer transition-colors"
                  >
                    <SlidersHorizontal className="w-3.5 h-3.5 text-amber-600" />
                    Admin Portal (Staff Only)
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Search Expandable Bar */}
        {isSearchOpen && (
          <div className="md:hidden pb-4 pt-1">
            <form onSubmit={handleSearchSubmit}>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search shoes, sneakers, boots..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 text-sm bg-neutral-100 rounded-xl border border-neutral-200 focus:outline-none focus:border-neutral-900"
                  autoFocus
                />
                <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              </div>
            </form>
          </div>
        )}
      </div>

      {/* Mobile Drawer Navigation */}
      {isMobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex">
          <div className="w-4/5 max-w-sm bg-white h-full shadow-2xl flex flex-col p-6 overflow-y-auto animate-in slide-in-from-left duration-200">
            <div className="flex items-center justify-between pb-6 border-b border-neutral-200">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-neutral-900 flex items-center justify-center text-white font-extrabold text-base">
                  S
                </div>
                <span className="font-extrabold text-lg tracking-tight uppercase">
                  {settings.storeName.split(' ')[0] || 'STEPORA'}
                </span>
              </div>
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-1.5 text-neutral-500 hover:text-black rounded-lg hover:bg-neutral-100 cursor-pointer"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="py-4 space-y-1">
              {navLinks.map((link, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    onNavigate(link.page, link.params);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full text-left px-4 py-3 rounded-xl text-base font-semibold transition-colors cursor-pointer ${
                    link.isSale ? 'text-rose-600 font-bold bg-rose-50' : 'text-neutral-800 hover:bg-neutral-100'
                  }`}
                >
                  {link.label}
                </button>
              ))}
            </div>

            <div className="mt-auto pt-6 border-t border-neutral-200 space-y-3">
              <button
                onClick={() => {
                  onNavigate('track-order');
                  setIsMobileMenuOpen(false);
                }}
                className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm font-medium text-neutral-700 bg-neutral-100 rounded-xl cursor-pointer"
              >
                <Truck className="w-4 h-4 text-amber-500" />
                Track Order
              </button>
              <button
                onClick={() => {
                  onNavigate('admin-login');
                  setIsMobileMenuOpen(false);
                }}
                className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm font-medium text-amber-900 bg-amber-50 rounded-xl cursor-pointer"
              >
                <SlidersHorizontal className="w-4 h-4 text-amber-600" />
                Admin Dashboard
              </button>
            </div>
          </div>
          <div className="flex-1" onClick={() => setIsMobileMenuOpen(false)} />
        </div>
      )}
    </header>
  );
};
