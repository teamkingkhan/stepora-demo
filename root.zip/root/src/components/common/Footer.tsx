import React, { useState } from 'react';
import { Mail, Phone, MapPin, ArrowRight, ShieldCheck, Heart, Send } from 'lucide-react';
import { useSettings } from '../../context/SettingsContext';
import { useToast } from '../../context/ToastContext';

interface FooterProps {
  onNavigate: (page: string, params?: any) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const { settings } = useSettings();
  const { showToast } = useToast();
  const [newsletterEmail, setNewsletterEmail] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail || !newsletterEmail.includes('@')) {
      showToast('Please enter a valid email address.', 'error');
      return;
    }
    showToast('Subscribed! Check your inbox for 10% off your first footwear order.', 'success');
    setNewsletterEmail('');
  };

  return (
    <footer className="bg-neutral-950 text-neutral-300 pt-16 pb-12 border-t border-neutral-900 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Newsletter Section */}
        <div className="bg-gradient-to-r from-neutral-900 via-neutral-900 to-amber-950/40 p-8 sm:p-12 rounded-3xl border border-neutral-800 mb-16 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <span className="text-amber-500 text-xs font-bold uppercase tracking-widest">
                Join the Footwear Club
              </span>
              <h3 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
                Unlock 10% Off Your First Pair
              </h3>
              <p className="text-neutral-400 text-sm mt-2 max-w-md">
                Be the first to know about limited shoe drops, private seasonal sales, and Bangladesh artisanal leather releases.
              </p>
            </div>
            <div>
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3">
                <input
                  type="email"
                  placeholder="Enter your email address..."
                  value={newsletterEmail}
                  onChange={e => setNewsletterEmail(e.target.value)}
                  className="flex-1 px-5 py-3.5 rounded-xl bg-neutral-950/80 border border-neutral-700 text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500 text-sm"
                />
                <button
                  type="submit"
                  className="px-6 py-3.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold rounded-xl text-sm transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-lg hover:shadow-amber-500/20"
                >
                  <span>Subscribe</span>
                  <Send className="w-4 h-4" />
                </button>
              </form>
              <p className="text-[11px] text-neutral-500 mt-2">
                We respect your privacy. No spam, unsubscribe anytime.
              </p>
            </div>
          </div>
        </div>

        {/* Links Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 mb-16">
          {/* Brand Info */}
          <div className="col-span-2">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-9 h-9 rounded-xl bg-white flex items-center justify-center text-neutral-950 font-extrabold text-lg">
                S
              </div>
              <span className="text-2xl font-extrabold tracking-tight text-white uppercase font-sans">
                {settings.storeName.split(' ')[0] || 'STEPORA'}
              </span>
            </div>
            <p className="text-neutral-400 text-sm leading-relaxed mb-6 max-w-sm">
              Crafting premium contemporary footwear with uncompromising ergonomics, full-grain leathers, and modern athletic cushioning. Made for life in motion across Bangladesh.
            </p>
            <div className="space-y-2 text-xs text-neutral-400">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <span>{settings.storeAddress}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-amber-500 shrink-0" />
                <span>{settings.storePhone}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-amber-500 shrink-0" />
                <span>{settings.storeEmail}</span>
              </div>
            </div>
          </div>

          {/* Shop */}
          <div>
            <h4 className="text-white text-xs font-bold uppercase tracking-wider mb-4">Shop Footwear</h4>
            <ul className="space-y-2.5 text-sm text-neutral-400">
              <li>
                <button onClick={() => onNavigate('shop', { category: 'men' })} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Men's Shoes
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('shop', { category: 'women' })} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Women's Shoes
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('shop', { category: 'sneakers' })} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Sneakers
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('shop', { category: 'sports' })} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Sports & Running
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('shop', { category: 'formal' })} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Formal Leather
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('shop', { category: 'kids' })} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Kids' Shoes
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('shop', { discountOnly: 'true' })} className="text-rose-400 hover:text-rose-300 font-semibold cursor-pointer">
                  Seasonal Sale %
                </button>
              </li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h4 className="text-white text-xs font-bold uppercase tracking-wider mb-4">Customer Care</h4>
            <ul className="space-y-2.5 text-sm text-neutral-400">
              <li>
                <button onClick={() => onNavigate('track-order')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Track Order
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('contact')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Contact Us
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('faq')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  FAQ & Sizing Help
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('shipping-policy')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Shipping Policy
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('return-policy')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  7-Day Return Policy
                </button>
              </li>
            </ul>
          </div>

          {/* Company & Legal */}
          <div>
            <h4 className="text-white text-xs font-bold uppercase tracking-wider mb-4">Company</h4>
            <ul className="space-y-2.5 text-sm text-neutral-400">
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  About STEPORA
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('privacy-policy')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('terms-conditions')} className="hover:text-amber-400 transition-colors cursor-pointer">
                  Terms & Conditions
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('admin-login')} className="text-xs text-neutral-500 hover:text-neutral-300 transition-colors cursor-pointer pt-2 inline-block">
                  Staff Login (Admin)
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bangladesh Payment Gateway Badges & Security */}
        <div className="pt-8 border-t border-neutral-900 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-xs text-neutral-500 font-semibold mr-2">Accepted Payment:</span>
            {/* bKash badge */}
            <div className="px-2.5 py-1 bg-white text-[#D12053] font-black text-xs rounded-md shadow-sm border border-neutral-800 flex items-center gap-1">
              <span>bKash</span>
            </div>
            {/* Nagad badge */}
            <div className="px-2.5 py-1 bg-white text-[#F7931E] font-black text-xs rounded-md shadow-sm border border-neutral-800 flex items-center gap-1">
              <span>Nagad</span>
            </div>
            {/* Visa / Master badge */}
            <div className="px-2.5 py-1 bg-neutral-900 text-white font-bold text-xs rounded-md border border-neutral-800 flex items-center gap-1">
              <span>Visa / Mastercard</span>
            </div>
            {/* Cash on Delivery badge */}
            <div className="px-2.5 py-1 bg-emerald-950/70 text-emerald-400 font-bold text-xs rounded-md border border-emerald-800/50 flex items-center gap-1">
              <span>Cash on Delivery</span>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs text-neutral-500">
            <p>© {new Date().getFullYear()} {settings.storeName}. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};
