import React, { useState, useEffect } from 'react';
import { ToastProvider } from './context/ToastContext';
import { SettingsProvider } from './context/SettingsContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import { WishlistProvider } from './context/WishlistContext';

import { Header } from './components/common/Header';
import { Footer } from './components/common/Footer';

// Customer Pages
import { HomePage } from './pages/customer/HomePage';
import { ShopPage } from './pages/customer/ShopPage';
import { ProductDetailsPage } from './pages/customer/ProductDetailsPage';
import { CategoriesPage } from './pages/customer/CategoriesPage';
import { CartPage } from './pages/customer/CartPage';
import { CheckoutPage } from './pages/customer/CheckoutPage';
import { OrderSuccessPage } from './pages/customer/OrderSuccessPage';
import { MyAccountPage } from './pages/customer/MyAccountPage';
import { WishlistPage } from './pages/customer/WishlistPage';
import { AuthPages } from './pages/customer/AuthPages';
import { TrackOrderPage } from './pages/customer/TrackOrderPage';
import { StaticPages } from './pages/customer/StaticPages';
import { NotFoundPage } from './pages/customer/NotFoundPage';

// Admin Pages
import { AdminLoginPage } from './pages/admin/AdminLoginPage';
import { AdminLayout, AdminTab } from './pages/admin/AdminLayout';
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage';
import { AdminProductsPage } from './pages/admin/AdminProductsPage';
import { AdminCategoriesPage } from './pages/admin/AdminCategoriesPage';
import { AdminOrdersPage } from './pages/admin/AdminOrdersPage';
import { AdminCustomersPage } from './pages/admin/AdminCustomersPage';
import { AdminInventoryPage } from './pages/admin/AdminInventoryPage';
import { AdminCouponsPage } from './pages/admin/AdminCouponsPage';
import { AdminReviewsPage } from './pages/admin/AdminReviewsPage';
import { AdminPaymentsPage } from './pages/admin/AdminPaymentsPage';
import { AdminReportsPage } from './pages/admin/AdminReportsPage';
import { AdminSettingsPage } from './pages/admin/AdminSettingsPage';
import { AdminProfilePage } from './pages/admin/AdminProfilePage';

interface NavigationState {
  page: string;
  params?: any;
}

const MainApp: React.FC = () => {
  const { isAdminAuthenticated } = useAuth();

  const [navState, setNavState] = useState<NavigationState>(() => {
    const hash = window.location.hash.replace('#', '');
    if (hash.startsWith('admin')) {
      return { page: hash || 'admin-dashboard' };
    }
    return { page: 'home' };
  });

  const [adminTab, setAdminTab] = useState<AdminTab>('dashboard');

  const navigate = (page: string, params?: any) => {
    setNavState({ page, params });
    window.location.hash = page;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Sync back/forward button
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '') || 'home';
      setNavState(prev => (prev.page === hash ? prev : { page: hash }));
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const { page, params } = navState;

  // ADMIN PORTAL ROUTING
  if (page.startsWith('admin')) {
    if (page === 'admin-login') {
      return (
        <AdminLoginPage
          onLoginSuccess={() => navigate('admin-dashboard')}
          onNavigateHome={() => navigate('home')}
        />
      );
    }

    if (!isAdminAuthenticated) {
      return (
        <AdminLoginPage
          onLoginSuccess={() => navigate('admin-dashboard')}
          onNavigateHome={() => navigate('home')}
        />
      );
    }

    return (
      <AdminLayout
        currentTab={adminTab}
        onSelectTab={tab => setAdminTab(tab)}
        onNavigateToStore={() => navigate('home')}
      >
        {adminTab === 'dashboard' && <AdminDashboardPage onSelectTab={t => setAdminTab(t)} />}
        {adminTab === 'products' && <AdminProductsPage />}
        {adminTab === 'add-product' && <AdminProductsPage onOpenCreate />}
        {adminTab === 'categories' && <AdminCategoriesPage />}
        {adminTab === 'orders' && <AdminOrdersPage />}
        {adminTab === 'customers' && <AdminCustomersPage />}
        {adminTab === 'inventory' && <AdminInventoryPage />}
        {adminTab === 'coupons' && <AdminCouponsPage />}
        {adminTab === 'reviews' && <AdminReviewsPage />}
        {adminTab === 'payments' && <AdminPaymentsPage />}
        {adminTab === 'reports' && <AdminReportsPage />}
        {adminTab === 'settings' && <AdminSettingsPage />}
        {adminTab === 'profile' && <AdminProfilePage />}
      </AdminLayout>
    );
  }

  // CUSTOMER STOREFRONT ROUTING
  return (
    <div className="min-h-screen flex flex-col bg-neutral-50/50">
      <Header onNavigate={navigate} currentPage={page} />

      <main className="flex-1">
        {page === 'home' && <HomePage onNavigate={navigate} />}
        {page === 'shop' && <ShopPage onNavigate={navigate} initialParams={params} />}
        {page === 'product-details' && (
          <ProductDetailsPage productId={params?.id || 'prod-001'} onNavigate={navigate} />
        )}
        {page === 'categories' && <CategoriesPage onNavigate={navigate} />}
        {page === 'cart' && <CartPage onNavigate={navigate} />}
        {page === 'checkout' && <CheckoutPage onNavigate={navigate} />}
        {page === 'order-success' && (
          <OrderSuccessPage orderId={params?.orderId} onNavigate={navigate} />
        )}
        {page === 'my-account' && <MyAccountPage onNavigate={navigate} initialTab="profile" />}
        {page === 'my-orders' && <MyAccountPage onNavigate={navigate} initialTab="orders" />}
        {page === 'wishlist' && <WishlistPage onNavigate={navigate} />}

        {page === 'login' && <AuthPages mode="login" onNavigate={navigate} />}
        {page === 'register' && <AuthPages mode="register" onNavigate={navigate} />}
        {page === 'forgot-password' && <AuthPages mode="forgot" onNavigate={navigate} />}
        {page === 'reset-password' && <AuthPages mode="reset" onNavigate={navigate} />}

        {page === 'track-order' && (
          <TrackOrderPage initialQuery={params?.query} onNavigate={navigate} />
        )}

        {page === 'about' && <StaticPages page="about" onNavigate={navigate} />}
        {page === 'contact' && <StaticPages page="contact" onNavigate={navigate} />}
        {page === 'faq' && <StaticPages page="faq" onNavigate={navigate} />}
        {page === 'shipping-policy' && <StaticPages page="shipping" onNavigate={navigate} />}
        {page === 'return-policy' && <StaticPages page="return" onNavigate={navigate} />}
        {page === 'privacy-policy' && <StaticPages page="privacy" onNavigate={navigate} />}
        {page === 'terms-conditions' && <StaticPages page="terms" onNavigate={navigate} />}

        {![
          'home',
          'shop',
          'product-details',
          'categories',
          'cart',
          'checkout',
          'order-success',
          'my-account',
          'my-orders',
          'wishlist',
          'login',
          'register',
          'forgot-password',
          'reset-password',
          'track-order',
          'about',
          'contact',
          'faq',
          'shipping-policy',
          'return-policy',
          'privacy-policy',
          'terms-conditions',
        ].includes(page) && <NotFoundPage onNavigate={navigate} />}
      </main>

      <Footer onNavigate={navigate} />
    </div>
  );
};

export default function App() {
  return (
    <ToastProvider>
      <SettingsProvider>
        <AuthProvider>
          <CartProvider>
            <WishlistProvider>
              <MainApp />
            </WishlistProvider>
          </CartProvider>
        </AuthProvider>
      </SettingsProvider>
    </ToastProvider>
  );
}
