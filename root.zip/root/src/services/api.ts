import { Product, Category, Order, User, Review, Coupon, StoreSettings, DashboardStats } from '../types';

const BASE_URL = '/api';

function getAuthHeader(tokenType: 'customer' | 'admin' = 'customer'): HeadersInit {
  const key = tokenType === 'admin' ? 'stepora_admin_token' : 'stepora_customer_token';
  const token = localStorage.getItem(key);
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function request<T>(endpoint: string, options: RequestInit = {}, authType?: 'customer' | 'admin'): Promise<T> {
  const headers = {
    'Content-Type': 'application/json',
    ...(authType ? getAuthHeader(authType) : {}),
    ...options.headers,
  };

  const response = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error || 'Network request failed. Please try again.');
  }
  return data as T;
}

export const api = {
  // Settings
  getSettings: () => request<{ settings: StoreSettings }>('/settings'),
  updateAdminSettings: (data: Partial<StoreSettings>) =>
    request<{ settings: StoreSettings; message: string }>('/admin/settings', { method: 'PUT', body: JSON.stringify(data) }, 'admin'),

  // Products
  getProducts: (params?: Record<string, string>) => {
    const qs = params ? '?' + new URLSearchParams(params).toString() : '';
    return request<{ products: Product[]; total: number; page: number; totalPages: number }>(`/products${qs}`);
  },
  getProductById: (id: string) => request<{ product: Product; related: Product[] }>(`/products/${id}`),

  // Categories
  getCategories: () => request<{ categories: Category[] }>('/categories'),

  // Customer Auth
  register: (body: any) => request<{ message: string; token: string; user: User }>('/auth/register', { method: 'POST', body: JSON.stringify(body) }),
  login: (body: any) => request<{ message: string; token: string; user: User }>('/auth/login', { method: 'POST', body: JSON.stringify(body) }),
  getMe: () => request<{ user: User }>('/auth/me', {}, 'customer'),
  updateProfile: (body: any) => request<{ message: string; user: User }>('/auth/profile', { method: 'PUT', body: JSON.stringify(body) }, 'customer'),
  changePassword: (body: any) => request<{ message: string }>('/auth/change-password', { method: 'POST', body: JSON.stringify(body) }, 'customer'),
  forgotPassword: (body: any) => request<{ message: string; demoResetToken?: string }>('/auth/forgot-password', { method: 'POST', body: JSON.stringify(body) }),
  resetPassword: (body: any) => request<{ message: string }>('/auth/reset-password', { method: 'POST', body: JSON.stringify(body) }),

  // Admin Auth
  adminLogin: (body: any) => request<{ message: string; token: string; admin: User; isDefaultPassword?: boolean }>('/admin/login', { method: 'POST', body: JSON.stringify(body) }),
  getAdminMe: () => request<{ admin: User }>('/admin/me', {}, 'admin'),
  changeAdminPassword: (body: any) => request<{ message: string }>('/admin/change-password', { method: 'POST', body: JSON.stringify(body) }, 'admin'),

  // Coupons
  applyCoupon: (code: string, subtotal: number) =>
    request<{ valid: boolean; code: string; discountAmount: number; message: string }>('/coupons/apply', { method: 'POST', body: JSON.stringify({ code, subtotal }) }),

  // Orders
  createOrder: (orderData: any) => request<{ message: string; order: Order }>('/orders', { method: 'POST', body: JSON.stringify(orderData) }),
  getOrderById: (id: string) => request<{ order: Order }>(`/orders/${id}`),
  trackOrder: (query: string) => request<{ order: Order }>(`/orders/track?query=${encodeURIComponent(query)}`),
  getCustomerOrders: () => request<{ orders: Order[] }>('/customer/orders', {}, 'customer'),

  // Payment
  createPayment: (orderId: string, method: string) =>
    request<any>('/payment/create', { method: 'POST', body: JSON.stringify({ orderId, method }) }),
  verifyPayment: (data: any) =>
    request<any>('/payment/verify', { method: 'POST', body: JSON.stringify(data) }),

  // Reviews
  getProductReviews: (productId: string) => request<{ reviews: Review[] }>(`/products/${productId}/reviews`),
  submitReview: (productId: string, data: any) => request<{ message: string; review: Review }>(`/products/${productId}/reviews`, { method: 'POST', body: JSON.stringify(data) }),

  // Admin Features
  getAdminDashboard: () => request<{ stats: DashboardStats }>('/admin/dashboard', {}, 'admin'),
  getAdminProducts: () => request<{ products: Product[] }>('/admin/products', {}, 'admin'),
  createAdminProduct: (product: any) => request<{ message: string; product: Product }>('/admin/products', { method: 'POST', body: JSON.stringify(product) }, 'admin'),
  updateAdminProduct: (id: string, updates: any) => request<{ message: string; product: Product }>(`/admin/products/${id}`, { method: 'PUT', body: JSON.stringify(updates) }, 'admin'),
  deleteAdminProduct: (id: string) => request<{ message: string }>(`/admin/products/${id}`, { method: 'DELETE' }, 'admin'),
  duplicateAdminProduct: (id: string) => request<{ message: string; product: Product }>(`/admin/products/${id}/duplicate`, { method: 'POST' }, 'admin'),

  getAdminCategories: () => request<{ categories: Category[] }>('/admin/categories', {}, 'admin'),
  createAdminCategory: (cat: any) => request<{ message: string; category: Category }>('/admin/categories', { method: 'POST', body: JSON.stringify(cat) }, 'admin'),
  updateAdminCategory: (id: string, updates: any) => request<{ message: string; category: Category }>(`/admin/categories/${id}`, { method: 'PUT', body: JSON.stringify(updates) }, 'admin'),
  deleteAdminCategory: (id: string) => request<{ message: string }>(`/admin/categories/${id}`, { method: 'DELETE' }, 'admin'),

  getAdminOrders: (params?: Record<string, string>) => {
    const qs = params ? '?' + new URLSearchParams(params).toString() : '';
    return request<{ orders: Order[] }>(`/admin/orders${qs}`, {}, 'admin');
  },
  updateAdminOrderStatus: (id: string, updates: any) =>
    request<{ message: string; order: Order }>(`/admin/orders/${id}/status`, { method: 'PUT', body: JSON.stringify(updates) }, 'admin'),

  getAdminCustomers: () => request<{ customers: any[] }>('/admin/customers', {}, 'admin'),
  updateCustomerStatus: (id: string, isActive: boolean) =>
    request<{ message: string; customer: any }>(`/admin/customers/${id}/status`, { method: 'PUT', body: JSON.stringify({ isActive }) }, 'admin'),

  getAdminInventory: () => request<{ inventory: any[] }>('/admin/inventory', {}, 'admin'),
  updateAdminInventory: (productId: string, size: string | undefined, newStock: number) =>
    request<{ message: string; product: Product }>('/admin/inventory/update', { method: 'POST', body: JSON.stringify({ productId, size, newStock }) }, 'admin'),

  getAdminCoupons: () => request<{ coupons: Coupon[] }>('/admin/coupons', {}, 'admin'),
  createAdminCoupon: (coupon: any) => request<{ message: string; coupon: Coupon }>('/admin/coupons', { method: 'POST', body: JSON.stringify(coupon) }, 'admin'),
  updateAdminCoupon: (id: string, updates: any) => request<{ message: string; coupon: Coupon }>(`/admin/coupons/${id}`, { method: 'PUT', body: JSON.stringify(updates) }, 'admin'),
  deleteAdminCoupon: (id: string) => request<{ message: string }>(`/admin/coupons/${id}`, { method: 'DELETE' }, 'admin'),

  getAdminReviews: () => request<{ reviews: Review[] }>('/admin/reviews', {}, 'admin'),
  updateAdminReviewStatus: (id: string, status: string) =>
    request<{ message: string; review: Review }>(`/admin/reviews/${id}/status`, { method: 'PUT', body: JSON.stringify({ status }) }, 'admin'),
  deleteAdminReview: (id: string) => request<{ message: string }>(`/admin/reviews/${id}`, { method: 'DELETE' }, 'admin'),

  getAdminReportsSummary: () => request<{ summary: any }>('/admin/reports', {}, 'admin'),
};
