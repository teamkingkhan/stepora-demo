export type ShoeSize = '36' | '37' | '38' | '39' | '40' | '41' | '42' | '43' | '44' | '45' | '46';

export interface ProductColor {
  name: string;
  hex: string;
  image?: string;
}

export interface SizeStock {
  size: ShoeSize;
  stock: number;
}

export interface ProductSpecification {
  upperMaterial: string;
  soleMaterial: string;
  insole: string;
  closure: string;
  weight: string;
  origin: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  sku: string;
  category: string;
  subcategory?: string;
  gender: 'men' | 'women' | 'kids' | 'unisex';
  brand: string;
  description: string;
  shortDescription: string;
  price: number;
  salePrice: number;
  discountPercentage: number;
  stockQuantity: number;
  availableSizes: ShoeSize[];
  sizeStock: SizeStock[];
  availableColors: ProductColor[];
  mainImage: string;
  images: string[];
  tags: string[];
  featured: boolean;
  bestSeller: boolean;
  newArrival: boolean;
  isActive: boolean;
  rating: number;
  reviewCount: number;
  specifications: ProductSpecification;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
  itemCount: number;
  featured: boolean;
  isActive: boolean;
}

export interface CartItem {
  id: string;
  productId: string;
  name: string;
  slug: string;
  price: number;
  salePrice: number;
  image: string;
  brand: string;
  selectedSize: ShoeSize;
  selectedColor: ProductColor;
  quantity: number;
  maxStock: number;
}

export interface CartSummary {
  items: CartItem[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  couponDiscount: number;
  shippingFee: number;
  tax: number;
  grandTotal: number;
}

export type OrderStatus =
  | 'Pending'
  | 'Confirmed'
  | 'Processing'
  | 'Packed'
  | 'Shipped'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Cancelled'
  | 'Returned'
  | 'Refunded';

export type PaymentMethod = 'bkash' | 'nagad' | 'card' | 'cod';

export type PaymentStatus =
  | 'Pending'
  | 'Processing'
  | 'Paid'
  | 'Failed'
  | 'Cancelled'
  | 'Refunded';

export interface ShippingAddress {
  fullName: string;
  phoneNumber: string;
  email: string;
  division: string;
  district: string;
  area: string;
  fullAddress: string;
  postalCode?: string;
  notes?: string;
}

export interface OrderItem {
  productId: string;
  productName: string;
  sku: string;
  image: string;
  price: number;
  quantity: number;
  selectedSize: ShoeSize;
  selectedColor: ProductColor;
  itemTotal: number;
}

export interface OrderTimeline {
  status: OrderStatus;
  title: string;
  description: string;
  timestamp: string;
  isCompleted: boolean;
}

export interface Order {
  id: string;
  orderNumber: string; // e.g. ORD-2026-000101
  customerId?: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  shippingFee: number;
  shippingRegion: 'inside_dhaka' | 'outside_dhaka';
  total: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  transactionId?: string;
  orderStatus: OrderStatus;
  shippingAddress: ShippingAddress;
  timeline: OrderTimeline[];
  createdAt: string;
  updatedAt: string;
}

export interface User {
  id: string;
  fullName: string;
  email: string;
  phoneNumber: string;
  role: 'customer' | 'admin';
  isActive: boolean;
  savedAddresses?: ShippingAddress[];
  createdAt: string;
}

export interface Review {
  id: string;
  productId: string;
  userId?: string;
  userName: string;
  userEmail: string;
  rating: number;
  comment: string;
  title: string;
  isVerifiedPurchase: boolean;
  status: 'approved' | 'pending' | 'hidden';
  createdAt: string;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrderAmount: number;
  maxDiscountAmount: number;
  startDate: string;
  expiryDate: string;
  usageLimit: number;
  usageCount: number;
  isActive: boolean;
}

export interface StoreSettings {
  storeName: string;
  logoUrl: string;
  storeEmail: string;
  storePhone: string;
  storeAddress: string;
  currency: string;
  currencyCode: string;
  insideDhakaShippingFee: number;
  outsideDhakaShippingFee: number;
  freeShippingThreshold: number;
  taxPercentage: number;
  enableBkash: boolean;
  enableNagad: boolean;
  enableCard: boolean;
  enableCod: boolean;
  paymentTestMode: boolean;
  facebookUrl: string;
  instagramUrl: string;
  youtubeUrl: string;
  tiktokUrl: string;
}

export interface DashboardStats {
  totalSales: number;
  todaySales: number;
  monthlySales: number;
  totalOrders: number;
  pendingOrders: number;
  completedOrders: number;
  cancelledOrders: number;
  totalCustomers: number;
  totalProducts: number;
  lowStockCount: number;
  outOfStockCount: number;
  totalRevenue: number;
  salesOverview: { date: string; amount: number; orders: number }[];
  categoryPerformance: { category: string; sales: number; count: number }[];
  topSellingProducts: { id: string; name: string; sales: number; revenue: number; image: string }[];
}
