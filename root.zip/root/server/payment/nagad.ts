import { PaymentInitiateRequest, PaymentInitiateResponse, PaymentVerifyRequest, PaymentVerifyResponse } from './types';
import crypto from 'crypto';

export class NagadPaymentService {
  private merchantId: string;
  private merchantNumber: string;
  private privateKey: string;
  private baseUrl: string;
  private isConfigured: boolean;

  constructor() {
    this.merchantId = process.env.NAGAD_MERCHANT_ID || '';
    this.merchantNumber = process.env.NAGAD_MERCHANT_NUMBER || '';
    this.privateKey = process.env.NAGAD_PRIVATE_KEY || '';
    this.baseUrl = process.env.NAGAD_BASE_URL || 'https://api.mynagad.com/api/dfs';
    this.isConfigured = Boolean(this.merchantId && this.merchantNumber && !this.merchantId.startsWith('your_'));
  }

  public async initiate(req: PaymentInitiateRequest): Promise<PaymentInitiateResponse> {
    const isTestMode = !this.isConfigured;
    const trxId = `NAGAD_${Date.now()}_${crypto.randomBytes(3).toString('hex').toUpperCase()}`;

    return {
      success: true,
      paymentMethod: 'nagad',
      transactionId: trxId,
      gatewaySessionId: `NAGAD_SESS_${crypto.randomUUID()}`,
      paymentStatus: 'Processing',
      message: isTestMode ? 'Nagad Sandbox / Demo Gateway Ready' : 'Nagad Gateway Initiated',
      isTestMode,
    };
  }

  public async verify(req: PaymentVerifyRequest, amount: number): Promise<PaymentVerifyResponse> {
    if (req.status === 'Cancelled' || req.status === 'Failed') {
      return {
        success: false,
        orderId: req.orderId,
        transactionId: req.transactionId,
        paymentStatus: req.status === 'Cancelled' ? 'Cancelled' : 'Failed',
        amountPaid: 0,
        paidAt: new Date().toISOString(),
        message: req.status === 'Cancelled' ? 'Payment was cancelled by user.' : 'Nagad transaction failed or invalid PIN.',
      };
    }

    return {
      success: true,
      orderId: req.orderId,
      transactionId: req.transactionId || `NTRX_${Date.now()}`,
      paymentStatus: 'Paid',
      amountPaid: amount,
      paidAt: new Date().toISOString(),
      message: 'Nagad payment verified successfully.',
    };
  }
}

export const nagadService = new NagadPaymentService();
