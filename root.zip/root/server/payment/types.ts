import { PaymentMethod, PaymentStatus } from '../../src/types';

export interface PaymentInitiateRequest {
  orderId: string;
  orderNumber: string;
  amount: number;
  currency: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  callbackUrl?: string;
}

export interface PaymentInitiateResponse {
  success: boolean;
  paymentMethod: PaymentMethod;
  transactionId: string;
  redirectUrl?: string;
  gatewaySessionId?: string;
  paymentStatus: PaymentStatus;
  message: string;
  isTestMode: boolean;
}

export interface PaymentVerifyRequest {
  orderId: string;
  paymentMethod: PaymentMethod;
  transactionId: string;
  paymentId?: string;
  otpOrPin?: string;
  status?: string;
}

export interface PaymentVerifyResponse {
  success: boolean;
  orderId: string;
  transactionId: string;
  paymentStatus: PaymentStatus;
  amountPaid: number;
  paidAt: string;
  message: string;
  gatewayResponse?: any;
}
