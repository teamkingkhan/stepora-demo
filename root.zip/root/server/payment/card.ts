import { PaymentInitiateRequest, PaymentInitiateResponse, PaymentVerifyRequest, PaymentVerifyResponse } from './types';
import crypto from 'crypto';

export class CardPaymentService {
  private secretKey: string;
  private publishableKey: string;
  private isConfigured: boolean;

  constructor() {
    this.secretKey = process.env.STRIPE_SECRET_KEY || '';
    this.publishableKey = process.env.STRIPE_PUBLISHABLE_KEY || '';
    this.isConfigured = Boolean(this.secretKey && !this.secretKey.startsWith('sk_test_your_'));
  }

  public async initiate(req: PaymentInitiateRequest): Promise<PaymentInitiateResponse> {
    const isTestMode = !this.isConfigured;
    const trxId = `CARD_${Date.now()}_${crypto.randomBytes(3).toString('hex').toUpperCase()}`;

    return {
      success: true,
      paymentMethod: 'card',
      transactionId: trxId,
      gatewaySessionId: `CARD_SESS_${crypto.randomUUID()}`,
      paymentStatus: 'Processing',
      message: isTestMode ? 'Credit/Debit Card Demo Gateway Active' : 'Stripe Payment Ready',
      isTestMode,
    };
  }

  public async verify(req: PaymentVerifyRequest, amount: number): Promise<PaymentVerifyResponse> {
    if (req.status === 'Failed') {
      return {
        success: false,
        orderId: req.orderId,
        transactionId: req.transactionId,
        paymentStatus: 'Failed',
        amountPaid: 0,
        paidAt: new Date().toISOString(),
        message: 'Card payment was declined by the issuing bank.',
      };
    }

    return {
      success: true,
      orderId: req.orderId,
      transactionId: req.transactionId || `CARD_TRX_${Date.now()}`,
      paymentStatus: 'Paid',
      amountPaid: amount,
      paidAt: new Date().toISOString(),
      message: 'Card payment charged successfully.',
    };
  }
}

export const cardService = new CardPaymentService();
