import { BkashPaymentService, bkashService } from './bkash';
import { NagadPaymentService, nagadService } from './nagad';
import { CardPaymentService, cardService } from './card';
import { CodPaymentService, codService } from './cod';
import { PaymentInitiateRequest, PaymentInitiateResponse, PaymentVerifyRequest, PaymentVerifyResponse } from './types';
import { PaymentMethod } from '../../src/types';

export class PaymentGatewayManager {
  public static async initiate(method: PaymentMethod, req: PaymentInitiateRequest): Promise<PaymentInitiateResponse> {
    switch (method) {
      case 'bkash':
        return await bkashService.initiate(req);
      case 'nagad':
        return await nagadService.initiate(req);
      case 'card':
        return await cardService.initiate(req);
      case 'cod':
      default:
        return await codService.initiate(req);
    }
  }

  public static async verify(
    method: PaymentMethod,
    req: PaymentVerifyRequest,
    amount: number
  ): Promise<PaymentVerifyResponse> {
    switch (method) {
      case 'bkash':
        return await bkashService.verify(req, amount);
      case 'nagad':
        return await nagadService.verify(req, amount);
      case 'card':
        return await cardService.verify(req, amount);
      case 'cod':
      default:
        return await codService.verify(req, amount);
    }
  }
}

export * from './types';
export { bkashService, nagadService, cardService, codService };
