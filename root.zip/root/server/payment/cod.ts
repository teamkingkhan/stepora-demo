import { PaymentInitiateRequest, PaymentInitiateResponse, PaymentVerifyRequest, PaymentVerifyResponse } from './types';

export class CodPaymentService {
  public async initiate(req: PaymentInitiateRequest): Promise<PaymentInitiateResponse> {
    const trxId = `COD_${Date.now()}`;
    return {
      success: true,
      paymentMethod: 'cod',
      transactionId: trxId,
      paymentStatus: 'Pending',
      message: 'Cash on Delivery selected. Pay when rider arrives at your doorstep.',
      isTestMode: false,
    };
  }

  public async verify(req: PaymentVerifyRequest, amount: number): Promise<PaymentVerifyResponse> {
    return {
      success: true,
      orderId: req.orderId,
      transactionId: req.transactionId || `COD_${Date.now()}`,
      paymentStatus: 'Pending', // COD remains Pending until delivered
      amountPaid: 0,
      paidAt: new Date().toISOString(),
      message: 'Cash on Delivery order confirmed.',
    };
  }
}

export const codService = new CodPaymentService();
