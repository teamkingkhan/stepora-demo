import fs from 'fs';
import path from 'path';
import { Product, Category, Order, User, Review, Coupon, StoreSettings, ShoeSize } from '../src/types';
import { hashPassword } from './auth';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.resolve(DATA_DIR, 'stepora.json');

export interface DatabaseSchema {
  products: Product[];
  categories: Category[];
  orders: Order[];
  users: (User & { passwordHash: string })[];
  coupons: Coupon[];
  reviews: Review[];
  settings: StoreSettings;
}

const DEFAULT_SETTINGS: StoreSettings = {
  storeName: 'STEPORA Footwear',
  logoUrl: '/stepora-logo.svg',
  storeEmail: 'support@stepora.com.bd',
  storePhone: '+880 1712 345678',
  storeAddress: 'House 42, Road 11, Banani, Dhaka-1213, Bangladesh',
  currency: '৳',
  currencyCode: 'BDT',
  insideDhakaShippingFee: 80,
  outsideDhakaShippingFee: 150,
  freeShippingThreshold: 3500,
  taxPercentage: 0,
  enableBkash: true,
  enableNagad: true,
  enableCard: true,
  enableCod: true,
  paymentTestMode: true,
  facebookUrl: 'https://facebook.com',
  instagramUrl: 'https://instagram.com',
  youtubeUrl: 'https://youtube.com',
  tiktokUrl: 'https://tiktok.com',
};

const DEFAULT_CATEGORIES: Category[] = [
  {
    id: 'cat-sneakers',
    name: 'Sneakers',
    slug: 'sneakers',
    description: 'Street-ready, ultra-cushioned lifestyle and luxury everyday sneakers.',
    image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=800&q=80',
    itemCount: 8,
    featured: true,
    isActive: true,
  },
  {
    id: 'cat-men',
    name: "Men's Shoes",
    slug: 'men',
    description: 'Engineered for confidence, longevity and sharp modern style.',
    image: 'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?auto=format&fit=crop&w=800&q=80',
    itemCount: 10,
    featured: true,
    isActive: true,
  },
  {
    id: 'cat-women',
    name: "Women's Shoes",
    slug: 'women',
    description: 'Graceful silhouettes, lightweight support and effortless elegance.',
    image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=800&q=80',
    itemCount: 8,
    featured: true,
    isActive: true,
  },
  {
    id: 'cat-sports',
    name: 'Sports & Running',
    slug: 'sports',
    description: 'Pro performance energy rebound, marathon cushioning and grip.',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80',
    itemCount: 6,
    featured: true,
    isActive: true,
  },
  {
    id: 'cat-formal',
    name: 'Formal Shoes',
    slug: 'formal',
    description: 'Genuine full-grain calf leather, Goodyear welted & handcrafted dress shoes.',
    image: 'https://images.unsplash.com/photo-1531310197839-ccf54634509e?auto=format&fit=crop&w=800&q=80',
    itemCount: 4,
    featured: true,
    isActive: true,
  },
  {
    id: 'cat-casual',
    name: 'Casual Shoes',
    slug: 'casual',
    description: 'Slip-ons, penny loafers and weekend lifestyle footwear.',
    image: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?auto=format&fit=crop&w=800&q=80',
    itemCount: 5,
    featured: true,
    isActive: true,
  },
  {
    id: 'cat-boots',
    name: 'Boots',
    slug: 'boots',
    description: 'Rugged combat boots, Chelsea leather boots and all-weather footwear.',
    image: 'https://images.unsplash.com/photo-1520639888713-7851133b1ed0?auto=format&fit=crop&w=800&q=80',
    itemCount: 3,
    featured: false,
    isActive: true,
  },
  {
    id: 'cat-sandals',
    name: 'Sandals & Slippers',
    slug: 'sandals',
    description: 'Ergonomic footbed slides, airy sandals and comfort slippers.',
    image: 'https://images.unsplash.com/photo-1603808033192-082d6919d3e1?auto=format&fit=crop&w=800&q=80',
    itemCount: 4,
    featured: false,
    isActive: true,
  },
  {
    id: 'cat-kids',
    name: "Kids' Shoes",
    slug: 'kids',
    description: 'Durable, supportive, high-traction kicks for little champions.',
    image: 'https://images.unsplash.com/photo-1514989940723-e8e51635b782?auto=format&fit=crop&w=800&q=80',
    itemCount: 3,
    featured: false,
    isActive: true,
  },
];

const SIZES_STANDARD: ShoeSize[] = ['38', '39', '40', '41', '42', '43', '44', '45'];
const SIZES_ALL: ShoeSize[] = ['36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46'];

function makeSizeStock(sizes: ShoeSize[], min = 4, max = 15) {
  return sizes.map(size => ({
    size,
    stock: Math.floor(Math.random() * (max - min + 1)) + min,
  }));
}

const DEFAULT_PRODUCTS: Product[] = [
  {
    id: 'prod-001',
    name: 'Apex Glide Nitro Running Shoes',
    slug: 'apex-glide-nitro-running-shoes',
    sku: 'STP-RUN-001',
    category: 'sports',
    subcategory: 'Running Shoes',
    gender: 'men',
    brand: 'STEPORA PRO',
    description: 'The Apex Glide Nitro sets a revolutionary standard for long-distance road running. Featuring a dual-density nitrogen-infused foam midsole with responsive TPU propulsion plate, each stride delivers explosive energy return. Breathable engineered mesh upper keeps your feet cool under the warmest Bangladeshi summer weather.',
    shortDescription: 'High-rebound nitrogen foam road runners with adaptive breathable mesh.',
    price: 4999,
    salePrice: 4299,
    discountPercentage: 14,
    stockQuantity: 48,
    availableSizes: ['39', '40', '41', '42', '43', '44', '45'],
    sizeStock: [
      { size: '39', stock: 6 },
      { size: '40', stock: 8 },
      { size: '41', stock: 10 },
      { size: '42', stock: 12 },
      { size: '43', stock: 7 },
      { size: '44', stock: 4 },
      { size: '45', stock: 1 },
    ],
    availableColors: [
      { name: 'Volt Black / Crimson', hex: '#E63946' },
      { name: 'Stealth Onyx', hex: '#1D1E22' },
      { name: 'Glacier Blue', hex: '#457B9D' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Running', 'Sports', 'Breathable', 'Nitro Foam', 'Trending'],
    featured: true,
    bestSeller: true,
    newArrival: false,
    isActive: true,
    rating: 4.9,
    reviewCount: 42,
    specifications: {
      upperMaterial: 'Engineered Multi-Layer AeroMesh',
      soleMaterial: 'Nitro Cushion Phylon & High-Abrasion Rubber',
      insole: 'Ortholite Molded Ergonomic Arch Insole',
      closure: 'Performance Speed Lace',
      weight: '245g (Size 42)',
      origin: 'Crafted in Bangladesh',
    },
    createdAt: '2026-01-15T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-002',
    name: 'Urban Velocity Minimalist White Sneaker',
    slug: 'urban-velocity-minimalist-white-sneaker',
    sku: 'STP-SNK-002',
    category: 'sneakers',
    subcategory: 'Casual Sneakers',
    gender: 'unisex',
    brand: 'STEPORA ORIGINALS',
    description: 'Timeless luxury meets everyday casual sophistication. Handcrafted with imported Napa calfskin leather, clean stitching and subtle gold foil branding on the heel counter. The memory-foam cupsole offers all-day comfort whether pairing with tailored trousers or weekend denim.',
    shortDescription: 'Clean Italian-inspired Napa leather low-top court sneakers.',
    price: 3850,
    salePrice: 3250,
    discountPercentage: 16,
    stockQuantity: 36,
    availableSizes: ['37', '38', '39', '40', '41', '42', '43', '44'],
    sizeStock: [
      { size: '37', stock: 4 },
      { size: '38', stock: 5 },
      { size: '39', stock: 6 },
      { size: '40', stock: 7 },
      { size: '41', stock: 8 },
      { size: '42', stock: 3 },
      { size: '43', stock: 2 },
      { size: '44', stock: 1 },
    ],
    availableColors: [
      { name: 'Crisp Cloud White', hex: '#F8F9FA' },
      { name: 'Bone White / Gum Sole', hex: '#E9ECEF' },
      { name: 'White & Emerald Accent', hex: '#2D6A4F' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Sneakers', 'White Sneaker', 'Minimalist', 'Leather', 'Best Seller'],
    featured: true,
    bestSeller: true,
    newArrival: false,
    isActive: true,
    rating: 4.8,
    reviewCount: 68,
    specifications: {
      upperMaterial: '100% Genuine Full Grain Napa Leather',
      soleMaterial: 'Vulcanized Rubber Cupsole',
      insole: 'Cushioned Memory Foam with Leather Lining',
      closure: '100% Waxed Cotton Laces',
      weight: '320g',
      origin: 'Handmade in Bangladesh',
    },
    createdAt: '2026-01-20T10:00:00Z',
    updatedAt: '2026-03-02T12:00:00Z',
  },
  {
    id: 'prod-003',
    name: 'Monarch Goodyear Welted Oxford Shoes',
    slug: 'monarch-goodyear-welted-oxford-shoes',
    sku: 'STP-FRM-003',
    category: 'formal',
    subcategory: 'Oxfords',
    gender: 'men',
    brand: 'STEPORA HERITAGE',
    description: 'The pinnacle of gentlemen footwear. Meticulously handcrafted by master cobblers with burnished French box calf leather. Featuring authentic Goodyear welt construction, closed lacing, and hand-finished Argentine leather outsoles for unmatched elegance in boardroom meetings and black-tie celebrations.',
    shortDescription: 'Hand-burnished full-grain leather classic closed-lace dress Oxfords.',
    price: 7850,
    salePrice: 6990,
    discountPercentage: 11,
    stockQuantity: 22,
    availableSizes: ['39', '40', '41', '42', '43', '44', '45'],
    sizeStock: [
      { size: '39', stock: 2 },
      { size: '40', stock: 4 },
      { size: '41', stock: 6 },
      { size: '42', stock: 5 },
      { size: '43', stock: 3 },
      { size: '44', stock: 2 },
      { size: '45', stock: 0 },
    ],
    availableColors: [
      { name: 'Burnished Espresso Brown', hex: '#4A2C11' },
      { name: 'Onyx Black Piano Polish', hex: '#141414' },
      { name: 'Antique Tan Cognac', hex: '#9C6644' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1531310197839-ccf54634509e?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Formal', 'Leather', 'Oxford', 'Goodyear Welt', 'Luxury'],
    featured: true,
    bestSeller: false,
    newArrival: true,
    isActive: true,
    rating: 5.0,
    reviewCount: 19,
    specifications: {
      upperMaterial: 'Imported French Calf Box Leather',
      soleMaterial: 'Argentine Veg-Tanned Oak Bark Leather Sole with Rubber Heel Tap',
      insole: 'Full Natural Leather Sockliner & Cork Midsole',
      closure: '5-Eyelet Blind Facings',
      weight: '440g',
      origin: 'Artisanal Heritage Workshop',
    },
    createdAt: '2026-02-01T10:00:00Z',
    updatedAt: '2026-03-05T12:00:00Z',
  },
  {
    id: 'prod-004',
    name: 'Highland Rugged Chelsea Boot',
    slug: 'highland-rugged-chelsea-boot',
    sku: 'STP-BOT-004',
    category: 'boots',
    subcategory: 'Chelsea Boots',
    gender: 'men',
    brand: 'STEPORA HERITAGE',
    description: 'Built to withstand rough city streets and countryside adventures. Oil-waxed pull-up leather that matures with a handsome patina over time. Flexible twin elastic gussets and heavy-duty front and rear pull tabs ensure effortless slip-on action, anchored by a deep lugged Commando rubber outsole.',
    shortDescription: 'Water-resistant waxed leather Chelsea boot with rugged lugged traction.',
    price: 6490,
    salePrice: 5690,
    discountPercentage: 12,
    stockQuantity: 28,
    availableSizes: ['40', '41', '42', '43', '44', '45'],
    sizeStock: [
      { size: '40', stock: 4 },
      { size: '41', stock: 6 },
      { size: '42', stock: 8 },
      { size: '43', stock: 5 },
      { size: '44', stock: 3 },
      { size: '45', stock: 2 },
    ],
    availableColors: [
      { name: 'Rustic Crazy Horse Brown', hex: '#5E3A1A' },
      { name: 'Midnight Charcoal', hex: '#212529' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1520639888713-7851133b1ed0?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1520639888713-7851133b1ed0?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Boots', 'Chelsea', 'Winter', 'Leather', 'Water Resistant'],
    featured: true,
    bestSeller: true,
    newArrival: false,
    isActive: true,
    rating: 4.9,
    reviewCount: 31,
    specifications: {
      upperMaterial: 'Heavyweight Waxy Pull-Up Cowhide',
      soleMaterial: 'Commando Lugged Slip-Resistant Rubber',
      insole: 'Dual-Layer Shock Absorbing PU Footbed',
      closure: 'Elastic Stretch Side Gores',
      weight: '560g',
      origin: 'Bangladesh',
    },
    createdAt: '2026-01-10T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-005',
    name: 'Aura Cloud Stride Women Running Sneaker',
    slug: 'aura-cloud-stride-women-running-sneaker',
    sku: 'STP-WMN-005',
    category: 'women',
    subcategory: 'Running Shoes',
    gender: 'women',
    brand: 'STEPORA LADY',
    description: 'Featherlight agility tailored specifically for the biomechanics of women runners. The Aura Cloud Stride features an anatomical narrow heel pocket, wide toe box freedom, and a marshmallow-soft EVA midsole that cradles your feet throughout jogging, gym workouts, or all-day city walks.',
    shortDescription: 'Ultra-cushioned pastel runner with female anatomical support.',
    price: 3690,
    salePrice: 2990,
    discountPercentage: 19,
    stockQuantity: 40,
    availableSizes: ['36', '37', '38', '39', '40', '41'],
    sizeStock: [
      { size: '36', stock: 6 },
      { size: '37', stock: 8 },
      { size: '38', stock: 12 },
      { size: '39', stock: 9 },
      { size: '40', stock: 4 },
      { size: '41', stock: 1 },
    ],
    availableColors: [
      { name: 'Blush Rose / Champagne', hex: '#F4ACB7' },
      { name: 'Lilac Mist', hex: '#D8B4E2' },
      { name: 'Cloud White / Silver', hex: '#F0F2F5' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1582588678413-dbf45f4823e9?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Women', 'Running', 'Lightweight', 'Pink', 'Cloud Cushion'],
    featured: true,
    bestSeller: true,
    newArrival: true,
    isActive: true,
    rating: 4.8,
    reviewCount: 54,
    specifications: {
      upperMaterial: 'FlyKnit Seamless Recycled Poly Mesh',
      soleMaterial: 'SuperFoam Cloud EVA Midsole with Rubber Pods',
      insole: 'Anatomic Memory Foam Cushioning',
      closure: 'Reflective Speed Laces',
      weight: '190g',
      origin: 'Bangladesh',
    },
    createdAt: '2026-02-12T10:00:00Z',
    updatedAt: '2026-03-04T12:00:00Z',
  },
  {
    id: 'prod-006',
    name: 'Riviera Hand-Sewn Suede Penny Loafer',
    slug: 'riviera-hand-sewn-suede-penny-loafer',
    sku: 'STP-CAS-006',
    category: 'casual',
    subcategory: 'Loafers',
    gender: 'men',
    brand: 'STEPORA ORIGINALS',
    description: 'Casual luxury at its effortless best. Hand-stitched apron toe using velvety Italian calf suede that molds like a glove around your foot. Unlined for breathable, glove-like flexibility, completed with a supple leather sole embedded with anti-skid rubber pads.',
    shortDescription: 'Unlined supple calf suede penny loafer for smart casual refinement.',
    price: 4590,
    salePrice: 3890,
    discountPercentage: 15,
    stockQuantity: 30,
    availableSizes: ['39', '40', '41', '42', '43', '44'],
    sizeStock: [
      { size: '39', stock: 4 },
      { size: '40', stock: 7 },
      { size: '41', stock: 8 },
      { size: '42', stock: 6 },
      { size: '43', stock: 3 },
      { size: '44', stock: 2 },
    ],
    availableColors: [
      { name: 'Warm Tobacco Suede', hex: '#A06D3B' },
      { name: 'Navy Sea Blue Suede', hex: '#1C3144' },
      { name: 'Charcoal Slate', hex: '#3E424B' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1533867617858-e7b97e060509?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1588361861040-ac9b1018f6d5?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Loafer', 'Suede', 'Casual', 'Penny Loafer', 'Summer'],
    featured: false,
    bestSeller: true,
    newArrival: false,
    isActive: true,
    rating: 4.7,
    reviewCount: 27,
    specifications: {
      upperMaterial: 'Water-Resistant Treated Calf Suede',
      soleMaterial: 'Leather Outsole with Embedded TPU Grip Pads',
      insole: 'Arch Support Leather Cushion',
      closure: 'Slip-on with Classic Penny Strap',
      weight: '310g',
      origin: 'Artisanal Studio Dhaka',
    },
    createdAt: '2026-01-25T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-007',
    name: 'Retro 85 Heritage Court High-Top',
    slug: 'retro-85-heritage-court-high-top',
    sku: 'STP-SNK-007',
    category: 'sneakers',
    subcategory: 'High Tops',
    gender: 'unisex',
    brand: 'STEPORA ORIGINALS',
    description: 'An iconic tribute to the golden era of basketball courts and street culture. Constructed with multi-toned tumbled leather panels, padded collar protection, perforations along the vamp, and an aged vintage midsole that catches every eye.',
    shortDescription: 'Vintage 80s throwback high-top silhouette in premium tumbled leather.',
    price: 4990,
    salePrice: 4250,
    discountPercentage: 15,
    stockQuantity: 24,
    availableSizes: ['38', '39', '40', '41', '42', '43', '44', '45'],
    sizeStock: [
      { size: '38', stock: 2 },
      { size: '39', stock: 3 },
      { size: '40', stock: 5 },
      { size: '41', stock: 5 },
      { size: '42', stock: 4 },
      { size: '43', stock: 3 },
      { size: '44', stock: 2 },
      { size: '45', stock: 0 },
    ],
    availableColors: [
      { name: 'Chicago Red / White / Black', hex: '#B22222' },
      { name: 'Royal Varsity Blue / White', hex: '#1D3557' },
      { name: 'Panda Monocrome', hex: '#000000' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1512374382149-233c42b6a83b?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['High Top', 'Retro', 'Basketball', 'Sneakers', 'Streetwear'],
    featured: true,
    bestSeller: false,
    newArrival: true,
    isActive: true,
    rating: 4.9,
    reviewCount: 38,
    specifications: {
      upperMaterial: 'Tumbled Leather & Suede Trim Overlays',
      soleMaterial: 'Herringbone Pattern Anti-Slip Gum Rubber',
      insole: 'High-Density Gel Heel Pad',
      closure: '8-Hole High Lace System',
      weight: '430g',
      origin: 'Bangladesh',
    },
    createdAt: '2026-02-18T10:00:00Z',
    updatedAt: '2026-03-02T12:00:00Z',
  },
  {
    id: 'prod-008',
    name: 'Sovereign Double Monk Strap Formal Shoe',
    slug: 'sovereign-double-monk-strap-formal-shoe',
    sku: 'STP-FRM-008',
    category: 'formal',
    subcategory: 'Monk Straps',
    gender: 'men',
    brand: 'STEPORA HERITAGE',
    description: 'Radiate authority with this sculpted double monk strap shoe. Crafted with hand-stained full grain crust leather, solid brass double buckles, and a chisel toe profile. Impeccably balances classic formal prestige with sartorial swagger.',
    shortDescription: 'Sculpted double buckle monk strap with antique brass hardware.',
    price: 6990,
    salePrice: 5990,
    discountPercentage: 14,
    stockQuantity: 18,
    availableSizes: ['40', '41', '42', '43', '44'],
    sizeStock: [
      { size: '40', stock: 3 },
      { size: '41', stock: 5 },
      { size: '42', stock: 5 },
      { size: '43', stock: 3 },
      { size: '44', stock: 2 },
    ],
    availableColors: [
      { name: 'Dark Burgundy Mahogany', hex: '#581845' },
      { name: 'Raven Black', hex: '#111111' },
      { name: 'Rich Chestnut', hex: '#783F04' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1531310197839-ccf54634509e?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1531310197839-ccf54634509e?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Formal', 'Monk Strap', 'Double Monk', 'Business', 'Premium'],
    featured: false,
    bestSeller: false,
    newArrival: true,
    isActive: true,
    rating: 4.8,
    reviewCount: 15,
    specifications: {
      upperMaterial: 'Full-Grain Crust Calf Leather',
      soleMaterial: 'Hand-Welted Channeled Leather Sole',
      insole: 'Cork Layered Memory Footbed',
      closure: 'Dual Adjustable Brass Buckles with Concealed Elastic',
      weight: '460g',
      origin: 'Artisanal Studio Dhaka',
    },
    createdAt: '2026-02-05T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-009',
    name: 'Zenith Ergonomic Leather Slide',
    slug: 'zenith-ergonomic-leather-slide',
    sku: 'STP-SAN-009',
    category: 'sandals',
    subcategory: 'Slides & Slippers',
    gender: 'unisex',
    brand: 'STEPORA COMFORT',
    description: 'Supreme everyday ease. Molded orthopedic footbed lined in soft genuine suede that matches your foot arch. Thick oiled nubuck crossover straps allow breathability while providing secure grip during home lounging, Friday prayers, or holiday beach strolls.',
    shortDescription: 'Orthopedic molded cork footbed slides with oiled nubuck straps.',
    price: 2190,
    salePrice: 1790,
    discountPercentage: 18,
    stockQuantity: 50,
    availableSizes: ['38', '39', '40', '41', '42', '43', '44', '45'],
    sizeStock: [
      { size: '38', stock: 6 },
      { size: '39', stock: 8 },
      { size: '40', stock: 10 },
      { size: '41', stock: 9 },
      { size: '42', stock: 7 },
      { size: '43', stock: 5 },
      { size: '44', stock: 3 },
      { size: '45', stock: 2 },
    ],
    availableColors: [
      { name: 'Oiled Saddle Brown', hex: '#6F4E37' },
      { name: 'Pitch Matte Black', hex: '#222222' },
      { name: 'Olive Drab Nubuck', hex: '#556B2F' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1603808033192-082d6919d3e1?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1603808033192-082d6919d3e1?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Sandals', 'Slippers', 'Slides', 'Comfort', 'Orthopedic'],
    featured: false,
    bestSeller: true,
    newArrival: false,
    isActive: true,
    rating: 4.8,
    reviewCount: 47,
    specifications: {
      upperMaterial: 'Oil-Waxed Nubuck Leather',
      soleMaterial: 'EVA Shock Dampening Outsole',
      insole: 'Natural Cork & Latex Anatomical Bed with Suede Lining',
      closure: 'Slip-On Crossover',
      weight: '210g',
      origin: 'Bangladesh',
    },
    createdAt: '2026-01-08T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-010',
    name: 'Elegance Strappy Block Heel Sandal',
    slug: 'elegance-strappy-block-heel-sandal',
    sku: 'STP-WMN-010',
    category: 'women',
    subcategory: 'Heels & Sandals',
    gender: 'women',
    brand: 'STEPORA LADY',
    description: 'Chic, steady and poised for weddings, evening dinners or festive Eid parties. Features minimalist tubular leather straps that frame the foot delicately, anchored on a sturdy 2.5-inch wrapped block heel with cushioned ball-of-foot padding so you can dance all night without strain.',
    shortDescription: 'Minimalist tubular leather ankle strap sandal on 2.5-inch block heel.',
    price: 3290,
    salePrice: 2690,
    discountPercentage: 18,
    stockQuantity: 26,
    availableSizes: ['36', '37', '38', '39', '40'],
    sizeStock: [
      { size: '36', stock: 4 },
      { size: '37', stock: 7 },
      { size: '38', stock: 8 },
      { size: '39', stock: 5 },
      { size: '40', stock: 2 },
    ],
    availableColors: [
      { name: 'Metallic Soft Gold', hex: '#D4AF37' },
      { name: 'Nude Beige Leather', hex: '#E3C1B4' },
      { name: 'Classic Noir', hex: '#1A1A1A' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1562273138-f46be4ebdf33?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Women', 'Heels', 'Sandals', 'Party Wear', 'Block Heel'],
    featured: false,
    bestSeller: false,
    newArrival: true,
    isActive: true,
    rating: 4.7,
    reviewCount: 22,
    specifications: {
      upperMaterial: 'Soft Vegan Metallic & Napa Leather',
      soleMaterial: 'Anti-Slip Resin Rubber',
      insole: 'High Density Latex Foam Footbed',
      closure: 'Buckled Ankle Strap with Hidden Elastic',
      weight: '260g',
      origin: 'Bangladesh',
    },
    createdAt: '2026-02-14T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-011',
    name: 'Outlander Waterproof Hiking Trail Shoe',
    slug: 'outlander-waterproof-hiking-trail-shoe',
    sku: 'STP-SPT-011',
    category: 'sports',
    subcategory: 'Trail & Hiking',
    gender: 'men',
    brand: 'STEPORA PRO',
    description: 'Engineered to conquer the hilly trails of Bandarban or wet rainy monsoons. Equipped with our proprietary HydroDry breathable membrane, reinforced rubber toe cap protector, rock plate underfoot, and multi-directional Vibram-style rubber lugs that grip wet muddy slopes.',
    shortDescription: 'All-weather waterproof trail shoe with protective toe bumper and deep mud lugs.',
    price: 5490,
    salePrice: 4790,
    discountPercentage: 13,
    stockQuantity: 32,
    availableSizes: ['40', '41', '42', '43', '44', '45', '46'],
    sizeStock: [
      { size: '40', stock: 4 },
      { size: '41', stock: 6 },
      { size: '42', stock: 8 },
      { size: '43', stock: 7 },
      { size: '44', stock: 4 },
      { size: '45', stock: 2 },
      { size: '46', stock: 1 },
    ],
    availableColors: [
      { name: 'Forest Green / Clay Orange', hex: '#2F4F4F' },
      { name: 'Steel Gray / Cobalt', hex: '#4A5568' },
      { name: 'Desert Sand Khaki', hex: '#C2B280' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1575537302964-96cd47c06b1b?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1575537302964-96cd47c06b1b?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Hiking', 'Trail', 'Waterproof', 'Sports', 'Outdoor'],
    featured: false,
    bestSeller: false,
    newArrival: false,
    isActive: true,
    rating: 4.9,
    reviewCount: 29,
    specifications: {
      upperMaterial: 'Ripstop Cordura with HydroDry Membrane',
      soleMaterial: 'Deep-Cleated Multi-Directional High Traction Rubber',
      insole: 'Dual-Density Orthopedic Insole',
      closure: 'Gusseted Tongue & Speed Ghillie Lacing',
      weight: '390g',
      origin: 'Bangladesh',
    },
    createdAt: '2026-01-18T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-012',
    name: 'Junior Sprint Dynamo Kids Sneaker',
    slug: 'junior-sprint-dynamo-kids-sneaker',
    sku: 'STP-KID-012',
    category: 'kids',
    subcategory: 'Kids Sneakers',
    gender: 'kids',
    brand: 'STEPORA KIDS',
    description: 'Designed for energetic school playgrounds, sports days and weekend play. Easy-fasten dual velcro straps allow kids to put them on by themselves in seconds. Reinforced toe bumper prevents scuffs, and high-bounce EVA foam keeps young feet joyful and active.',
    shortDescription: 'Dual velcro strap lightweight kids sneaker with scuff-resistant toe bumper.',
    price: 2190,
    salePrice: 1750,
    discountPercentage: 20,
    stockQuantity: 44,
    availableSizes: ['36', '37', '38'],
    sizeStock: [
      { size: '36', stock: 14 },
      { size: '37', stock: 16 },
      { size: '38', stock: 14 },
    ],
    availableColors: [
      { name: 'Electric Royal & Neon Lime', hex: '#3B82F6' },
      { name: 'Vibrant Berry Pink', hex: '#EC4899' },
      { name: 'Turbo Solar Yellow', hex: '#FACC15' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1514989940723-e8e51635b782?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1514989940723-e8e51635b782?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Kids', 'Velcro', 'Lightweight', 'School', 'Playground'],
    featured: false,
    bestSeller: true,
    newArrival: false,
    isActive: true,
    rating: 4.8,
    reviewCount: 35,
    specifications: {
      upperMaterial: 'Breathable Honeycomb Mesh & Synthetic Overlays',
      soleMaterial: 'Featherlight Non-Marking Phylon EVA',
      insole: 'Washable Anti-Bacterial Foam Insole',
      closure: 'Dual Hook-and-Loop Velcro Straps',
      weight: '145g',
      origin: 'Bangladesh',
    },
    createdAt: '2026-01-22T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-013',
    name: 'Heritage Derby Wingtip Brogue',
    slug: 'heritage-derby-wingtip-brogue',
    sku: 'STP-FRM-013',
    category: 'formal',
    subcategory: 'Brogues',
    gender: 'men',
    brand: 'STEPORA HERITAGE',
    description: 'Impeccable perforation medallion details and serrated wingtip edges define this British-inspired Derby brogue. Versatile open-lacing architecture accommodates high insteps with ease while maintaining uncompromising prestige with navy suits or smart chinos.',
    shortDescription: 'Classic medallion wingtip brogue in hand-finished vegetable-tanned leather.',
    price: 6850,
    salePrice: 5850,
    discountPercentage: 15,
    stockQuantity: 20,
    availableSizes: ['40', '41', '42', '43', '44'],
    sizeStock: [
      { size: '40', stock: 4 },
      { size: '41', stock: 5 },
      { size: '42', stock: 6 },
      { size: '43', stock: 3 },
      { size: '44', stock: 2 },
    ],
    availableColors: [
      { name: 'Burnished Tan Cognac', hex: '#B87333' },
      { name: 'Deep Dark Chocolate', hex: '#3B2F2F' },
      { name: 'Midnight Onyx', hex: '#000000' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Formal', 'Brogue', 'Derby', 'Wingtip', 'Heritage'],
    featured: false,
    bestSeller: false,
    newArrival: false,
    isActive: true,
    rating: 4.7,
    reviewCount: 16,
    specifications: {
      upperMaterial: 'Vegetable-Tanned Full Grain Leather',
      soleMaterial: 'Stitched Leather Outsole with Non-Slip Rubber Inset',
      insole: 'Cushioned Leather Insole',
      closure: 'Open Lace Derby',
      weight: '450g',
      origin: 'Artisanal Studio Dhaka',
    },
    createdAt: '2026-01-28T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-014',
    name: 'Velocity Chunky Street Sneaker',
    slug: 'velocity-chunky-street-sneaker',
    sku: 'STP-SNK-014',
    category: 'sneakers',
    subcategory: 'Chunky Sneakers',
    gender: 'unisex',
    brand: 'STEPORA ORIGINALS',
    description: 'Statement fashion with sculpted, architectural layers. Bold oversized silhouettes inspired by high-fashion runway chunky trainers, balanced by an ultra-light EVA midsole that feels like walking on marshmallows despite its bold exterior.',
    shortDescription: 'Bold architectural platform dad shoe with multi-layered textures.',
    price: 4650,
    salePrice: 3890,
    discountPercentage: 16,
    stockQuantity: 28,
    availableSizes: ['38', '39', '40', '41', '42', '43', '44'],
    sizeStock: [
      { size: '38', stock: 3 },
      { size: '39', stock: 4 },
      { size: '40', stock: 6 },
      { size: '41', stock: 6 },
      { size: '42', stock: 5 },
      { size: '43', stock: 3 },
      { size: '44', stock: 1 },
    ],
    availableColors: [
      { name: 'Tri-Tone Cloud Grey / White / Teal', hex: '#64748B' },
      { name: 'Cyberpunk Black & Neon', hex: '#1E293B' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1512374382149-233c42b6a83b?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1512374382149-233c42b6a83b?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Chunky Sneaker', 'Streetwear', 'Fashion', 'Platform', 'Unisex'],
    featured: true,
    bestSeller: false,
    newArrival: true,
    isActive: true,
    rating: 4.8,
    reviewCount: 23,
    specifications: {
      upperMaterial: 'Split Suede, TPU Welds & Ballistic Mesh',
      soleMaterial: 'Sculpted Lightweight Phylon & Dual-Density Rubber',
      insole: 'Hi-Poly Ergonomic Bounce Insole',
      closure: 'Reflective Rope Laces',
      weight: '380g',
      origin: 'Bangladesh',
    },
    createdAt: '2026-02-15T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-015',
    name: 'Breeze Cushion Dual-Strap Leather Sandal',
    slug: 'breeze-cushion-dual-strap-leather-sandal',
    sku: 'STP-SAN-015',
    category: 'sandals',
    subcategory: 'Casual Sandals',
    gender: 'men',
    brand: 'STEPORA COMFORT',
    description: 'Engineered specifically for warm tropical comfort. Two wide adjustable buckle straps crafted from thick pull-up leather, anchored onto a shock-absorbing cork footbed that molds to your unique foot contour with every wear.',
    shortDescription: 'Adjustable dual-buckle genuine leather footbed comfort sandal.',
    price: 2390,
    salePrice: 1990,
    discountPercentage: 17,
    stockQuantity: 42,
    availableSizes: ['39', '40', '41', '42', '43', '44', '45'],
    sizeStock: [
      { size: '39', stock: 5 },
      { size: '40', stock: 8 },
      { size: '41', stock: 9 },
      { size: '42', stock: 8 },
      { size: '43', stock: 6 },
      { size: '44', stock: 4 },
      { size: '45', stock: 2 },
    ],
    availableColors: [
      { name: 'Rich Tobacco Mocca', hex: '#4B3621' },
      { name: 'Onyx Black', hex: '#1C1C1C' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1603808033192-082d6919d3e1?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1603808033192-082d6919d3e1?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Sandals', 'Summer', 'Leather', 'Cork Footbed', 'Everyday'],
    featured: false,
    bestSeller: true,
    newArrival: false,
    isActive: true,
    rating: 4.8,
    reviewCount: 39,
    specifications: {
      upperMaterial: 'Genuine Cowhide Pull-Up Leather',
      soleMaterial: 'EVA Grooved Wave Sole',
      insole: 'Suede-Lined Contour Cork Footbed',
      closure: 'Dual Antique Metal Buckles',
      weight: '230g',
      origin: 'Bangladesh',
    },
    createdAt: '2026-01-12T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-016',
    name: 'Pulse Pro Carbon Turf Sports Trainer',
    slug: 'pulse-pro-carbon-turf-sports-trainer',
    sku: 'STP-SPT-016',
    category: 'sports',
    subcategory: 'Training Shoes',
    gender: 'men',
    brand: 'STEPORA PRO',
    description: 'Engineered for gym workouts, HIIT, cross-training and indoor turf cricket. A rigid carbon-reinforced midfoot shank prevents torsion while lateral sidewall wraps support explosive lateral movements and heavy lifting stability.',
    shortDescription: 'Cross-training workout shoe with carbon-reinforced midfoot torsion control.',
    price: 4350,
    salePrice: 3690,
    discountPercentage: 15,
    stockQuantity: 34,
    availableSizes: ['40', '41', '42', '43', '44', '45'],
    sizeStock: [
      { size: '40', stock: 5 },
      { size: '41', stock: 7 },
      { size: '42', stock: 9 },
      { size: '43', stock: 6 },
      { size: '44', stock: 4 },
      { size: '45', stock: 3 },
    ],
    availableColors: [
      { name: 'Jet Black / Hyper Lemon', hex: '#CCFF00' },
      { name: 'Steel Stealth Gray', hex: '#374151' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Training', 'Gym', 'Crossfit', 'Sports', 'Performance'],
    featured: false,
    bestSeller: false,
    newArrival: true,
    isActive: true,
    rating: 4.8,
    reviewCount: 18,
    specifications: {
      upperMaterial: 'Abrasion-Resistant High-Tenacity TPU Mesh',
      soleMaterial: 'Non-Marking Flat Stable Gym Rubber',
      insole: 'Dual-Density High Rebound Foam',
      closure: 'Integrated Dynamic Webbing Lace',
      weight: '280g',
      origin: 'Bangladesh',
    },
    createdAt: '2026-02-08T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-017',
    name: 'Sleek Starlight Slip-On Knit Shoe',
    slug: 'sleek-starlight-slip-on-knit-shoe',
    sku: 'STP-WMN-017',
    category: 'women',
    subcategory: 'Casual Slip-Ons',
    gender: 'women',
    brand: 'STEPORA LADY',
    description: 'Slip on, walk out, feel weightless. 3D circular knit upper hugs the contours of your feet like a second skin, eliminating hot spots and blisters. Flexible grooved sole bends effortlessly with every step, making it your go-to companion for air travel and shopping days.',
    shortDescription: 'Elastic stretch knit sock-fit slip-on sneaker for lightweight travel.',
    price: 2790,
    salePrice: 2290,
    discountPercentage: 18,
    stockQuantity: 38,
    availableSizes: ['36', '37', '38', '39', '40', '41'],
    sizeStock: [
      { size: '36', stock: 5 },
      { size: '37', stock: 8 },
      { size: '38', stock: 10 },
      { size: '39', stock: 8 },
      { size: '40', stock: 5 },
      { size: '41', stock: 2 },
    ],
    availableColors: [
      { name: 'Oatmeal Heather / Pearl', hex: '#E5DCC5' },
      { name: 'Midnight Charcoal Heather', hex: '#374151' },
      { name: 'Lavender Pastel', hex: '#BDB2FF' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1582588678413-dbf45f4823e9?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1582588678413-dbf45f4823e9?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Women', 'Slip On', 'Knit', 'Comfort', 'Lightweight'],
    featured: false,
    bestSeller: true,
    newArrival: false,
    isActive: true,
    rating: 4.9,
    reviewCount: 31,
    specifications: {
      upperMaterial: '4-Way Stretch Elastic Knit Fabric',
      soleMaterial: 'Ultra-Lightweight Molded Phylon',
      insole: 'Pillow-Soft Memory Foam with Arch Pillow',
      closure: 'Slip-On Sock Fit with Heel Pull Loop',
      weight: '160g',
      origin: 'Bangladesh',
    },
    createdAt: '2026-01-14T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-018',
    name: 'Little Champion Active Flex Kids Shoe',
    slug: 'little-champion-active-flex-kids-shoe',
    sku: 'STP-KID-018',
    category: 'kids',
    subcategory: 'Kids Sports',
    gender: 'kids',
    brand: 'STEPORA KIDS',
    description: 'Vibrant, energetic and kid-tested tough. Features elastic faux laces with single wide power strap for easy on/off. Cushioned midsole protects little joints while running on concrete or school tracks, paired with high-durability rubber heel pods.',
    shortDescription: 'Flexible lightweight kids running shoe with easy power strap.',
    price: 1990,
    salePrice: 1590,
    discountPercentage: 20,
    stockQuantity: 36,
    availableSizes: ['36', '37', '38'],
    sizeStock: [
      { size: '36', stock: 12 },
      { size: '37', stock: 14 },
      { size: '38', stock: 10 },
    ],
    availableColors: [
      { name: 'Sonic Blue & Flame Red', hex: '#2563EB' },
      { name: 'Cool Mint & Aqua', hex: '#10B981' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1514989940723-e8e51635b782?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1514989940723-e8e51635b782?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Kids', 'Active', 'Easy On', 'School', 'Sport'],
    featured: false,
    bestSeller: false,
    newArrival: false,
    isActive: true,
    rating: 4.8,
    reviewCount: 21,
    specifications: {
      upperMaterial: 'Breathable Knit & Reinforced Synthetic Leather',
      soleMaterial: 'Flex-Groove EVA Outsole',
      insole: 'Molded Kid Foam Cushion',
      closure: 'Elastic Lace + Single Hook-and-Loop Power Strap',
      weight: '135g',
      origin: 'Bangladesh',
    },
    createdAt: '2026-01-20T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-019',
    name: 'Commander Tactical Waterproof Combat Boot',
    slug: 'commander-tactical-waterproof-combat-boot',
    sku: 'STP-BOT-019',
    category: 'boots',
    subcategory: 'Combat Boots',
    gender: 'men',
    brand: 'STEPORA HERITAGE',
    description: 'Uncompromising durability with military-inspired heritage styling. Built from full-grain pull-up leather and ballistic 1000D nylon collar. YKK heavy-duty side zipper lets you slip in and out within seconds without unlacing the 9-eyelet speed hooks.',
    shortDescription: 'Full-grain leather tactical combat boot with quick YKK side zipper.',
    price: 6990,
    salePrice: 5990,
    discountPercentage: 14,
    stockQuantity: 22,
    availableSizes: ['40', '41', '42', '43', '44', '45'],
    sizeStock: [
      { size: '40', stock: 3 },
      { size: '41', stock: 5 },
      { size: '42', stock: 6 },
      { size: '43', stock: 4 },
      { size: '44', stock: 3 },
      { size: '45', stock: 1 },
    ],
    availableColors: [
      { name: 'Tactical Matte Black', hex: '#111827' },
      { name: 'Combat Desert Tan', hex: '#D2B48C' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1520639888713-7851133b1ed0?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Boots', 'Combat', 'Tactical', 'Leather', 'Side Zip'],
    featured: false,
    bestSeller: false,
    newArrival: true,
    isActive: true,
    rating: 4.9,
    reviewCount: 17,
    specifications: {
      upperMaterial: 'Heavy Full-Grain Bovine Leather & Ballistic Nylon',
      soleMaterial: 'Oil and Acid Resistant Heavy Tread Lug Sole',
      insole: 'Dual-Density Shock Gel Insole',
      closure: 'Speed Hooks + YKK Heavy-Duty Side Zipper',
      weight: '620g',
      origin: 'Bangladesh',
    },
    createdAt: '2026-02-10T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-020',
    name: 'Coastline Handcrafted Canvas Espadrille',
    slug: 'coastline-handcrafted-canvas-espadrille',
    sku: 'STP-CAS-020',
    category: 'casual',
    subcategory: 'Espadrilles',
    gender: 'unisex',
    brand: 'STEPORA ORIGINALS',
    description: 'The definitive summer weekend shoe. Organic woven cotton canvas upper breathes effortlessly on humid days, stitched onto a natural jute braided rope midsole with vulcanized thin rubber bottom that protects the jute from puddles and moisture.',
    shortDescription: 'Breathable organic canvas slip-on with authentic woven natural jute rope.',
    price: 1990,
    salePrice: 1590,
    discountPercentage: 20,
    stockQuantity: 35,
    availableSizes: ['38', '39', '40', '41', '42', '43', '44'],
    sizeStock: [
      { size: '38', stock: 4 },
      { size: '39', stock: 6 },
      { size: '40', stock: 7 },
      { size: '41', stock: 8 },
      { size: '42', stock: 5 },
      { size: '43', stock: 3 },
      { size: '44', stock: 2 },
    ],
    availableColors: [
      { name: 'Nautical Navy Blue', hex: '#1E3A8A' },
      { name: 'Sand Natural Ecru', hex: '#F5F5DC' },
      { name: 'Olive Sage', hex: '#6B8E23' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1588361861040-ac9b1018f6d5?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1588361861040-ac9b1018f6d5?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Espadrille', 'Canvas', 'Summer', 'Jute', 'Casual'],
    featured: false,
    bestSeller: false,
    newArrival: false,
    isActive: true,
    rating: 4.7,
    reviewCount: 20,
    specifications: {
      upperMaterial: '100% Organic Breathable Heavy Cotton Canvas',
      soleMaterial: 'Braided Natural Eco Jute with Vulcanized Protective Rubber Base',
      insole: 'Jute Footbed with Padded Leather Heel Patch',
      closure: 'Elastic Inset Slip-On',
      weight: '210g',
      origin: 'Bangladesh',
    },
    createdAt: '2026-01-26T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-021',
    name: 'Vortex Elite Track Carbon Spike Runner',
    slug: 'vortex-elite-track-carbon-spike-runner',
    sku: 'STP-SPT-021',
    category: 'sports',
    subcategory: 'Running Shoes',
    gender: 'unisex',
    brand: 'STEPORA PRO',
    description: 'Precision sprint weapon calibrated for maximum speed. Equipped with a rigid full-length carbon composite plate that acts as a catapult during sprint launches. Seamless aerodynamic monomesh upper reduces drag to the absolute minimum.',
    shortDescription: 'Full-length carbon composite propulsion plate sprint spike shoe.',
    price: 6890,
    salePrice: 5990,
    discountPercentage: 13,
    stockQuantity: 16,
    availableSizes: ['40', '41', '42', '43', '44'],
    sizeStock: [
      { size: '40', stock: 3 },
      { size: '41', stock: 4 },
      { size: '42', stock: 5 },
      { size: '43', stock: 3 },
      { size: '44', stock: 1 },
    ],
    availableColors: [
      { name: 'Solar Aurora Iridescent', hex: '#6366F1' },
      { name: 'Velocity Cyan', hex: '#06B6D4' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1587563871167-1ee9c731aefb?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1587563871167-1ee9c731aefb?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Track', 'Carbon Plate', 'Sprint', 'Athletic', 'Speed'],
    featured: true,
    bestSeller: false,
    newArrival: true,
    isActive: true,
    rating: 5.0,
    reviewCount: 12,
    specifications: {
      upperMaterial: 'AtomWeave Ultra-Fine Monofilament Mesh',
      soleMaterial: 'Carbon Composite Propulsion Plate with Ceramic Pins',
      insole: 'Bonded Feather Insole',
      closure: 'Notched Speed Laces',
      weight: '165g',
      origin: 'Pro Athletic Lab',
    },
    createdAt: '2026-02-22T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
  {
    id: 'prod-022',
    name: 'Aero Street Low-Top Leather Sneaker',
    slug: 'aero-street-low-top-leather-sneaker',
    sku: 'STP-SNK-022',
    category: 'sneakers',
    subcategory: 'Street Sneakers',
    gender: 'men',
    brand: 'STEPORA ORIGINALS',
    description: 'Everyday street royalty. Features premium milled cowhide leather with perforated side panels for breathability, custom molded heel stabilizer clip, and durable side-stitched rubber cupsole that stays clean and resists scuffs.',
    shortDescription: 'Everyday street sneaker in supple milled leather with cupsole stitching.',
    price: 3990,
    salePrice: 3390,
    discountPercentage: 15,
    stockQuantity: 32,
    availableSizes: ['39', '40', '41', '42', '43', '44', '45'],
    sizeStock: [
      { size: '39', stock: 4 },
      { size: '40', stock: 6 },
      { size: '41', stock: 8 },
      { size: '42', stock: 7 },
      { size: '43', stock: 4 },
      { size: '44', stock: 2 },
      { size: '45', stock: 1 },
    ],
    availableColors: [
      { name: 'Arctic White / Black Accent', hex: '#FFFFFF' },
      { name: 'Charcoal Shadow', hex: '#334155' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?auto=format&fit=crop&w=800&q=80',
    ],
    tags: ['Sneakers', 'Streetwear', 'White Sneaker', 'Leather'],
    featured: false,
    bestSeller: true,
    newArrival: false,
    isActive: true,
    rating: 4.8,
    reviewCount: 33,
    specifications: {
      upperMaterial: 'Milled Full Grain Cow Leather',
      soleMaterial: 'Full Perimeter Stitched Rubber Cupsole',
      insole: 'High-Resilience Polyurethane Footbed',
      closure: 'Waxed Flat Cotton Laces',
      weight: '330g',
      origin: 'Bangladesh',
    },
    createdAt: '2026-01-16T10:00:00Z',
    updatedAt: '2026-03-01T12:00:00Z',
  },
];

const DEFAULT_COUPONS: Coupon[] = [
  {
    id: 'coup-001',
    code: 'WELCOME10',
    discountType: 'percentage',
    discountValue: 10,
    minOrderAmount: 1500,
    maxDiscountAmount: 500,
    startDate: '2026-01-01',
    expiryDate: '2026-12-31',
    usageLimit: 1000,
    usageCount: 142,
    isActive: true,
  },
  {
    id: 'coup-002',
    code: 'SAVE20',
    discountType: 'percentage',
    discountValue: 20,
    minOrderAmount: 3000,
    maxDiscountAmount: 1000,
    startDate: '2026-01-01',
    expiryDate: '2026-12-31',
    usageLimit: 500,
    usageCount: 88,
    isActive: true,
  },
  {
    id: 'coup-003',
    code: 'SHOE50',
    discountType: 'fixed',
    discountValue: 500,
    minOrderAmount: 4000,
    maxDiscountAmount: 500,
    startDate: '2026-01-01',
    expiryDate: '2026-12-31',
    usageLimit: 200,
    usageCount: 65,
    isActive: true,
  },
  {
    id: 'coup-004',
    code: 'STEPORA15',
    discountType: 'percentage',
    discountValue: 15,
    minOrderAmount: 2500,
    maxDiscountAmount: 800,
    startDate: '2026-01-01',
    expiryDate: '2026-12-31',
    usageLimit: 300,
    usageCount: 42,
    isActive: true,
  },
];

const DEFAULT_REVIEWS: Review[] = [
  {
    id: 'rev-001',
    productId: 'prod-001',
    userName: 'Tanvir Hossain',
    userEmail: 'tanvir.runner@gmail.com',
    rating: 5,
    title: 'Incredible cushioning for morning road runs!',
    comment: 'The nitrogen foam feels remarkably soft yet springy. I ran 10km along Hatirjheel in Dhaka, zero knee discomfort. Sizing is spot on EU 42. Highly recommend!',
    isVerifiedPurchase: true,
    status: 'approved',
    createdAt: '2026-02-10T14:30:00Z',
  },
  {
    id: 'rev-002',
    productId: 'prod-002',
    userName: 'Sadia Rahman',
    userEmail: 'sadia.r@yahoo.com',
    rating: 5,
    title: 'Best white sneakers I have ever owned in Bangladesh',
    comment: 'The Napa leather quality is so buttery smooth. Wore them for 8 hours at an office exhibition and felt zero fatigue. The packaging and dust bag also feel very luxury.',
    isVerifiedPurchase: true,
    status: 'approved',
    createdAt: '2026-02-18T09:15:00Z',
  },
  {
    id: 'rev-003',
    productId: 'prod-003',
    userName: 'Mahmudul Hasan',
    userEmail: 'mahmud.csuite@gmail.com',
    rating: 5,
    title: 'Pure craftsmanship. Worth every single Taka.',
    comment: 'I usually buy international brands when traveling, but this homegrown Goodyear welt Oxford matches European luxury benchcraft. The burnish finish is magnificent.',
    isVerifiedPurchase: true,
    status: 'approved',
    createdAt: '2026-02-25T16:40:00Z',
  },
];

const DEFAULT_ORDERS: Order[] = [
  {
    id: 'ord-1001',
    orderNumber: 'ORD-2026-000101',
    customerId: 'usr-demo-001',
    customerName: 'Kazi Farhan Ahmed',
    customerEmail: 'farhan.ahmed@example.com',
    customerPhone: '01711223344',
    items: [
      {
        productId: 'prod-001',
        productName: 'Apex Glide Nitro Running Shoes',
        sku: 'STP-RUN-001',
        image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80',
        price: 4299,
        quantity: 1,
        selectedSize: '42',
        selectedColor: { name: 'Volt Black / Crimson', hex: '#E63946' },
        itemTotal: 4299,
      },
    ],
    subtotal: 4299,
    discount: 429.9,
    couponCode: 'WELCOME10',
    shippingFee: 0,
    shippingRegion: 'inside_dhaka',
    total: 3869.1,
    paymentMethod: 'bkash',
    paymentStatus: 'Paid',
    transactionId: 'BKASH_TRX_9928172',
    orderStatus: 'Delivered',
    shippingAddress: {
      fullName: 'Kazi Farhan Ahmed',
      phoneNumber: '01711223344',
      email: 'farhan.ahmed@example.com',
      division: 'Dhaka',
      district: 'Dhaka',
      area: 'Gulshan 2',
      fullAddress: 'Flat 4B, Road 68, Gulshan 2, Dhaka-1212',
      postalCode: '1212',
    },
    timeline: [
      { status: 'Pending', title: 'Order Placed', description: 'Customer confirmed order with bKash', timestamp: '2026-02-20T10:00:00Z', isCompleted: true },
      { status: 'Confirmed', title: 'Payment Verified', description: 'bKash Transaction TRX_9928172 verified', timestamp: '2026-02-20T10:05:00Z', isCompleted: true },
      { status: 'Processing', title: 'Dispatched to Warehouse', description: 'Items verified & wrapped in dust bags', timestamp: '2026-02-20T14:00:00Z', isCompleted: true },
      { status: 'Shipped', title: 'Handed to Courier', description: 'Courier Partner: Pathao Express Courier', timestamp: '2026-02-21T09:30:00Z', isCompleted: true },
      { status: 'Delivered', title: 'Delivered Successfully', description: 'Package handed over to recipient', timestamp: '2026-02-22T13:45:00Z', isCompleted: true },
    ],
    createdAt: '2026-02-20T10:00:00Z',
    updatedAt: '2026-02-22T13:45:00Z',
  },
  {
    id: 'ord-1002',
    orderNumber: 'ORD-2026-000102',
    customerId: 'usr-demo-002',
    customerName: 'Nasrin Sultana',
    customerEmail: 'nasrin.sultana@example.com',
    customerPhone: '01819876543',
    items: [
      {
        productId: 'prod-002',
        productName: 'Urban Velocity Minimalist White Sneaker',
        sku: 'STP-SNK-002',
        image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=800&q=80',
        price: 3250,
        quantity: 1,
        selectedSize: '38',
        selectedColor: { name: 'Crisp Cloud White', hex: '#F8F9FA' },
        itemTotal: 3250,
      },
    ],
    subtotal: 3250,
    discount: 0,
    shippingFee: 80,
    shippingRegion: 'inside_dhaka',
    total: 3330,
    paymentMethod: 'cod',
    paymentStatus: 'Pending',
    orderStatus: 'Out for Delivery',
    shippingAddress: {
      fullName: 'Nasrin Sultana',
      phoneNumber: '01819876543',
      email: 'nasrin.sultana@example.com',
      division: 'Dhaka',
      district: 'Dhaka',
      area: 'Dhanmondi',
      fullAddress: 'House 14, Road 27 (Old), Dhanmondi, Dhaka',
      postalCode: '1209',
    },
    timeline: [
      { status: 'Pending', title: 'Order Placed', description: 'Cash on delivery requested', timestamp: '2026-03-01T09:00:00Z', isCompleted: true },
      { status: 'Confirmed', title: 'Order Confirmed', description: 'Customer confirmed via automated call', timestamp: '2026-03-01T09:30:00Z', isCompleted: true },
      { status: 'Processing', title: 'Packed & Quality Checked', description: 'Box packaged securely with invoice', timestamp: '2026-03-01T15:00:00Z', isCompleted: true },
      { status: 'Out for Delivery', title: 'Rider on the Way', description: 'Rider: Delivery Hero Dhaka hub', timestamp: '2026-03-02T08:30:00Z', isCompleted: true },
    ],
    createdAt: '2026-03-01T09:00:00Z',
    updatedAt: '2026-03-02T08:30:00Z',
  },
];

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.loadData();
  }

  private loadData(): DatabaseSchema {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const fileContent = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(fileContent);
        // Ensure default admin exists
        const adminUsername = (process.env.ADMIN_USERNAME || 'RAHULADMIN').trim();
        const adminPassword = (process.env.ADMIN_PASSWORD || '123456').trim();

        let hasAdmin = parsed.users && parsed.users.some((u: any) => u.role === 'admin' && (u.email === adminUsername || u.fullName === adminUsername));
        if (!hasAdmin) {
          parsed.users = parsed.users || [];
          parsed.users.push({
            id: 'usr-admin-01',
            fullName: adminUsername,
            email: `${adminUsername.toLowerCase()}@stepora.admin`,
            phoneNumber: '+8801700000000',
            role: 'admin',
            isActive: true,
            passwordHash: hashPassword(adminPassword),
            createdAt: new Date().toISOString(),
          });
          this.saveDataDirect(parsed);
        }
        return parsed;
      }
    } catch (err) {
      console.error('Error loading database, re-seeding default data:', err);
    }

    const adminUsername = (process.env.ADMIN_USERNAME || 'RAHULADMIN').trim();
    const adminPassword = (process.env.ADMIN_PASSWORD || '123456').trim();

    const seeded: DatabaseSchema = {
      products: DEFAULT_PRODUCTS,
      categories: DEFAULT_CATEGORIES,
      orders: DEFAULT_ORDERS,
      coupons: DEFAULT_COUPONS,
      reviews: DEFAULT_REVIEWS,
      settings: DEFAULT_SETTINGS,
      users: [
        {
          id: 'usr-admin-01',
          fullName: adminUsername,
          email: `${adminUsername.toLowerCase()}@stepora.admin`,
          phoneNumber: '+8801700000000',
          role: 'admin',
          isActive: true,
          passwordHash: hashPassword(adminPassword),
          createdAt: new Date().toISOString(),
        },
        {
          id: 'usr-demo-001',
          fullName: 'Kazi Farhan Ahmed',
          email: 'farhan.ahmed@example.com',
          phoneNumber: '01711223344',
          role: 'customer',
          isActive: true,
          passwordHash: hashPassword('customer123'),
          savedAddresses: [
            {
              fullName: 'Kazi Farhan Ahmed',
              phoneNumber: '01711223344',
              email: 'farhan.ahmed@example.com',
              division: 'Dhaka',
              district: 'Dhaka',
              area: 'Gulshan 2',
              fullAddress: 'Flat 4B, Road 68, Gulshan 2, Dhaka-1212',
              postalCode: '1212',
            },
          ],
          createdAt: '2026-01-10T10:00:00Z',
        },
      ],
    };

    this.saveDataDirect(seeded);
    return seeded;
  }

  private saveDataDirect(data: DatabaseSchema) {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  }

  public save() {
    this.saveDataDirect(this.data);
  }

  // Getters
  public getProducts() { return this.data.products; }
  public getCategories() { return this.data.categories; }
  public getOrders() { return this.data.orders; }
  public getUsers() { return this.data.users; }
  public getCoupons() { return this.data.coupons; }
  public getReviews() { return this.data.reviews; }
  public getSettings() { return this.data.settings; }

  // Product Operations
  public findProductById(id: string) {
    return this.data.products.find(p => p.id === id || p.slug === id);
  }

  public addProduct(product: Product) {
    this.data.products.unshift(product);
    this.save();
    return product;
  }

  public updateProduct(id: string, updates: Partial<Product>) {
    const idx = this.data.products.findIndex(p => p.id === id);
    if (idx === -1) return null;
    this.data.products[idx] = {
      ...this.data.products[idx],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.save();
    return this.data.products[idx];
  }

  public deleteProduct(id: string) {
    const idx = this.data.products.findIndex(p => p.id === id);
    if (idx === -1) return false;
    this.data.products.splice(idx, 1);
    this.save();
    return true;
  }

  // Category Operations
  public addCategory(cat: Category) {
    this.data.categories.push(cat);
    this.save();
    return cat;
  }

  public updateCategory(id: string, updates: Partial<Category>) {
    const idx = this.data.categories.findIndex(c => c.id === id);
    if (idx === -1) return null;
    this.data.categories[idx] = { ...this.data.categories[idx], ...updates };
    this.save();
    return this.data.categories[idx];
  }

  public deleteCategory(id: string) {
    const idx = this.data.categories.findIndex(c => c.id === id);
    if (idx === -1) return false;
    this.data.categories.splice(idx, 1);
    this.save();
    return true;
  }

  // Orders Operations
  public addOrder(order: Order) {
    this.data.orders.unshift(order);
    // Deduct stock
    for (const item of order.items) {
      const prod = this.findProductById(item.productId);
      if (prod) {
        prod.stockQuantity = Math.max(0, prod.stockQuantity - item.quantity);
        const sStock = prod.sizeStock?.find(s => s.size === item.selectedSize);
        if (sStock) {
          sStock.stock = Math.max(0, sStock.stock - item.quantity);
        }
      }
    }
    this.save();
    return order;
  }

  public updateOrder(id: string, updates: Partial<Order>) {
    const idx = this.data.orders.findIndex(o => o.id === id || o.orderNumber === id);
    if (idx === -1) return null;
    this.data.orders[idx] = {
      ...this.data.orders[idx],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.save();
    return this.data.orders[idx];
  }

  // Coupon Operations
  public addCoupon(c: Coupon) {
    this.data.coupons.unshift(c);
    this.save();
    return c;
  }

  public updateCoupon(id: string, updates: Partial<Coupon>) {
    const idx = this.data.coupons.findIndex(c => c.id === id);
    if (idx === -1) return null;
    this.data.coupons[idx] = { ...this.data.coupons[idx], ...updates };
    this.save();
    return this.data.coupons[idx];
  }

  public deleteCoupon(id: string) {
    const idx = this.data.coupons.findIndex(c => c.id === id);
    if (idx === -1) return false;
    this.data.coupons.splice(idx, 1);
    this.save();
    return true;
  }

  // Review Operations
  public addReview(r: Review) {
    this.data.reviews.unshift(r);
    // Recalculate product rating
    const prod = this.findProductById(r.productId);
    if (prod) {
      const prodReviews = this.data.reviews.filter(rv => rv.productId === prod.id && rv.status === 'approved');
      if (prodReviews.length > 0) {
        const sum = prodReviews.reduce((acc, rv) => acc + rv.rating, 0);
        prod.rating = parseFloat((sum / prodReviews.length).toFixed(1));
        prod.reviewCount = prodReviews.length;
      }
    }
    this.save();
    return r;
  }

  public updateReview(id: string, updates: Partial<Review>) {
    const idx = this.data.reviews.findIndex(r => r.id === id);
    if (idx === -1) return null;
    this.data.reviews[idx] = { ...this.data.reviews[idx], ...updates };
    this.save();
    return this.data.reviews[idx];
  }

  public deleteReview(id: string) {
    const idx = this.data.reviews.findIndex(r => r.id === id);
    if (idx === -1) return false;
    this.data.reviews.splice(idx, 1);
    this.save();
    return true;
  }

  // Settings
  public updateSettings(updates: Partial<StoreSettings>) {
    this.data.settings = { ...this.data.settings, ...updates };
    this.save();
    return this.data.settings;
  }

  // Users
  public addUser(user: User & { passwordHash: string }) {
    this.data.users.push(user);
    this.save();
    return user;
  }

  public updateUser(id: string, updates: Partial<User & { passwordHash: string }>) {
    const idx = this.data.users.findIndex(u => u.id === id);
    if (idx === -1) return null;
    this.data.users[idx] = { ...this.data.users[idx], ...updates };
    this.save();
    return this.data.users[idx];
  }
}

export const db = new Database();
