import { Router, Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { db } from './db';
import { hashPassword, verifyPassword, createToken, verifyToken, TokenPayload } from './auth';
import { PaymentGatewayManager } from './payment';
import { Order, OrderStatus, PaymentStatus, Product, Coupon, Review, ShoeSize } from '../src/types';

export const apiRouter = Router();

// Middleware: Customer Auth
export function requireCustomerAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required. Please login.' });
  }
  const token = authHeader.split(' ')[1];
  const payload = verifyToken(token);
  if (!payload) {
    return res.status(401).json({ error: 'Session expired or invalid token.' });
  }
  (req as any).user = payload;
  next();
}

// Middleware: Admin Auth
export function requireAdminAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Admin access requires authorization.' });
  }
  const token = authHeader.split(' ')[1];
  const payload = verifyToken(token);
  if (!payload || payload.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied: Admin credentials required.' });
  }
  (req as any).admin = payload;
  next();
}

// ==========================================
// AUTHENTICATION ROUTES (Customer)
// ==========================================

apiRouter.post('/auth/register', (req: Request, res: Response) => {
  try {
    const { fullName, email, password, phoneNumber } = req.body;
    if (!fullName || !email || !password) {
      return res.status(400).json({ error: 'Full name, email, and password are required.' });
    }
    const cleanEmail = email.toLowerCase().trim();
    const existing = db.getUsers().find(u => u.email.toLowerCase() === cleanEmail);
    if (existing) {
      return res.status(409).json({ error: 'An account with this email already exists.' });
    }

    const newUser = {
      id: `usr-${Date.now()}`,
      fullName: fullName.trim(),
      email: cleanEmail,
      phoneNumber: (phoneNumber || '').trim(),
      role: 'customer' as const,
      isActive: true,
      passwordHash: hashPassword(password),
      savedAddresses: [],
      createdAt: new Date().toISOString(),
    };

    db.addUser(newUser);

    const token = createToken({
      userId: newUser.id,
      email: newUser.email,
      name: newUser.fullName,
      role: newUser.role,
    });

    const { passwordHash: _, ...userSafe } = newUser;
    return res.status(201).json({
      message: 'Registration successful! Welcome to STEPORA.',
      token,
      user: userSafe,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Registration failed.' });
  }
});

apiRouter.post('/auth/login', (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }
    const cleanEmail = email.toLowerCase().trim();
    const user = db.getUsers().find(u => u.email.toLowerCase() === cleanEmail && u.role === 'customer');

    if (!user || !verifyPassword(password, user.passwordHash)) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    if (!user.isActive) {
      return res.status(403).json({ error: 'Your account has been deactivated. Please contact support.' });
    }

    const token = createToken({
      userId: user.id,
      email: user.email,
      name: user.fullName,
      role: user.role,
    });

    const { passwordHash: _, ...userSafe } = user;
    return res.json({
      message: 'Login successful.',
      token,
      user: userSafe,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Login failed.' });
  }
});

apiRouter.get('/auth/me', requireCustomerAuth, (req: Request, res: Response) => {
  const payload = (req as any).user as TokenPayload;
  const user = db.getUsers().find(u => u.id === payload.userId);
  if (!user) {
    return res.status(404).json({ error: 'User profile not found.' });
  }
  const { passwordHash: _, ...userSafe } = user;
  return res.json({ user: userSafe });
});

apiRouter.put('/auth/profile', requireCustomerAuth, (req: Request, res: Response) => {
  const payload = (req as any).user as TokenPayload;
  const { fullName, phoneNumber, savedAddresses } = req.body;

  const updated = db.updateUser(payload.userId, {
    fullName: fullName || undefined,
    phoneNumber: phoneNumber || undefined,
    savedAddresses: savedAddresses || undefined,
  });

  if (!updated) {
    return res.status(404).json({ error: 'User not found.' });
  }

  const { passwordHash: _, ...userSafe } = updated;
  return res.json({ message: 'Profile updated successfully.', user: userSafe });
});

apiRouter.post('/auth/change-password', requireCustomerAuth, (req: Request, res: Response) => {
  const payload = (req as any).user as TokenPayload;
  const { currentPassword, newPassword } = req.body;

  if (!currentPassword || !newPassword || newPassword.length < 6) {
    return res.status(400).json({ error: 'New password must be at least 6 characters.' });
  }

  const user = db.getUsers().find(u => u.id === payload.userId);
  if (!user || !verifyPassword(currentPassword, user.passwordHash)) {
    return res.status(400).json({ error: 'Current password is incorrect.' });
  }

  db.updateUser(payload.userId, {
    passwordHash: hashPassword(newPassword),
  });

  return res.json({ message: 'Password changed successfully.' });
});

apiRouter.post('/auth/forgot-password', (req: Request, res: Response) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Email is required.' });
  const user = db.getUsers().find(u => u.email.toLowerCase() === email.toLowerCase().trim());
  // In demo/real, return a simulated verification reset token
  return res.json({
    message: 'If that email exists in our system, a password reset link has been dispatched.',
    demoResetToken: user ? `RESET-${Buffer.from(user.id).toString('base64url')}` : null,
  });
});

apiRouter.post('/auth/reset-password', (req: Request, res: Response) => {
  const { resetToken, newPassword } = req.body;
  if (!resetToken || !newPassword || newPassword.length < 6) {
    return res.status(400).json({ error: 'Valid reset token and new password (min 6 chars) are required.' });
  }
  try {
    const rawId = resetToken.replace('RESET-', '');
    const userId = Buffer.from(rawId, 'base64url').toString('utf-8');
    const user = db.getUsers().find(u => u.id === userId);
    if (!user) return res.status(400).json({ error: 'Invalid or expired password reset link.' });

    db.updateUser(userId, { passwordHash: hashPassword(newPassword) });
    return res.json({ message: 'Password has been reset successfully. You can now login.' });
  } catch {
    return res.status(400).json({ error: 'Invalid reset token format.' });
  }
});

// ==========================================
// ADMIN AUTHENTICATION
// ==========================================

apiRouter.post('/admin/login', (req: Request, res: Response) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Admin username and password are required.' });
    }

    const cleanUsername = username.trim();
    const adminUser = db.getUsers().find(
      u => u.role === 'admin' && (u.fullName.toLowerCase() === cleanUsername.toLowerCase() || u.email.toLowerCase() === cleanUsername.toLowerCase())
    );

    if (!adminUser) {
      return res.status(401).json({ error: 'Invalid admin credentials.' });
    }

    const isValid = verifyPassword(password, adminUser.passwordHash);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid admin credentials.' });
    }

    const token = createToken({
      userId: adminUser.id,
      email: adminUser.email,
      name: adminUser.fullName,
      role: 'admin',
    }, 14);

    const { passwordHash: _, ...safeAdmin } = adminUser;
    return res.json({
      message: 'Admin authorization granted.',
      token,
      admin: safeAdmin,
      isDefaultPassword: password === '123456',
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Admin authentication failed.' });
  }
});

apiRouter.get('/admin/me', requireAdminAuth, (req: Request, res: Response) => {
  const payload = (req as any).admin as TokenPayload;
  const admin = db.getUsers().find(u => u.id === payload.userId && u.role === 'admin');
  if (!admin) return res.status(404).json({ error: 'Admin user not found.' });
  const { passwordHash: _, ...safeAdmin } = admin;
  return res.json({ admin: safeAdmin });
});

apiRouter.post('/admin/change-password', requireAdminAuth, (req: Request, res: Response) => {
  const payload = (req as any).admin as TokenPayload;
  const { currentPassword, newPassword } = req.body;
  if (!newPassword || newPassword.length < 6) {
    return res.status(400).json({ error: 'New password must be at least 6 characters.' });
  }

  const admin = db.getUsers().find(u => u.id === payload.userId);
  if (!admin || !verifyPassword(currentPassword, admin.passwordHash)) {
    return res.status(400).json({ error: 'Current password is incorrect.' });
  }

  db.updateUser(admin.id, {
    passwordHash: hashPassword(newPassword),
  });

  return res.json({ message: 'Admin password updated securely.' });
});

// ==========================================
// STORE SETTINGS
// ==========================================

apiRouter.get('/settings', (_req: Request, res: Response) => {
  return res.json({ settings: db.getSettings() });
});

apiRouter.put('/admin/settings', requireAdminAuth, (req: Request, res: Response) => {
  const updated = db.updateSettings(req.body);
  return res.json({ message: 'Store settings updated successfully.', settings: updated });
});

// ==========================================
// PRODUCTS ENDPOINTS (Public & Admin)
// ==========================================

apiRouter.get('/products', (req: Request, res: Response) => {
  try {
    const {
      q,
      category,
      gender,
      brand,
      size,
      color,
      minPrice,
      maxPrice,
      rating,
      featured,
      bestSeller,
      newArrival,
      inStock,
      discountOnly,
      sort,
      page = '1',
      limit = '12',
    } = req.query as Record<string, string>;

    let list = db.getProducts().filter(p => p.isActive);

    // Search query
    if (q) {
      const searchTerms = q.toLowerCase().trim().split(/\s+/);
      list = list.filter(p => {
        const text = `${p.name} ${p.brand} ${p.category} ${p.subcategory || ''} ${p.sku} ${p.description} ${(p.tags || []).join(' ')}`.toLowerCase();
        return searchTerms.every(term => text.includes(term));
      });
    }

    // Category filter
    if (category && category !== 'all') {
      list = list.filter(p => p.category.toLowerCase() === category.toLowerCase() || p.slug.includes(category.toLowerCase()));
    }

    // Gender
    if (gender && gender !== 'all') {
      list = list.filter(p => p.gender === gender || p.gender === 'unisex');
    }

    // Brand
    if (brand && brand !== 'all') {
      list = list.filter(p => p.brand.toLowerCase() === brand.toLowerCase());
    }

    // Size
    if (size) {
      list = list.filter(p => p.availableSizes.includes(size as ShoeSize));
    }

    // Color
    if (color) {
      list = list.filter(p => p.availableColors.some(c => c.name.toLowerCase().includes(color.toLowerCase())));
    }

    // Price range
    if (minPrice) {
      const min = parseFloat(minPrice);
      if (!isNaN(min)) list = list.filter(p => (p.salePrice || p.price) >= min);
    }
    if (maxPrice) {
      const max = parseFloat(maxPrice);
      if (!isNaN(max)) list = list.filter(p => (p.salePrice || p.price) <= max);
    }

    // Rating
    if (rating) {
      const r = parseFloat(rating);
      if (!isNaN(r)) list = list.filter(p => p.rating >= r);
    }

    // Status filters
    if (featured === 'true') list = list.filter(p => p.featured);
    if (bestSeller === 'true') list = list.filter(p => p.bestSeller);
    if (newArrival === 'true') list = list.filter(p => p.newArrival);
    if (inStock === 'true') list = list.filter(p => p.stockQuantity > 0);
    if (discountOnly === 'true') list = list.filter(p => p.discountPercentage > 0);

    // Sorting
    switch (sort) {
      case 'price-low':
        list.sort((a, b) => (a.salePrice || a.price) - (b.salePrice || b.price));
        break;
      case 'price-high':
        list.sort((a, b) => (b.salePrice || b.price) - (a.salePrice || a.price));
        break;
      case 'rating':
        list.sort((a, b) => b.rating - a.rating);
        break;
      case 'best-selling':
        list.sort((a, b) => (b.bestSeller ? 1 : 0) - (a.bestSeller ? 1 : 0) || b.reviewCount - a.reviewCount);
        break;
      case 'popular':
        list.sort((a, b) => b.reviewCount - a.reviewCount);
        break;
      case 'newest':
      default:
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
    }

    const total = list.length;
    const pageNum = Math.max(1, parseInt(page) || 1);
    const limitNum = Math.max(1, parseInt(limit) || 12);
    const startIndex = (pageNum - 1) * limitNum;
    const paginated = list.slice(startIndex, startIndex + limitNum);

    return res.json({
      products: paginated,
      total,
      page: pageNum,
      totalPages: Math.ceil(total / limitNum),
      limit: limitNum,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Failed to fetch products.' });
  }
});

apiRouter.get('/products/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const product = db.findProductById(id);
  if (!product) {
    return res.status(404).json({ error: 'Sorry, this product is currently unavailable.' });
  }

  // Related products
  const related = db
    .getProducts()
    .filter(p => p.id !== product.id && p.isActive && (p.category === product.category || p.gender === product.gender))
    .slice(0, 4);

  return res.json({ product, related });
});

// Admin Product Management
apiRouter.get('/admin/products', requireAdminAuth, (_req: Request, res: Response) => {
  return res.json({ products: db.getProducts() });
});

apiRouter.post('/admin/products', requireAdminAuth, (req: Request, res: Response) => {
  try {
    const data = req.body;
    if (!data.name || !data.price || !data.category) {
      return res.status(400).json({ error: 'Product name, price, and category are required.' });
    }

    const price = parseFloat(data.price);
    const salePrice = data.salePrice ? parseFloat(data.salePrice) : price;
    const discountPercentage = price > salePrice ? Math.round(((price - salePrice) / price) * 100) : 0;
    const slug = data.slug || data.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');

    const newProduct: Product = {
      id: `prod-${Date.now()}`,
      name: data.name,
      slug,
      sku: data.sku || `STP-${Date.now().toString().slice(-4)}`,
      category: data.category,
      subcategory: data.subcategory || '',
      gender: data.gender || 'unisex',
      brand: data.brand || 'STEPORA',
      description: data.description || '',
      shortDescription: data.shortDescription || data.description?.slice(0, 100) || '',
      price,
      salePrice,
      discountPercentage,
      stockQuantity: parseInt(data.stockQuantity) || 10,
      availableSizes: data.availableSizes && data.availableSizes.length ? data.availableSizes : ['39', '40', '41', '42', '43'],
      sizeStock: data.sizeStock || [
        { size: '39', stock: 2 },
        { size: '40', stock: 3 },
        { size: '41', stock: 4 },
        { size: '42', stock: 4 },
        { size: '43', stock: 2 },
      ],
      availableColors: data.availableColors || [{ name: 'Classic Black', hex: '#111111' }],
      mainImage: data.mainImage || data.images?.[0] || 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=800&q=80',
      images: data.images && data.images.length ? data.images : [data.mainImage || 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=800&q=80'],
      tags: data.tags || ['Shoes', 'Footwear'],
      featured: Boolean(data.featured),
      bestSeller: Boolean(data.bestSeller),
      newArrival: Boolean(data.newArrival !== undefined ? data.newArrival : true),
      isActive: Boolean(data.isActive !== undefined ? data.isActive : true),
      rating: 5.0,
      reviewCount: 0,
      specifications: data.specifications || {
        upperMaterial: 'Premium Genuine Cowhide Leather',
        soleMaterial: 'Non-Slip Vulcanized Rubber Sole',
        insole: 'Cushioned Memory Foam Insole',
        closure: 'Lace-Up',
        weight: '340g',
        origin: 'Handmade in Bangladesh',
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const created = db.addProduct(newProduct);
    return res.status(201).json({ message: 'Product created successfully.', product: created });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Failed to create product.' });
  }
});

apiRouter.put('/admin/products/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const updates = req.body;
  if (updates.price && updates.salePrice) {
    const price = parseFloat(updates.price);
    const sale = parseFloat(updates.salePrice);
    updates.discountPercentage = price > sale ? Math.round(((price - sale) / price) * 100) : 0;
  }
  const updated = db.updateProduct(id, updates);
  if (!updated) return res.status(404).json({ error: 'Product not found.' });
  return res.json({ message: 'Product updated successfully.', product: updated });
});

apiRouter.delete('/admin/products/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const deleted = db.deleteProduct(id);
  if (!deleted) return res.status(404).json({ error: 'Product not found.' });
  return res.json({ message: 'Product deleted successfully.' });
});

apiRouter.post('/admin/products/:id/duplicate', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const original = db.findProductById(id);
  if (!original) return res.status(404).json({ error: 'Original product not found.' });

  const duplicated: Product = {
    ...original,
    id: `prod-${Date.now()}`,
    name: `${original.name} (Copy)`,
    slug: `${original.slug}-copy-${Date.now().toString().slice(-4)}`,
    sku: `${original.sku}-CPY`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.addProduct(duplicated);
  return res.status(201).json({ message: 'Product duplicated successfully.', product: duplicated });
});

// ==========================================
// CATEGORIES ENDPOINTS
// ==========================================

apiRouter.get('/categories', (_req: Request, res: Response) => {
  return res.json({ categories: db.getCategories().filter(c => c.isActive) });
});

apiRouter.get('/admin/categories', requireAdminAuth, (_req: Request, res: Response) => {
  return res.json({ categories: db.getCategories() });
});

apiRouter.post('/admin/categories', requireAdminAuth, (req: Request, res: Response) => {
  const { name, description, image, featured } = req.body;
  if (!name) return res.status(400).json({ error: 'Category name is required.' });

  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
  const newCat = {
    id: `cat-${Date.now()}`,
    name,
    slug,
    description: description || '',
    image: image || 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=800&q=80',
    itemCount: 0,
    featured: Boolean(featured),
    isActive: true,
  };
  db.addCategory(newCat);
  return res.status(201).json({ message: 'Category added.', category: newCat });
});

apiRouter.put('/admin/categories/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const updated = db.updateCategory(id, req.body);
  if (!updated) return res.status(404).json({ error: 'Category not found.' });
  return res.json({ message: 'Category updated.', category: updated });
});

apiRouter.delete('/admin/categories/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const success = db.deleteCategory(id);
  if (!success) return res.status(404).json({ error: 'Category not found.' });
  return res.json({ message: 'Category removed.' });
});

// ==========================================
// COUPON VALIDATION & ADMIN ENDPOINTS
// ==========================================

apiRouter.post('/coupons/apply', (req: Request, res: Response) => {
  const { code, subtotal } = req.body;
  if (!code) return res.status(400).json({ error: 'Coupon code is required.' });

  const cleanCode = code.toUpperCase().trim();
  const coupon = db.getCoupons().find(c => c.code.toUpperCase() === cleanCode && c.isActive);

  if (!coupon) {
    return res.status(400).json({ error: 'This coupon is invalid or expired.' });
  }

  const today = new Date().toISOString().split('T')[0];
  if (coupon.expiryDate && coupon.expiryDate < today) {
    return res.status(400).json({ error: 'This coupon is expired.' });
  }

  if (coupon.usageLimit && coupon.usageCount >= coupon.usageLimit) {
    return res.status(400).json({ error: 'This coupon has reached its usage limit.' });
  }

  const sub = parseFloat(subtotal) || 0;
  if (coupon.minOrderAmount && sub < coupon.minOrderAmount) {
    const settings = db.getSettings();
    return res.status(400).json({
      error: `Minimum order amount for this coupon is ${settings.currency} ${coupon.minOrderAmount}.`,
    });
  }

  let discountAmount = 0;
  if (coupon.discountType === 'percentage') {
    discountAmount = (sub * coupon.discountValue) / 100;
    if (coupon.maxDiscountAmount && discountAmount > coupon.maxDiscountAmount) {
      discountAmount = coupon.maxDiscountAmount;
    }
  } else {
    discountAmount = Math.min(coupon.discountValue, sub);
  }

  return res.json({
    valid: true,
    code: coupon.code,
    discountAmount: Math.round(discountAmount * 100) / 100,
    discountType: coupon.discountType,
    discountValue: coupon.discountValue,
    message: `Coupon ${coupon.code} applied successfully!`,
  });
});

apiRouter.get('/admin/coupons', requireAdminAuth, (_req: Request, res: Response) => {
  return res.json({ coupons: db.getCoupons() });
});

apiRouter.post('/admin/coupons', requireAdminAuth, (req: Request, res: Response) => {
  const { code, discountType, discountValue, minOrderAmount, maxDiscountAmount, expiryDate, usageLimit } = req.body;
  if (!code || !discountValue) {
    return res.status(400).json({ error: 'Coupon code and discount value are required.' });
  }

  const newCoupon: Coupon = {
    id: `coup-${Date.now()}`,
    code: code.toUpperCase().trim(),
    discountType: discountType || 'percentage',
    discountValue: parseFloat(discountValue) || 10,
    minOrderAmount: parseFloat(minOrderAmount) || 0,
    maxDiscountAmount: parseFloat(maxDiscountAmount) || 1000,
    startDate: new Date().toISOString().split('T')[0],
    expiryDate: expiryDate || '2026-12-31',
    usageLimit: parseInt(usageLimit) || 100,
    usageCount: 0,
    isActive: true,
  };

  db.addCoupon(newCoupon);
  return res.status(201).json({ message: 'Coupon created.', coupon: newCoupon });
});

apiRouter.put('/admin/coupons/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const updated = db.updateCoupon(id, req.body);
  if (!updated) return res.status(404).json({ error: 'Coupon not found.' });
  return res.json({ message: 'Coupon updated.', coupon: updated });
});

apiRouter.delete('/admin/coupons/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const success = db.deleteCoupon(id);
  if (!success) return res.status(404).json({ error: 'Coupon not found.' });
  return res.json({ message: 'Coupon deleted.' });
});

// ==========================================
// ORDERS & CHECKOUT ENDPOINTS
// ==========================================

apiRouter.post('/orders', (req: Request, res: Response) => {
  try {
    const {
      customerId,
      shippingAddress,
      items,
      couponCode,
      paymentMethod,
      shippingRegion,
    } = req.body;

    if (!shippingAddress || !shippingAddress.fullName || !shippingAddress.phoneNumber || !shippingAddress.fullAddress) {
      return res.status(400).json({ error: 'Complete shipping address and contact number are required.' });
    }

    if (!items || !items.length) {
      return res.status(400).json({ error: 'Your cart is empty. Please add items to checkout.' });
    }

    const settings = db.getSettings();

    // Verify products and calculate exact prices server-side
    let calculatedSubtotal = 0;
    const verifiedItems = [];

    for (const item of items) {
      const product = db.findProductById(item.productId);
      if (!product || !product.isActive) {
        return res.status(400).json({ error: `Product "${item.productName || item.productId}" is no longer available.` });
      }

      if (!item.selectedSize) {
        return res.status(400).json({ error: `Please select a size for ${product.name}.` });
      }

      const sStock = product.sizeStock?.find(s => s.size === item.selectedSize);
      if (sStock && sStock.stock < item.quantity) {
        return res.status(400).json({ error: `Size ${item.selectedSize} of ${product.name} only has ${sStock.stock} in stock.` });
      }

      const price = product.salePrice || product.price;
      const itemTotal = price * item.quantity;
      calculatedSubtotal += itemTotal;

      verifiedItems.push({
        productId: product.id,
        productName: product.name,
        sku: product.sku,
        image: product.mainImage,
        price,
        quantity: item.quantity,
        selectedSize: item.selectedSize,
        selectedColor: item.selectedColor || product.availableColors[0],
        itemTotal,
      });
    }

    // Shipping calculation
    const region = shippingRegion === 'outside_dhaka' ? 'outside_dhaka' : 'inside_dhaka';
    let shippingFee = region === 'outside_dhaka' ? settings.outsideDhakaShippingFee : settings.insideDhakaShippingFee;
    if (calculatedSubtotal >= settings.freeShippingThreshold) {
      shippingFee = 0;
    }

    // Coupon discount calculation
    let discount = 0;
    if (couponCode) {
      const coupon = db.getCoupons().find(c => c.code.toUpperCase() === couponCode.toUpperCase().trim() && c.isActive);
      if (coupon) {
        if (coupon.discountType === 'percentage') {
          discount = (calculatedSubtotal * coupon.discountValue) / 100;
          if (coupon.maxDiscountAmount && discount > coupon.maxDiscountAmount) {
            discount = coupon.maxDiscountAmount;
          }
        } else {
          discount = Math.min(coupon.discountValue, calculatedSubtotal);
        }
        coupon.usageCount += 1;
        db.save();
      }
    }

    const total = Math.max(0, calculatedSubtotal - discount + shippingFee);

    // Generate unique order number: ORD-2026-XXXXXX
    const existingCount = db.getOrders().length + 101;
    const orderNumber = `ORD-2026-${existingCount.toString().padStart(6, '0')}`;

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber,
      customerId: customerId || undefined,
      customerName: shippingAddress.fullName,
      customerEmail: shippingAddress.email || '',
      customerPhone: shippingAddress.phoneNumber,
      items: verifiedItems,
      subtotal: calculatedSubtotal,
      discount,
      couponCode: discount > 0 ? couponCode : undefined,
      shippingFee,
      shippingRegion: region,
      total,
      paymentMethod: paymentMethod || 'cod',
      paymentStatus: paymentMethod === 'cod' ? 'Pending' : 'Processing',
      orderStatus: 'Pending',
      shippingAddress,
      timeline: [
        {
          status: 'Pending',
          title: 'Order Placed',
          description: `Order successfully placed via ${paymentMethod ? paymentMethod.toUpperCase() : 'COD'}.`,
          timestamp: new Date().toISOString(),
          isCompleted: true,
        },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    db.addOrder(newOrder);

    return res.status(201).json({
      message: 'Order created successfully.',
      order: newOrder,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Failed to place order.' });
  }
});

apiRouter.get('/orders/track', (req: Request, res: Response) => {
  const { query } = req.query as { query?: string };
  if (!query) return res.status(400).json({ error: 'Please enter an Order ID or Phone Number to track.' });

  const cleanQuery = query.trim().toUpperCase();
  const order = db.getOrders().find(
    o => o.orderNumber.toUpperCase() === cleanQuery || o.customerPhone.includes(cleanQuery) || o.id === query.trim()
  );

  if (!order) {
    return res.status(404).json({ error: 'No order found matching your tracking details. Please double check.' });
  }

  return res.json({ order });
});

apiRouter.get('/orders/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const order = db.getOrders().find(o => o.id === id || o.orderNumber === id);
  if (!order) {
    return res.status(404).json({ error: 'Order not found.' });
  }
  return res.json({ order });
});

apiRouter.get('/customer/orders', requireCustomerAuth, (req: Request, res: Response) => {
  const payload = (req as any).user as TokenPayload;
  const orders = db.getOrders().filter(o => o.customerId === payload.userId || o.customerEmail === payload.email);
  return res.json({ orders });
});

// Admin Orders
apiRouter.get('/admin/orders', requireAdminAuth, (req: Request, res: Response) => {
  const { status, paymentStatus, search } = req.query as Record<string, string>;
  let list = db.getOrders();

  if (status && status !== 'all') {
    list = list.filter(o => o.orderStatus === status);
  }
  if (paymentStatus && paymentStatus !== 'all') {
    list = list.filter(o => o.paymentStatus === paymentStatus);
  }
  if (search) {
    const s = search.toLowerCase();
    list = list.filter(o => o.orderNumber.toLowerCase().includes(s) || o.customerName.toLowerCase().includes(s) || o.customerPhone.includes(s));
  }

  return res.json({ orders: list });
});

apiRouter.put('/admin/orders/:id/status', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const { orderStatus, paymentStatus, note } = req.body;

  const order = db.getOrders().find(o => o.id === id || o.orderNumber === id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });

  const updates: Partial<Order> = {};
  if (orderStatus && orderStatus !== order.orderStatus) {
    updates.orderStatus = orderStatus as OrderStatus;
    const newTimeline = [...order.timeline];
    newTimeline.push({
      status: orderStatus as OrderStatus,
      title: `Status Updated to ${orderStatus}`,
      description: note || `Admin updated order status to ${orderStatus}.`,
      timestamp: new Date().toISOString(),
      isCompleted: true,
    });
    updates.timeline = newTimeline;
  }

  if (paymentStatus) {
    updates.paymentStatus = paymentStatus as PaymentStatus;
  }

  const updated = db.updateOrder(order.id, updates);
  return res.json({ message: 'Order status updated.', order: updated });
});

// ==========================================
// PAYMENT GATEWAY INTEGRATION
// ==========================================

apiRouter.post('/payment/create', async (req: Request, res: Response) => {
  try {
    const { orderId, method } = req.body;
    const order = db.getOrders().find(o => o.id === orderId || o.orderNumber === orderId);

    if (!order) return res.status(404).json({ error: 'Order not found for payment processing.' });

    const settings = db.getSettings();
    const result = await PaymentGatewayManager.initiate(method, {
      orderId: order.id,
      orderNumber: order.orderNumber,
      amount: order.total,
      currency: settings.currencyCode,
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      customerEmail: order.customerEmail,
    });

    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Payment initiation failed.' });
  }
});

apiRouter.post('/payment/verify', async (req: Request, res: Response) => {
  try {
    const { orderId, paymentMethod, transactionId, otpOrPin, status } = req.body;
    const order = db.getOrders().find(o => o.id === orderId || o.orderNumber === orderId);

    if (!order) return res.status(404).json({ error: 'Order not found.' });

    const verification = await PaymentGatewayManager.verify(
      paymentMethod,
      {
        orderId: order.id,
        paymentMethod,
        transactionId,
        otpOrPin,
        status,
      },
      order.total
    );

    if (verification.success && verification.paymentStatus === 'Paid') {
      const newTimeline = [...order.timeline];
      newTimeline.push({
        status: 'Confirmed',
        title: 'Payment Confirmed',
        description: `Verified transaction ${verification.transactionId} via ${paymentMethod.toUpperCase()}`,
        timestamp: new Date().toISOString(),
        isCompleted: true,
      });

      db.updateOrder(order.id, {
        paymentStatus: 'Paid',
        orderStatus: 'Confirmed',
        transactionId: verification.transactionId,
        timeline: newTimeline,
      });
    } else if (verification.paymentStatus === 'Failed' || verification.paymentStatus === 'Cancelled') {
      db.updateOrder(order.id, {
        paymentStatus: verification.paymentStatus,
      });
    }

    return res.json(verification);
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Payment verification failed.' });
  }
});

// ==========================================
// REVIEWS
// ==========================================

apiRouter.get('/products/:id/reviews', (req: Request, res: Response) => {
  const { id } = req.params;
  const reviews = db.getReviews().filter(r => r.productId === id && r.status === 'approved');
  return res.json({ reviews });
});

apiRouter.post('/products/:id/reviews', (req: Request, res: Response) => {
  const { id } = req.params;
  const { userName, userEmail, rating, title, comment } = req.body;

  if (!userName || !rating || !comment) {
    return res.status(400).json({ error: 'Name, rating, and review text are required.' });
  }

  // Check if verified purchaser
  const hasPurchased = db.getOrders().some(
    o =>
      (o.customerEmail.toLowerCase() === (userEmail || '').toLowerCase().trim() ||
        o.customerName.toLowerCase() === userName.toLowerCase().trim()) &&
      o.items.some(it => it.productId === id) &&
      o.orderStatus === 'Delivered'
  );

  const newReview: Review = {
    id: `rev-${Date.now()}`,
    productId: id,
    userName: userName.trim(),
    userEmail: (userEmail || '').trim(),
    rating: Math.min(5, Math.max(1, parseInt(rating) || 5)),
    title: title || 'Verified Customer Review',
    comment: comment.trim(),
    isVerifiedPurchase: hasPurchased,
    status: 'approved',
    createdAt: new Date().toISOString(),
  };

  db.addReview(newReview);
  return res.status(201).json({ message: 'Thank you! Your review has been published.', review: newReview });
});

apiRouter.get('/admin/reviews', requireAdminAuth, (_req: Request, res: Response) => {
  return res.json({ reviews: db.getReviews() });
});

apiRouter.put('/admin/reviews/:id/status', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const { status } = req.body;
  const updated = db.updateReview(id, { status });
  if (!updated) return res.status(404).json({ error: 'Review not found.' });
  return res.json({ message: 'Review status updated.', review: updated });
});

apiRouter.delete('/admin/reviews/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const success = db.deleteReview(id);
  if (!success) return res.status(404).json({ error: 'Review not found.' });
  return res.json({ message: 'Review removed.' });
});

// ==========================================
// ADMIN DASHBOARD & ANALYTICS
// ==========================================

apiRouter.get('/admin/dashboard', requireAdminAuth, (_req: Request, res: Response) => {
  const orders = db.getOrders();
  const products = db.getProducts();
  const users = db.getUsers();

  const totalSales = orders.filter(o => o.paymentStatus === 'Paid').reduce((acc, o) => acc + o.total, 0);
  const totalOrders = orders.length;
  const pendingOrders = orders.filter(o => o.orderStatus === 'Pending' || o.orderStatus === 'Confirmed').length;
  const completedOrders = orders.filter(o => o.orderStatus === 'Delivered').length;
  const cancelledOrders = orders.filter(o => o.orderStatus === 'Cancelled').length;

  const lowStockCount = products.filter(p => p.stockQuantity > 0 && p.stockQuantity <= 5).length;
  const outOfStockCount = products.filter(p => p.stockQuantity === 0).length;

  // Chart data: sales by day / recent 7 periods
  const salesMap = new Map<string, { amount: number; count: number }>();
  for (const o of orders) {
    const d = o.createdAt.split('T')[0];
    const curr = salesMap.get(d) || { amount: 0, count: 0 };
    curr.amount += o.total;
    curr.count += 1;
    salesMap.set(d, curr);
  }

  const salesOverview = Array.from(salesMap.entries())
    .map(([date, val]) => ({ date, amount: Math.round(val.amount), orders: val.count }))
    .slice(-7);

  // Category performance
  const catSales = new Map<string, { sales: number; count: number }>();
  for (const o of orders) {
    for (const it of o.items) {
      const prod = products.find(p => p.id === it.productId);
      const cat = prod?.category || 'general';
      const curr = catSales.get(cat) || { sales: 0, count: 0 };
      curr.sales += it.itemTotal;
      curr.count += it.quantity;
      catSales.set(cat, curr);
    }
  }

  const categoryPerformance = Array.from(catSales.entries()).map(([category, val]) => ({
    category,
    sales: val.sales,
    count: val.count,
  }));

  // Top selling products
  const prodSales = new Map<string, { sales: number; revenue: number; name: string; image: string }>();
  for (const o of orders) {
    for (const it of o.items) {
      const curr = prodSales.get(it.productId) || { sales: 0, revenue: 0, name: it.productName, image: it.image };
      curr.sales += it.quantity;
      curr.revenue += it.itemTotal;
      prodSales.set(it.productId, curr);
    }
  }

  const topSellingProducts = Array.from(prodSales.entries())
    .map(([id, val]) => ({ id, ...val }))
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 5);

  return res.json({
    stats: {
      totalSales,
      todaySales: Math.round(totalSales * 0.15),
      monthlySales: Math.round(totalSales * 0.75),
      totalOrders,
      pendingOrders,
      completedOrders,
      cancelledOrders,
      totalCustomers: users.filter(u => u.role === 'customer').length,
      totalProducts: products.length,
      lowStockCount,
      outOfStockCount,
      totalRevenue: totalSales,
      salesOverview,
      categoryPerformance,
      topSellingProducts,
    },
  });
});

// Admin Customers Management
apiRouter.get('/admin/customers', requireAdminAuth, (_req: Request, res: Response) => {
  const users = db.getUsers().filter(u => u.role === 'customer');
  const orders = db.getOrders();

  const customerList = users.map(u => {
    const userOrders = orders.filter(o => o.customerId === u.id || o.customerEmail === u.email);
    const totalSpent = userOrders.filter(o => o.paymentStatus === 'Paid').reduce((sum, o) => sum + o.total, 0);
    const { passwordHash: _, ...safeUser } = u;
    return {
      ...safeUser,
      ordersCount: userOrders.length,
      totalSpent,
      lastOrderDate: userOrders[0]?.createdAt || null,
    };
  });

  return res.json({ customers: customerList });
});

apiRouter.put('/admin/customers/:id/status', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const { isActive } = req.body;
  const updated = db.updateUser(id, { isActive });
  if (!updated) return res.status(404).json({ error: 'Customer not found.' });
  const { passwordHash: _, ...safe } = updated;
  return res.json({ message: 'Customer status updated.', customer: safe });
});

// Admin Inventory
apiRouter.get('/admin/inventory', requireAdminAuth, (_req: Request, res: Response) => {
  const products = db.getProducts();
  const inventoryItems = products.map(p => ({
    id: p.id,
    name: p.name,
    sku: p.sku,
    brand: p.brand,
    category: p.category,
    price: p.price,
    salePrice: p.salePrice,
    stockQuantity: p.stockQuantity,
    sizeStock: p.sizeStock,
    isLowStock: p.stockQuantity <= 5 && p.stockQuantity > 0,
    isOutOfStock: p.stockQuantity === 0,
  }));
  return res.json({ inventory: inventoryItems });
});

apiRouter.post('/admin/inventory/update', requireAdminAuth, (req: Request, res: Response) => {
  const { productId, size, newStock } = req.body;
  const product = db.findProductById(productId);
  if (!product) return res.status(404).json({ error: 'Product not found.' });

  if (size && product.sizeStock) {
    const sItem = product.sizeStock.find(s => s.size === size);
    if (sItem) {
      sItem.stock = parseInt(newStock) || 0;
    } else {
      product.sizeStock.push({ size, stock: parseInt(newStock) || 0 });
    }
    // Recompute total stock
    product.stockQuantity = product.sizeStock.reduce((acc, s) => acc + s.stock, 0);
  } else {
    product.stockQuantity = parseInt(newStock) || 0;
  }

  db.save();
  return res.json({ message: 'Stock quantity updated.', product });
});

// Admin Reports (with CSV export capability)
apiRouter.get('/admin/reports', requireAdminAuth, (req: Request, res: Response) => {
  const { format, reportType } = req.query as { format?: string; reportType?: string };
  const orders = db.getOrders();
  const products = db.getProducts();

  if (format === 'csv') {
    // Generate clean CSV content
    let csvHeader = 'Order Number,Date,Customer Name,Phone,Payment Method,Payment Status,Order Status,Total (BDT)\n';
    let csvRows = orders
      .map(
        o =>
          `"${o.orderNumber}","${o.createdAt}","${o.customerName}","${o.customerPhone}","${o.paymentMethod}","${o.paymentStatus}","${o.orderStatus}",${o.total}`
      )
      .join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="stepora_sales_report.csv"');
    return res.send(csvHeader + csvRows);
  }

  return res.json({
    summary: {
      generatedAt: new Date().toISOString(),
      totalOrders: orders.length,
      totalSalesRevenue: orders.filter(o => o.paymentStatus === 'Paid').reduce((sum, o) => sum + o.total, 0),
      topCategories: Array.from(new Set(products.map(p => p.category))),
    },
  });
});
